# Implementation Plan

## Overview and goal

Build the approved ShopSmart personalized retail-recommendation POC in the repository root, following [SDD.md](./SDD.md) as the design source of truth. Deliver the minimum complete demo journey first: create a lightweight demo account, enter the storefront, browse and view image-bearing products, and use recommendation/chat. Complete the synthetic catalog, Azure OpenAI hybrid recommendation path, live stock/price checks, privacy, audit, testing, demo, and final documentation without adding production identity, new services, or unsanctioned architecture.

The estimate is **4 hours 20 minutes planned work plus 40 minutes contingency** (total cap: 5 hours). The optional FastAPI mock API is deliberately excluded from the core plan; SDD §7.4b permits deferring it until the core demo passes, and it is not needed for the primary journey. No application code is to be written until the human confirms the planning review gate.

## Derived facts and Decision Log

### Derived from SDD

- Python 3.11+, Streamlit, SQLite, Chroma, Pydantic v2, `openai` Azure SDK, and `python-dotenv`.
- Azure OpenAI is the only LLM provider; chat/function-calling and embedding deployments are required.
- Local `.venv` + pip/`requirements.txt`; `.env` for secrets; synthetic data only.
- Synthetic data: 50,000 SKUs, 12 customers, about 300 historical events, and 2,000 embedded products.
- SQLite-backed inventory/pricing/promotion stubs are the required default; optional HTTP mock API is deferred.
- Hybrid retrieval + one tool-calling agent, with output validation, live stock/price checks, fallback, PII masking, consent, and an audit row per recommendation/refresh.
- Streamlit must support demo account creation, customer selection, catalogue browsing, product details, product images/placeholders, recommendation cards, chat, simulation controls, metrics, and audit display.
- No model training; embedding/index construction is required but is not ML training.
- Automated checks include unit tests, smoke checks, and a 15-case labelled evaluation with an 80% pass threshold.
- Product account creation and browsing/image display are release-blocking demo paths. No product administration or production authentication.

### Interview decisions

| # | Decision | Chosen | Source |
|---|---|---|---|
| 1 | Azure configuration readiness | Available to configure locally; do not share endpoint/key/deployment values in chat | User |
| 2 | Human task owner label | Human developer | Accepted recommendation |
| 3 | Git workflow | No Git/commits in this workspace | Accepted recommendation; workspace is not a Git repository |
| 4 | Task granularity | Fine-grained, approximately 15–30 minute work units with explicit steps | Accepted recommendation |
| 5 | Code quality | SDD baseline: type hints and tests; no new linter | Accepted recommendation |
| 6 | Model switching | Allowed at any time with tracker and handoff update | Accepted recommendation |
| 7 | Runtime/environment | Python 3.11 venv + pip and `requirements.txt` | Derived from SDD §§3.3, 9.2, 13.1 |
| 8 | Secrets | `.env` locally, `.env.example` in project; never disclose or log secrets | Derived from SDD §§3.3, 8.7 |
| 9 | Data and integrations | Synthetic data; SQLite stubs; no real retail system | Derived from SDD §§3.1, 3.3, 7.4 |
| 10 | Validation and phase gates | SDD unit/smoke/evaluation checks; pause at each required phase gate | Derived from SDD and accepted workflow |

No scope or architecture deviation is approved. Any future change requires a human decision and a tracker Decision Log entry before implementation.

## Phase overview

| Phase | Objective | Time budget | Entry criteria | Exit criteria |
|---|---|---:|---|---|
| 0. Setup | Establish package/config/test scaffold and validate Azure configuration | 20 min | Human confirms planning review | Setup commands/scaffold are ready; Azure smoke check passes or the precise external blocker is recorded |
| 1. Development | Build data/index, application modules, services, and primary Streamlit storefront | 165 min | Phase 0 gate approved | Requirements mapped to implementation; account creation and browse/view journey works; unit/smoke checks for modules pass |
| 2. ML Training | N/A — no ML training in SDD | 0 min | N/A | Explicitly marked N/A; Azure embeddings/index are handled in Development |
| 3. Testing and Debugging | Run unit, smoke, and evaluation checks; fix all failures | 35 min | Development gate approved | All required tests pass, evaluation reaches >=80%, no open blockers |
| 4. Demo Prep | Run from clean start and rehearse release-blocking demo paths | 10 min | Testing gate approved | Account, browse, product images, recommendations/chat, and key demo actions verified |
| 5. Final Documentation | Write and verify README, walkthrough, and solution overview from actual implementation | 30 min | Demo Prep done and explicit `CONFIRM COMPLETE` received after testing | All three docs verified; tracker close-out and handoff complete |

**Total:** 260 minutes (4h20) planned, plus 40 minutes contingency = 5 hours maximum. The optional API extension is outside the committed scope/timebox and is dropped first.

## Build order and dependency graph

```mermaid
flowchart TD
    GATE["Human confirms planning review"] --> SETUP["Phase 0: package, config, Azure smoke"]
    SETUP --> G0["Human approves Setup gate"]
    G0 --> DB["SQLite schema + synthetic vocab/personas/data"]
    DB --> IDX["Azure client + Chroma index"]
    DB --> FOUND["Models, privacy, stubs, audit, events"]
    IDX --> RET["Retrieval, tools, prompts, guardrails, fallback"]
    FOUND --> RET
    RET --> SVC["Agent + RecommendationService + focused tests"]
    SVC --> UI["Streamlit signup, browse, images, recommendations/chat"]
    UI --> TEST["Phase 3: unit + smoke + evaluation + fixes"]
    TEST --> G3["Human confirms testing complete"]
    G3 --> DEMO["Phase 4: clean-start demo rehearsal"]
    DEMO --> G4["Human approves Demo Prep gate"]
    G4 --> DOCGATE["Human replies CONFIRM COMPLETE"]
    DOCGATE --> DOCS["Phase 5: README, WALKTHROUGH, SOLUTION_OVERVIEW"]
    DOCS --> CLOSE["Verify docs, close tracker, handoff"]
```

## Per-phase detailed approach

### Phase 0 — Setup (20 min)

- Create the SDD-defined scaffold, pinned `requirements.txt`, `pyproject.toml`, `pytest.ini`, `.gitignore`, `.env.example`, package markers, and `.github/copilot-instructions.md`.
- Implement `src/retailrec/config.py` and the Azure client wrapper in `src/retailrec/llm.py` only to the degree needed for the Azure readiness smoke check.
- Human enters actual Azure values and a non-default pseudonymization salt locally in `.env`; do not ask them to paste secrets into chat.
- Run `python scripts/smoke_test.py --azure-only` after setup scripts exist. Do not claim live Azure works unless chat and embeddings both return successfully.

### Phase 1 — Development (165 min)

1. **Data foundation:** implement `db.py`; create `data/vocab.json` and `data/personas.json`; implement deterministic `scripts/generate_data.py`. Include optional `image_url` values for demo-visible products and preserve a safe category placeholder when missing/broken.
2. **Embeddings/index:** finish `llm.py`; implement `scripts/build_index.py` for exactly 2,000 products and persistent Chroma collection `products`. Do not substitute another LLM or external AI service.
3. **Core foundations:** implement typed Pydantic models, privacy masking/pseudonymization/profile filtering, inventory and pricing Protocols/stubs, audit persistence, and event/feedback/metrics modules. Add tests T-01..T-04 and T-11.
4. **Recommendation pipeline:** implement Chroma/SQL retrieval, the four function schemas and safe tool executor, SDD prompt, JSON validation/live guardrails, fallback, tool-calling loop, and service facade. Add fakes and tests T-05..T-10. Preserve the viewed-SKU exclusion and fail-closed data verification.
5. **UI:** implement `app/streamlit_app.py` with lightweight demo account creation (display name/email, no password), existing demo customers, storefront navigation, category browsing, view details, images/placeholders, chat and recommendation cards, simulation actions, metrics, and audit viewer. Keep impressions/event recording in service callbacks, never render reruns.
6. Deliver in dependency order, preserving SDD module names/signatures and using no extra application frameworks. No product admin UI and no production authentication.

### Phase 2 — ML Training

N/A — no ML training in the SDD. Embedding the selected products and building Chroma are retrieval/index setup tasks already covered in Phase 1.

### Phase 3 — Testing and Debugging (35 min)

- Run focused tests during module work, then `pytest -q`.
- Run `python scripts/smoke_test.py` and verify S-01 through S-03 (Azure chat/embed, data/index counts, audited recommendation with live-valid items).
- Implement/use `data/eval_set.json` and `scripts/run_eval.py`; run all 15 evaluation cases and require >=80% success. Verify report output and process exit code. If a failure occurs, diagnose and repair before proceeding; do not lower acceptance thresholds silently.
- Test demo account validation/creation, existing customer entry, image rendering/fallback, catalogue navigation, product view/exclusion, recommendation/chat, refresh after stock/promotion changes, and audit/events.
- If Azure credentials or a required external dependency are unavailable, stop at the dependency, record `BLOCKED-HUMAN` plus exact required action, and wait. SQLite stub mode keeps local browsing navigable but does not count as a successful Azure integration test.

### Phase 4 — Demo Prep (10 min)

- Generate the database and index using the clean-start setup, launch Streamlit, and walk the critical route: create account → browse → view product → recommendation/chat.
- Verify images or category placeholders; demonstrate a stock flip and promotion refresh without an LLM call when feasible.
- Confirm AI vs Baseline switch, feedback, audit view, and evaluation command; record any known limits truthfully. Do not claim Azure-backed behavior if only stub/fallback behavior was exercised.

### Phase 5 — Final Documentation (LAST, 30 min)

- Do not begin until Phases 0–4 are complete, tests and evaluation pass, blockers/manual actions are resolved, and the human explicitly replies `CONFIRM COMPLETE`.
- Write `README.md`, `WALKTHROUGH.md`, and `SOLUTION_OVERVIEW.md` from the final code/configuration/results only.
- Verify each documented command, path, test count, result, architecture claim, and limitation against the workspace. No placeholders or planned-but-unimplemented features.
- Update tracker immediately after each document and final verification, then write the close-out/handoff.

## Environment and setup steps

Windows commands (from the project root; use PowerShell):

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pip install -e .
Copy-Item .env.example .env
# Human fills the Azure values and PSEUDO_SALT in local .env; never paste values into chat.
python scripts/smoke_test.py --azure-only
python scripts/generate_data.py
python scripts/build_index.py
python scripts/smoke_test.py
pytest -q
python scripts/run_eval.py
streamlit run app/streamlit_app.py
```

The smoke check is intentionally sequenced after configuration and before data/index creation. No Git commands are planned because the current workspace is not a Git repository and the interview selected no Git/commits.

## Configuration and secrets

- Required local values: `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_CHAT_DEPLOYMENT`, `AZURE_OPENAI_EMBED_DEPLOYMENT`, and `PSEUDO_SALT`; use `AZURE_OPENAI_API_VERSION=2024-10-21` unless the Azure resource requires another supported value.
- Optional settings/defaults follow SDD §8.7, including `DB_PATH=data/catalog.db`, `CHROMA_PATH=data/chroma`, `RANDOM_SEED=42`, `CATALOG_SIZE=50000`, `EMBED_SUBSET_PER_SUBCATEGORY=40`, `API_BACKEND=stub`.
- `.env` is local and ignored by `.gitignore`; `.env.example` contains placeholders only. Never log or disclose credentials. The selected owner confirmed Azure configuration is available locally, not that any secret was supplied in chat.
- No production authentication, password storage, SSO, Key Vault, or new secrets service.

## Data plan

- Use the exact deterministic synthetic schema, category/subcategory vocabulary and distributions in SDD §§8.2 and 10; generate 50,000 products, inventory rows, promotions, 12 synthetic customers, and 25 historical events/customer.
- Select 40 in-stock/popular products per subcategory for 2,000 embeddings; validate DB and Chroma counts.
- Set C12 consent to false and use salted pseudonymous IDs for event history.
- Product imagery is optional URL data; use an existing/available URL when practical and a category-based placeholder for absent/failed URLs. Do not add image management or make remote image success a prerequisite for browsing.
- Evaluation cases and `data/eval_report.json` follow SDD §12.3; generated DB/index/report are ignored artifacts.

## ML plan

N/A, no ML training in SDD. Azure embeddings and Chroma index construction are required system setup, not training/fine-tuning.

## Testing plan

- Unit: SDD T-01..T-11 using in-memory/test fixtures and `FakeLLM`; no network in unit tests.
- Smoke: S-01 Azure chat+embedding, S-02 exact data/index counts, S-03 audited/live-valid recommendation.
- Evaluation: E01–E15 with common privacy, stock, audit, latency, exclusion, and case-specific checks; require >=12/15 (80%) and exit code 0.
- UI/demo acceptance: successful demo signup and entry, existing customer path, category browse, product detail, images/placeholders, chat/recommendation, stock refresh, promotion, feedback and audit.
- Optional T-12/T-13 mock HTTP tests are not part of this plan because the optional API is deferred.

## Risks, fallbacks, and cut list

| Risk | Mitigation/fallback |
|---|---|
| Azure credentials, deployment, quota, or connectivity unavailable | Human config action; stop Azure-dependent acceptance and mark blocked. Keep local browsing and SQLite stub paths available; clearly label simulation and do not claim live AI verification. |
| 4–5 hour budget pressure | Drop optional FastAPI mock API first; then use SDD §11.4 cuts in order and record any accepted cut as a Decision Log entry. Do not cut account creation, browse/view journey, image fallback, live stock/price recheck, privacy, audit, or core fallback. |
| Streamlit reruns duplicate events or stale state | Use session state and callbacks; recommendation/refresh service owns impressions; test clean journeys. |
| LLM JSON/relevance failures | Schema retry, evaluate, repair prompt/logic, then SDD fallback; never fabricate verification. |
| Product image URLs missing/unavailable | Category-based placeholder; product browsing and recommendations remain operable. |
| SDD describes root `SDD.md`, while its illustrative tree lists `docs/SDD.md` | Use the actual root `[SDD.md](./SDD.md)` as source; do not duplicate or move it. |

## Manual actions list

| Action | Who | When |
|---|---|---|
| Enter the available Azure endpoint/key/API version/deployment names and a non-default `PSEUDO_SALT` into local `.env`; keep secrets out of chat | Human developer | Phase 0 before Azure smoke check |
| Approve Phase 0 before Development | Human developer | Setup phase gate |
| Approve Development before Testing and Debugging | Human developer | Development phase gate |
| Confirm full end-to-end testing is complete (`CONFIRM COMPLETE`) before final docs | Human developer | After Testing and Demo Prep |
| Approve each remaining phase gate and resolve any specific blocker | Human developer | At the corresponding gate/blocker |

If a manual action is needed while executing, stop, update the tracker to `BLOCKED-HUMAN`, state exact steps and wait; do not continue to dependent work.

## Definition of Done for the prototype

- All required core files/modules/scripts/tests from SDD §9 exist or have an explicitly approved tracker deviation.
- Synthetic data/index acceptance counts pass; Azure chat and embedding smoke succeeds.
- All unit tests and smoke tests pass; 15-case evaluation is >=80%.
- Demo account creation and product browsing/view journeys work; product images appear where available and gracefully fall back.
- Recommendation outputs are schema-validated and live-stock/price checked; PII masking, consent, audit, fallback, metrics and feedback are verified.
- Demo rehearsal succeeds from a clean start; blockers and manual actions are resolved.
- After explicit human completion confirmation, all three final docs match the implemented code/results and are verified; tracker is closed with a handoff.
