# ShopSmart Solution Overview

## 1. Purpose and scope

ShopSmart is a local proof-of-concept retail storefront for personalized product recommendations. It demonstrates synthetic catalog generation, hybrid retrieval, an Azure OpenAI tool-calling agent, live checks against SQLite-backed inventory/pricing stubs, privacy controls, audit records, and a Streamlit shopping flow.

The application is not connected to a real retailer. It has no production identity system, checkout, payment processing, or product administration. Its customer and product data are synthetic. The design source is [`SDD.md`](./SDD.md); the current delivery state and evidence are recorded in [`task_tracker.md`](./task_tracker.md).

## 2. Implemented architecture

```mermaid
flowchart TB
    Shopper --> UI["Streamlit storefront<br/>app/streamlit_app.py"]
    UI --> SVC["RecommendationService<br/>session and recommendation facade"]
    SVC --> PRIV["Masking and pseudonymization"]
    SVC --> AGENT["Bounded RecommendationAgent"]
    AGENT --> LLM["AzureLLMClient"]
    LLM --> AZURE["Azure OpenAI<br/>chat and embeddings"]
    AGENT --> TOOLS["ToolExecutor<br/>4 local function tools"]
    TOOLS --> RETRIEVE["CatalogRetriever"]
    RETRIEVE --> CHROMA[("Chroma<br/>products collection")]
    RETRIEVE --> DB[("SQLite catalog")]
    TOOLS --> SERVICES["SQLite inventory and pricing stubs"]
    SERVICES --> DB
    SVC --> GUARD["Pydantic validation<br/>live stock/price checks"]
    GUARD --> FALLBACK["Popular in-stock fallback"]
    SVC --> LOG["Audit, events, feedback, metrics"]
    LOG --> DB
    GUARD --> UI
    FALLBACK --> UI
```

### Request flow

1. The Streamlit UI starts a pseudonymous session and calls `RecommendationService` for a home, view, or chat recommendation.
2. The service masks user text, builds a consent-appropriate search query, and retrieves seed candidates through Azure embeddings and persistent Chroma. Sparse vector results can be supplemented by SQLite keyword search.
3. In AI mode, `RecommendationAgent` calls Azure chat using the bounded tool loop. `ToolExecutor` exposes `search_catalog`, `check_inventory`, `get_pricing_and_promotions`, and `get_user_profile`.
4. `guardrails.py` parses the structured response, validates its Pydantic model, checks catalog membership, excludes the viewed SKU, rechecks stock and price, and backfills eligible candidates.
5. If generation fails, confidence is below the configured threshold, or no valid cards remain, `fallback.py` selects popular in-stock items. Off-topic responses can return no cards.
6. The service records recommendation impressions and audit data; UI callbacks record views, clicks, add-to-cart events, and feedback. The UI renders verified prices and stock, with category placeholders for missing or unavailable product images.

Refresh after stock or promotion simulation uses the previous candidate pool and rechecks the live stub services without an additional LLM call.

## 3. Components and responsibilities

| Component | Implementation | Responsibility |
|---|---|---|
| Presentation | `app/streamlit_app.py` | Demo account entry, seeded shopper selection, browse/view, cards, chat, simulation controls, metrics, and audit viewer |
| Application facade | `src/retailrec/service.py` | Session creation, recommendation orchestration, refresh, event/feedback APIs, and product browse/details |
| Agent and prompts | `src/retailrec/agent.py`, `src/retailrec/prompts.py` | Bounded Azure chat/tool loop and request context construction |
| Azure integration | `src/retailrec/llm.py` | Single Azure OpenAI client wrapper for chat and embeddings; retries transient failures |
| Retrieval and tools | `src/retailrec/retrieval.py`, `src/retailrec/tools.py` | Chroma/SQLite candidate search and validated execution of the four agent tools |
| Output controls | `src/retailrec/models.py`, `src/retailrec/guardrails.py`, `src/retailrec/fallback.py` | Typed output, live verification, exclusion/backfill, and fallback ranking |
| Privacy | `src/retailrec/privacy.py` | Mask common card/email/phone patterns and known names; create salted pseudonymous IDs; omit profile/history when consent is false |
| Retail stubs | `src/retailrec/services/base.py`, `src/retailrec/services/inventory_stub.py`, `src/retailrec/services/pricing_stub.py` | Protocol contracts and SQLite-backed stock and promotion behavior |
| Persistence/observability | `src/retailrec/db.py`, `src/retailrec/audit.py`, `src/retailrec/events.py` | SQLite schema, audit rows, session events, feedback, and illustrative metrics |
| Data and validation scripts | `scripts/`, `data/eval_set.json` | Synthetic data generation, Chroma index build, smoke checks, and labelled evaluation |

`RecommendationService` currently wires the SQLite stub implementations and rejects `API_BACKEND` values other than `stub`. The inventory and pricing Protocols are interface seams only; the optional HTTP mock API and its clients are not implemented.

## 4. Data and integrations

### Local data

- The default SQLite database is `data/catalog.db`. It stores products, inventory, promotions, customers, sessions, events, feedback, and audit rows.
- `scripts/generate_data.py` rebuilds the database using the configured seed. Default clean-start counts recorded on 2026-11-06 were 50,000 products, 50,000 inventory rows, 300 standing promotions, 12 customers, and 300 synthetic history events.
- The default Chroma path is `data/chroma`; the persistent `products` collection contains 2,000 selected products (40 per subcategory). Embedding vectors are generated in batches through the Azure embedding deployment.
- `data/vocab.json`, `data/personas.json`, and `data/eval_set.json` are source fixtures. The database, Chroma files, and `data/eval_report.json` are generated local artifacts and are ignored.

Catalog contents are generated from a fixed seed, but generated timestamps are based on the current time; do not treat the whole database byte-for-byte as deterministic.

### External and stubbed services

| Integration | Current behavior |
|---|---|
| Azure OpenAI chat | Real Azure SDK call through `AzureLLMClient`; deployment name comes from local configuration |
| Azure OpenAI embeddings | Real Azure SDK call through the same wrapper; used to build the product index and embed search queries |
| Inventory | SQLite stub with simulated latency, live reads, stock-out, and reset operations |
| Pricing/promotions | SQLite stub calculates effective prices and applies the highest active discount; supports flash-sale create/clear |
| Customer/profile history | Synthetic local rows; only consent-appropriate profile fields/events are returned to tools |
| HTTP inventory/pricing API | Deferred and unsupported; no `mock_api` implementation or HTTP clients are present |

## 5. Runtime configuration and privacy

Required local environment variables are `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_CHAT_DEPLOYMENT`, `AZURE_OPENAI_EMBED_DEPLOYMENT`, and `PSEUDO_SALT`. `AZURE_OPENAI_API_VERSION` defaults to `2024-10-21`. Paths and synthetic-data settings have defaults in `src/retailrec/config.py` and the placeholder-only [`.env.example`](./.env.example). Never include real keys or `.env` values in documentation or logs.

The implementation masks payment-card-like numbers, email addresses, phone numbers, and known customer names in user text. Session/event identifiers use a salted SHA-256 pseudonym. The profile tool returns no profile/history when consent is false; seeded customer C12 exercises this path. These are prototype safeguards over synthetic data, not a legal compliance certification or substitute for production consent, retention, access, and deletion controls.

GPT-5-family chat deployments use the Azure-compatible `max_completion_tokens` parameter and minimal reasoning effort while retaining the configured 800-token limit. Other supported chat deployments use the configured temperature/token request shape. The Azure client retries transient rate-limit, connection, and timeout errors; the service uses its popular in-stock fallback on recommendation failures.

## 6. Requirement traceability

The following links the SDD's functional requirements to the implementation and recorded evidence. `PASS` refers to the specified test or demo check; the latest evaluation result is listed separately below.

| SDD requirement | Implementation | Evidence / status |
|---|---|---|
| FR-1 Synthetic data | `scripts/generate_data.py`, `src/retailrec/db.py` | S-02 clean-start counts verified |
| FR-2 Embedded catalog | `scripts/build_index.py`, `src/retailrec/retrieval.py` | S-02 count 2,000; Chroma self-test returned relevant Sports & Outdoors results |
| FR-3 Account, browse, view | `app/streamlit_app.py`, `src/retailrec/events.py` | Streamlit AppTest and browser rehearsal passed |
| FR-4 Home/view recommendations | `src/retailrec/service.py`, `src/retailrec/agent.py`, `src/retailrec/prompts.py` | S-03 and AppTest; clean-start E01–E04/E15 scenarios exercised; E01 failed only the latency check |
| FR-5 Conversational recommendations | `app/streamlit_app.py`, `src/retailrec/agent.py`, `src/retailrec/tools.py` | Browser chat rehearsal and E05–E09 evaluation cases passed in the latest run |
| FR-6 Stock verification | `src/retailrec/guardrails.py`, `src/retailrec/services/inventory_stub.py` | Stock-out/backfill unit and refresh checks; E10 scenario passed |
| FR-7 Price/promotions | `src/retailrec/services/pricing_stub.py`, `src/retailrec/guardrails.py` | Flash-sale unit/refresh checks; E11 scenario passed |
| FR-8 Simulation and refresh | `app/streamlit_app.py`, `src/retailrec/service.py` | Browser rehearsal covered stock mark/reset; refresh tests covered stock and flash sale |
| FR-9 Feedback | `src/retailrec/events.py`, Streamlit card callbacks | Feedback upsert/metrics test and browser rehearsal passed |
| FR-10 Audit | `src/retailrec/audit.py`, `src/retailrec/service.py` | Audit unit checks, S-03, and evaluation audit checks passed |
| FR-11 Privacy/consent | `src/retailrec/privacy.py`, `src/retailrec/tools.py` | Masking/consent unit tests; E12 and E14 scenarios passed |
| FR-12 Structured output | `src/retailrec/models.py`, `src/retailrec/guardrails.py`, `src/retailrec/agent.py` | Schema-validation and retry unit tests passed |
| FR-13 Fallback | `src/retailrec/fallback.py`, `src/retailrec/service.py` | Low-confidence/Azure-error fallback and fail-closed unit tests passed; E13 passed |
| FR-14 Metrics and baseline | `src/retailrec/events.py`, `app/streamlit_app.py` | Metrics test and browser rehearsal passed |
| FR-15 Labelled evaluation | `scripts/run_eval.py`, `data/eval_set.json` | Latest clean-start evaluation: 14/15 (93%), exit 0; E01 latency miss documented |
| FR-16 Optional HTTP API | No current implementation | Deferred; no HTTP backend or T12/T13 tests; `API_BACKEND` must remain `stub` |
| FR-17 Demo account creation | `app/streamlit_app.py`, `src/retailrec/service.py` | Invalid/duplicate/valid account tests and browser rehearsal passed |
| FR-18 Product imagery | `scripts/generate_data.py`, `app/streamlit_app.py` | AppTest verified category placeholder; browser rehearsal rendered available images |

## 7. Verification results and known limitations

Recorded on 2026-11-06:

- Unit tests: **32 passed**; the final documentation verification reran `python -m pytest -q` and passed all 32.
- Smoke tests: **S-01, S-02, and S-03 passed** on the clean-start data and index.
- Demo rehearsal: health endpoint returned HTTP 200; signup, browse, view, chat, imagery, stock-out/reset, feedback, metrics, and audit display were exercised.
- Latest clean-start evaluation: **14/15 (93%)**, exit code **0**, against an **80%** overall threshold. E01 took **15,465 ms**, exceeding the per-case 15,000 ms limit by **465 ms**. The aggregate gate passes, but not every case meets its individual check.

Known boundaries and risks:

- Azure latency and model output are variable; E01 latency missed the hard per-case limit in the latest evaluation.
- The catalog and retail state are synthetic/local. The HTTP API, real retailer integration, production identity, and checkout/payment paths are absent.
- Metrics are illustrative demo counters, not a statistically valid A/B test.
- Product imagery depends on remote URLs; the category placeholder keeps the UI usable when an image is unavailable.
- PII masking and consent handling are limited prototype controls and do not provide legal certification or complete production privacy operations.

## 8. Production path

The following are future directions from the design, not implemented features:

1. Implement authenticated, fail-closed adapters for real inventory/pricing/promotion systems behind the existing service contracts; add integration tests, timeouts, caching, and circuit breakers.
2. Add production identity, consent management, data retention/deletion, encryption, secret management, and appropriate security/privacy reviews.
3. Move the catalog/index to managed infrastructure with incremental product updates, and process real clickstream data only under approved governance.
4. Add deployment, monitoring/tracing, token/latency budgets, larger offline evaluation, and statistically sound online experiments before making conversion claims.

## 9. Related documents

- [`README.md`](./README.md): setup, commands, limitations, and quick start.
- [`WALKTHROUGH.md`](./WALKTHROUGH.md): detailed demo sequence and execution flow.
- [`implementation_plan.md`](./implementation_plan.md): approved project plan.
- [`task_tracker.md`](./task_tracker.md): task states, phase approvals, test results, and handoff.
