"""Semantic and keyword retrieval for the product catalog."""

import re
import sqlite3
from typing import Iterable

import chromadb
from chromadb.config import Settings as ChromaSettings

from retailrec.llm import LLMClient
from retailrec.models import Candidate


class CatalogRetriever:
    """Search the persistent product index and SQLite catalog."""

    def __init__(
        self, llm: LLMClient, conn: sqlite3.Connection, chroma_path: str
    ):
        self.llm = llm
        self.conn = conn
        client = chromadb.PersistentClient(
            path=chroma_path,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        self.collection = client.get_collection("products")

    def search(
        self,
        query: str,
        top_k: int = 10,
        category: str | None = None,
        max_price: float | None = None,
    ) -> list[Candidate]:
        """Return semantic results, filling sparse results with SQL matches."""
        if not query.strip():
            return []
        if not 1 <= top_k <= 15:
            raise ValueError("top_k must be between 1 and 15")
        if max_price is not None and max_price < 0:
            raise ValueError("max_price must not be negative")

        embeddings = self.llm.embed([query])
        if len(embeddings) != 1 or not embeddings[0]:
            raise ValueError("Embedding client returned no query vector")
        conditions: list[dict] = []
        if category is not None:
            conditions.append({"category": category})
        if max_price is not None:
            conditions.append({"base_price": {"$lte": max_price}})
        where = None
        if len(conditions) == 1:
            where = conditions[0]
        elif len(conditions) > 1:
            where = {"$and": conditions}

        response = self.collection.query(
            query_embeddings=embeddings,
            n_results=top_k,
            where=where,
            include=["metadatas", "distances", "documents"],
        )
        vector_hits = self._vector_candidates(response)
        catalog = self.get_candidates_by_sku(
            candidate.sku for candidate in vector_hits
        )
        candidates = [
            catalog[hit.sku].model_copy(
                update={"score": hit.score, "snippet": hit.snippet}
            )
            for hit in vector_hits
            if hit.sku in catalog
        ]
        if len(candidates) >= 3:
            return candidates[:top_k]

        merged = {candidate.sku: candidate for candidate in candidates}
        for candidate in self.keyword_search(
            query, category=category, max_price=max_price, limit=top_k
        ):
            merged.setdefault(candidate.sku, candidate)
            if len(merged) >= top_k:
                break
        return list(merged.values())[:top_k]

    def keyword_search(
        self,
        query: str,
        category: str | None,
        max_price: float | None,
        limit: int = 10,
    ) -> list[Candidate]:
        """Find products matching any query term, ranked by popularity."""
        if limit < 1:
            raise ValueError("limit must be positive")
        terms = list(dict.fromkeys(re.findall(r"[\w'-]+", query.lower())))
        if not terms:
            return []

        predicates: list[str] = []
        params: list[object] = []
        for term in terms:
            predicates.append("(LOWER(name) LIKE ? OR LOWER(tags) LIKE ? OR LOWER(description) LIKE ?)")
            pattern = f"%{term}%"
            params.extend((pattern, pattern, pattern))
        filters = [f"({' OR '.join(predicates)})"]
        if category is not None:
            filters.append("category = ?")
            params.append(category)
        if max_price is not None:
            if max_price < 0:
                raise ValueError("max_price must not be negative")
            filters.append("base_price <= ?")
            params.append(max_price)
        params.append(limit)
        rows = self.conn.execute(
            f"""SELECT sku, name, category, subcategory, base_price,
                       description, popularity
                FROM products WHERE {' AND '.join(filters)}
                ORDER BY popularity DESC, sku LIMIT ?""",
            params,
        ).fetchall()
        return [
            Candidate(
                sku=row["sku"],
                name=row["name"],
                category=row["category"],
                subcategory=row["subcategory"],
                base_price=float(row["base_price"]),
                score=float(row["popularity"]) / 100.0,
                snippet=row["description"],
            )
            for row in rows
        ]

    def get_candidates_by_sku(
        self, skus: Iterable[str]
    ) -> dict[str, Candidate]:
        """Return catalog records for known SKUs only."""
        requested = list(dict.fromkeys(skus))
        if not requested:
            return {}
        placeholders = ",".join("?" for _ in requested)
        rows = self.conn.execute(
            f"""SELECT sku, name, category, subcategory, base_price,
                       description, popularity
                FROM products WHERE sku IN ({placeholders})""",
            requested,
        ).fetchall()
        return {
            row["sku"]: Candidate(
                sku=row["sku"],
                name=row["name"],
                category=row["category"],
                subcategory=row["subcategory"],
                base_price=float(row["base_price"]),
                score=float(row["popularity"]) / 100.0,
                snippet=row["description"],
            )
            for row in rows
        }

    @staticmethod
    def _vector_candidates(response: dict) -> list[Candidate]:
        """Normalize Chroma's nested query result into typed candidates."""
        metadata = (response.get("metadatas") or [[]])[0]
        distances = (response.get("distances") or [[]])[0]
        documents = (response.get("documents") or [[]])[0]
        candidates: list[Candidate] = []
        for index, item in enumerate(metadata):
            if not item or "sku" not in item:
                continue
            distance = distances[index] if index < len(distances) else 1.0
            document = documents[index] if index < len(documents) else ""
            candidates.append(
                Candidate(
                    sku=str(item["sku"]),
                    name=str(item.get("name", "")),
                    category=str(item.get("category", "")),
                    subcategory=str(item.get("subcategory", "")),
                    base_price=float(item.get("base_price", 0)),
                    score=1.0 - float(distance),
                    snippet=document or "",
                )
            )
        return candidates
