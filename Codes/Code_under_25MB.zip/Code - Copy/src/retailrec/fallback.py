"""Popular in-stock product fallback for uncertain or unavailable AI results."""

import sqlite3

from retailrec.models import EnrichedRec, SessionContext
from retailrec.services.base import InventoryService, PricingService


def popular_in_stock(
    ctx: SessionContext,
    conn: sqlite3.Connection,
    inventory: InventoryService,
    pricing: PricingService,
    n: int,
    exclude: set[str],
    origin: str,
) -> list[EnrichedRec]:
    """Return up to ``n`` popular, live-verified products."""
    if n < 1:
        return []
    params: list[object] = []
    category_filter = ""
    if ctx.consent and ctx.preferred_categories:
        placeholders = ",".join("?" for _ in ctx.preferred_categories)
        category_filter = f"WHERE category IN ({placeholders})"
        params.extend(ctx.preferred_categories)
    rows = conn.execute(
        f"""SELECT sku, name, category, subcategory, base_price, popularity
            FROM products {category_filter}
            ORDER BY popularity DESC, sku LIMIT 60""",
        params,
    ).fetchall()
    products = [row for row in rows if row["sku"] not in exclude]
    if not products:
        return []
    stocks = inventory.get_stock(row["sku"] for row in products)
    available = [
        row
        for row in products
        if row["sku"] in stocks and stocks[row["sku"]].status != "out_of_stock"
    ]
    prices = pricing.get_prices(row["sku"] for row in available)
    results: list[EnrichedRec] = []
    for row in available:
        price = prices.get(row["sku"])
        if price is None:
            continue
        rank = len(results) + 1
        results.append(
            EnrichedRec(
                sku=row["sku"],
                name=row["name"],
                category=row["category"],
                subcategory=row["subcategory"],
                rank=rank,
                reason=f"Popular in {row['subcategory']}",
                highlight_promo=price.discount_pct > 0,
                stock=stocks[row["sku"]],
                price=price,
                sources={
                    "rec_id": None,
                    "retrieval_score": None,
                    "tools_used": [],
                    "origin": origin,
                },
            )
        )
        if len(results) >= n:
            break
    return results
