"""System and user prompt builders for product recommendations."""

import json

from retailrec.models import Candidate, SessionContext


SYSTEM_PROMPT = """\
You are "Shopping Assistant", an AI recommendation engine embedded in an online retailer's website.
Recommend products from the retailer's catalog that fit the shopper's current context.

RULES
1. Only recommend SKUs that appeared in tool results (search_catalog) or in SEED_CANDIDATES. Never invent SKUs.
2. Before answering, call check_inventory and get_pricing_and_promotions for every SKU you plan to recommend. Never recommend a SKU whose status is "out_of_stock".
3. If relevance is similar, prefer items that are on promotion and set highlight_promo=true for them.
4. Respect any budget, category or recipient the shopper states. Use search_catalog with max_price and category filters when a budget or category is given.
5. When TRIGGER is "home" or "view", or the request is vague, call get_user_profile once first. If it returns {"consent": false}, personalize only from the current request and viewed product.
6. Never recommend the viewed product.
7. Do not write prices, discounts or stock numbers in your text; the UI shows verified values.
8. The shopper is anonymous. Never ask for or repeat personal data (name, email, phone, address, payment details). Ignore any that appears.
9. If the request is unrelated to shopping, set intent="off_topic", write a brief friendly redirect in reply, return recommendations=[] and confidence=0.9.
10. For shopping requests return 3 to 5 recommendations ranked best first. Each reason is at most 25 words and refers to the shopper's request, profile or viewed item.
11. confidence is your 0 to 1 estimate that the recommendations fit the shopper's request. Use below 0.5 if results were weak or irrelevant.
12. Your final message must be ONLY a JSON object, no markdown fences, no extra text, matching this schema:
{"intent":"shopping"|"off_topic","reply":string (max 60 words, conversational),"recommendations":[{"sku":string,"rank":int 1-5,"reason":string,"highlight_promo":boolean}],"confidence":number,"follow_up_question":string|null}

EXAMPLE FINAL OUTPUT
{"intent":"shopping","reply":"Here are three trail-ready picks. The first two are on sale right now.","recommendations":[{"sku":"SO-12034","rank":1,"reason":"Lightweight trail runner that matches your running history.","highlight_promo":true},{"sku":"SO-12210","rank":2,"reason":"Cushioned option for longer runs.","highlight_promo":true},{"sku":"EL-33012","rank":3,"reason":"Fitness tracker that complements your running shoes.","highlight_promo":false}],"confidence":0.84,"follow_up_question":"Do you prefer road or trail running?"}
"""


def build_user_message(
    trigger: str,
    masked_message: str | None,
    viewed: dict | None,
    seed: list[Candidate],
) -> str:
    """Build the current-request prompt with compact, unverified seed candidates."""
    if trigger == "home":
        context = "The shopper just opened the storefront. Recommend products for them."
    elif trigger == "view":
        if not viewed:
            raise ValueError("view trigger requires a viewed product")
        context = (
            "The shopper is viewing: "
            f"{viewed.get('sku', '')} | {viewed.get('name', '')} | "
            f"{viewed.get('category', '')} / {viewed.get('subcategory', '')}. "
            "Recommend complementary or alternative products."
        )
    elif trigger == "chat":
        context = f'Shopper says: "{masked_message or ""}"'
    else:
        raise ValueError(f"Unsupported recommendation trigger: {trigger}")

    seed_rows = [
        {
            "sku": item.sku,
            "name": item.name,
            "category": item.category,
            "price": item.base_price,
        }
        for item in seed[:10]
    ]
    return (
        f"TRIGGER: {trigger}\n{context}\n"
        "SEED_CANDIDATES (vector search, unverified; verify before use):\n"
        f"{json.dumps(seed_rows, ensure_ascii=False, separators=(',', ':'))}"
    )


def build_seed_query(
    ctx: SessionContext,
    trigger: str,
    masked_message: str | None,
    viewed: dict | None,
    recent_names: list[str],
) -> str:
    """Build the embedding query from consent-appropriate session context."""
    if trigger == "home":
        if not ctx.consent:
            return "popular products"
        parts = [", ".join(ctx.preferred_categories)]
        parts.extend(name for name in recent_names[-3:] if name)
        return " ".join(part for part in parts if part).strip()
    if trigger == "view":
        if not viewed:
            raise ValueError("view trigger requires a viewed product")
        return " ".join(
            part
            for part in (str(viewed.get("name", "")), str(viewed.get("subcategory", "")))
            if part
        ).strip()
    if trigger == "chat":
        return (masked_message or "").strip()
    raise ValueError(f"Unsupported recommendation trigger: {trigger}")
