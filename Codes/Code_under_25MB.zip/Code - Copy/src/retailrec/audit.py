"""Persistence helpers for recommendation audit records."""

from dataclasses import asdict, dataclass
import json
import sqlite3
from uuid import uuid4

from retailrec.db import now_iso


@dataclass
class AuditRecord:
    """Fields captured for one recommendation generation or refresh."""

    rec_id: str
    session_id: str
    pseudo_id: str
    ts: str
    trigger: str
    mode: str
    user_message_masked: str | None = None
    pii_entities_masked: list[str] | None = None
    seed_candidates: list | None = None
    tool_calls: list | None = None
    final_recs: list | None = None
    model_deployment: str | None = None
    iterations: int = 0
    validation_retries: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    latency_ms: int = 0
    confidence: float | None = None
    fallback_used: bool = False
    fallback_reason: str | None = None
    guardrail_flags: list[str] | None = None
    error: str | None = None


class AuditLogger:
    """Write and read recommendation audit entries."""

    _JSON_FIELDS = (
        "pii_entities_masked",
        "seed_candidates",
        "tool_calls",
        "final_recs",
        "guardrail_flags",
    )

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def new_rec_id(self) -> str:
        """Create a short unique recommendation identifier."""
        return uuid4().hex[:12]

    def write(self, rec: AuditRecord) -> None:
        """Persist the supplied audit record."""
        values = asdict(rec)
        for field in self._JSON_FIELDS:
            values[field] = json.dumps(values[field] or [], default=str)
        values["fallback_used"] = int(values["fallback_used"])
        columns = ", ".join(values)
        placeholders = ", ".join("?" for _ in values)
        self.conn.execute(
            f"INSERT INTO audit_log ({columns}) VALUES ({placeholders})",
            tuple(values.values()),
        )
        self.conn.commit()

    def recent(self, n: int = 5) -> list[dict]:
        """Return the latest audit entries without exposing customer identifiers."""
        if n < 1:
            raise ValueError("n must be positive")
        rows = self.conn.execute(
            """SELECT rec_id, ts, trigger, mode, confidence, fallback_used,
                      fallback_reason, guardrail_flags, tool_calls, final_recs,
                      user_message_masked, pii_entities_masked, seed_candidates,
                      model_deployment, iterations, validation_retries,
                      prompt_tokens, completion_tokens, latency_ms, error
               FROM audit_log ORDER BY ts DESC LIMIT ?""",
            (n,),
        ).fetchall()
        return [dict(row) for row in rows]
