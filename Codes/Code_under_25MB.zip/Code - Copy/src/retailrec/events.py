"""Session events, feedback, and illustrative metric calculations."""

import json
import sqlite3
from typing import Literal

from retailrec.db import now_iso
from retailrec.models import SessionContext


EVENT_TYPES = {
    "view",
    "add_to_cart",
    "purchase",
    "rec_impression",
    "rec_click",
    "chat_message",
}


def record_event(
    conn: sqlite3.Connection,
    ctx: SessionContext,
    event_type: str,
    sku: str | None = None,
    rec_id: str | None = None,
    meta: dict | None = None,
) -> None:
    """Persist a pseudonymous event for the active session."""
    if event_type not in EVENT_TYPES:
        raise ValueError(f"Unsupported event type: {event_type}")
    conn.execute(
        """INSERT INTO events
           (pseudo_id, session_id, event_type, sku, rec_id, mode, meta_json, ts)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            ctx.pseudo_id,
            ctx.session_id,
            event_type,
            sku,
            rec_id,
            ctx.mode,
            json.dumps(meta or {}, default=str),
            now_iso(),
        ),
    )
    conn.commit()


def get_recent_events(
    conn: sqlite3.Connection, pseudo_id: str, limit: int = 10
) -> list[dict]:
    """Return recent event details with product names and categories."""
    if limit < 1:
        raise ValueError("limit must be positive")
    rows = conn.execute(
        """SELECT e.event_type, e.sku, p.name, p.category, e.ts
           FROM events e LEFT JOIN products p ON p.sku = e.sku
           WHERE e.pseudo_id = ?
           ORDER BY e.ts DESC, e.event_id DESC LIMIT ?""",
        (pseudo_id, limit),
    ).fetchall()
    return [dict(row) for row in rows]


def record_feedback(
    conn: sqlite3.Connection,
    ctx: SessionContext,
    rec_id: str,
    sku: str,
    value: Literal[-1, 1],
) -> None:
    """Upsert feedback for one recommendation card."""
    if value not in (-1, 1):
        raise ValueError("feedback value must be -1 or 1")
    conn.execute(
        """INSERT INTO feedback
           (session_id, pseudo_id, rec_id, sku, value, ts)
           VALUES (?, ?, ?, ?, ?, ?)
           ON CONFLICT(session_id, rec_id, sku)
           DO UPDATE SET value = excluded.value, ts = excluded.ts""",
        (
            ctx.session_id,
            ctx.pseudo_id,
            rec_id,
            sku,
            value,
            now_iso(),
        ),
    )
    conn.commit()


def compute_metrics(conn: sqlite3.Connection, session_id: str) -> dict:
    """Calculate illustrative counters and rates for each session mode."""
    rows = conn.execute(
        """SELECT mode,
                  SUM(CASE WHEN event_type = 'rec_impression' THEN 1 ELSE 0 END) AS impressions,
                  SUM(CASE WHEN event_type = 'rec_click' THEN 1 ELSE 0 END) AS clicks,
                  SUM(CASE WHEN event_type = 'add_to_cart' THEN 1 ELSE 0 END) AS carts
           FROM events WHERE session_id = ? GROUP BY mode""",
        (session_id,),
    ).fetchall()
    feedback_rows = conn.execute(
        """SELECT s.mode,
                  SUM(CASE WHEN f.value = 1 THEN 1 ELSE 0 END) AS thumbs_up,
                  SUM(CASE WHEN f.value = -1 THEN 1 ELSE 0 END) AS thumbs_down
           FROM feedback f JOIN sessions s ON s.session_id = f.session_id
           WHERE f.session_id = ? GROUP BY s.mode""",
        (session_id,),
    ).fetchall()
    feedback = {row["mode"]: row for row in feedback_rows}
    modes = {}
    for row in rows:
        mode = row["mode"] or "unknown"
        impressions = int(row["impressions"] or 0)
        clicks = int(row["clicks"] or 0)
        carts = int(row["carts"] or 0)
        rated = feedback.get(mode)
        thumbs_up = int(rated["thumbs_up"] or 0) if rated else 0
        thumbs_down = int(rated["thumbs_down"] or 0) if rated else 0
        total_ratings = thumbs_up + thumbs_down
        modes[mode] = {
            "impressions": impressions,
            "clicks": clicks,
            "carts": carts,
            "ctr": clicks / impressions if impressions else 0.0,
            "cart_rate": carts / impressions if impressions else 0.0,
            "thumbs_up": thumbs_up,
            "thumbs_down": thumbs_down,
            "satisfaction": thumbs_up / total_ratings if total_ratings else 0.0,
        }

    started = conn.execute(
        "SELECT started_at FROM sessions WHERE session_id = ?", (session_id,)
    ).fetchone()
    last_event = conn.execute(
        "SELECT MAX(ts) FROM events WHERE session_id = ?", (session_id,)
    ).fetchone()
    duration = 0.0
    if started and last_event and last_event[0]:
        from datetime import datetime

        start_time = datetime.fromisoformat(started["started_at"])
        end_time = datetime.fromisoformat(last_event[0])
        duration = max(0.0, (end_time - start_time).total_seconds())
    return {"by_mode": modes, "session_duration_s": duration}
