"""SQLite connection, schema, and timestamp helpers."""

from datetime import datetime, timezone
from pathlib import Path
import sqlite3

from retailrec.config import get_settings


SCHEMA = """
CREATE TABLE IF NOT EXISTS products (
  sku TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL,
  category TEXT NOT NULL, subcategory TEXT NOT NULL, brand TEXT NOT NULL,
  base_price REAL NOT NULL, tags TEXT NOT NULL, rating REAL NOT NULL,
  popularity REAL NOT NULL, embedded INTEGER NOT NULL DEFAULT 0, image_url TEXT);
CREATE INDEX IF NOT EXISTS idx_products_cat_pop ON products(category, popularity DESC);
CREATE INDEX IF NOT EXISTS idx_products_subcat ON products(subcategory);
CREATE TABLE IF NOT EXISTS inventory (
  sku TEXT PRIMARY KEY REFERENCES products(sku), stock_qty INTEGER NOT NULL,
  initial_qty INTEGER NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS promotions (
  promo_id TEXT PRIMARY KEY,
  scope_type TEXT NOT NULL CHECK(scope_type IN ('sku','category')),
  scope_value TEXT NOT NULL, discount_pct REAL NOT NULL, label TEXT NOT NULL,
  is_flash INTEGER NOT NULL DEFAULT 0, starts_at TEXT NOT NULL, ends_at TEXT);
CREATE INDEX IF NOT EXISTS idx_promos_scope ON promotions(scope_type, scope_value);
CREATE TABLE IF NOT EXISTS customers (
  customer_id TEXT PRIMARY KEY, display_name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
  persona TEXT NOT NULL, age_band TEXT NOT NULL, region TEXT NOT NULL,
  preferred_categories TEXT NOT NULL, price_sensitivity TEXT NOT NULL,
  consent_personalization INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (
  session_id TEXT PRIMARY KEY, pseudo_id TEXT NOT NULL, mode TEXT NOT NULL,
  started_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events (
  event_id INTEGER PRIMARY KEY AUTOINCREMENT, pseudo_id TEXT NOT NULL,
  session_id TEXT, event_type TEXT NOT NULL, sku TEXT, rec_id TEXT,
  mode TEXT, meta_json TEXT, ts TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_events_pseudo ON events(pseudo_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_events_session ON events(session_id, event_type);
CREATE TABLE IF NOT EXISTS feedback (
  feedback_id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL,
  pseudo_id TEXT NOT NULL, rec_id TEXT NOT NULL, sku TEXT NOT NULL,
  value INTEGER NOT NULL CHECK(value IN (-1,1)), ts TEXT NOT NULL,
  UNIQUE(session_id, rec_id, sku));
CREATE TABLE IF NOT EXISTS audit_log (
  rec_id TEXT PRIMARY KEY, session_id TEXT NOT NULL, pseudo_id TEXT NOT NULL,
  ts TEXT NOT NULL, trigger TEXT NOT NULL, mode TEXT NOT NULL,
  user_message_masked TEXT, pii_entities_masked TEXT, seed_candidates TEXT,
  tool_calls TEXT, final_recs TEXT, model_deployment TEXT, iterations INTEGER,
  validation_retries INTEGER, prompt_tokens INTEGER, completion_tokens INTEGER,
  latency_ms INTEGER, confidence REAL, fallback_used INTEGER NOT NULL DEFAULT 0,
  fallback_reason TEXT, guardrail_flags TEXT, error TEXT);
"""

DROP_SCHEMA = """
DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS feedback;
DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS sessions;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS promotions;
DROP TABLE IF EXISTS inventory;
DROP TABLE IF EXISTS products;
"""


def get_conn(db_path: str | None = None) -> sqlite3.Connection:
    """Open a thread-compatible SQLite connection and configure WAL."""
    path = db_path or get_settings().db_path
    if path != ":memory:":
        Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_schema(conn: sqlite3.Connection, *, reset: bool = False) -> None:
    """Create the application schema, optionally dropping existing tables."""
    if reset:
        conn.executescript(DROP_SCHEMA)
    conn.executescript(SCHEMA)
    conn.commit()


def now_iso() -> str:
    """Return a seconds-precision UTC timestamp in ISO-8601 format."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
