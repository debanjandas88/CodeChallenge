"""Application facade for sessions, recommendations, events, and metrics."""

import logging
import sqlite3
from time import perf_counter
from typing import Literal
from uuid import uuid4

from retailrec.agent import AgentRun, RecommendationAgent
from retailrec.audit import AuditLogger, AuditRecord
from retailrec.config import Settings, get_settings
from retailrec.db import get_conn, now_iso
from retailrec.events import (
    compute_metrics,
    get_recent_events,
    record_event,
    record_feedback,
)
from retailrec.fallback import popular_in_stock
from retailrec.guardrails import enforce_live_constraints, revalidate
from retailrec.llm import AzureLLMClient, LLMClient
from retailrec.models import EnrichedRec, RecResult, SessionContext
from retailrec.prompts import build_seed_query, build_user_message
from retailrec.privacy import mask_text, pseudonymize
from retailrec.retrieval import CatalogRetriever
from retailrec.services.inventory_stub import SqliteInventoryService
from retailrec.services.pricing_stub import SqlitePricingService
from retailrec.tools import ToolExecutor


logger = logging.getLogger(__name__)


class RecommendationService:
    """Wire persistence, Azure, retrieval, live stubs, and recommendation flows."""

    def __init__(
        self,
        settings: Settings | None = None,
        llm: LLMClient | None = None,
        conn: sqlite3.Connection | None = None,
    ):
        self.settings = settings or get_settings()
        if self.settings.api_backend != "stub":
            raise ValueError(
                "Only API_BACKEND=stub is implemented; the optional HTTP API is deferred."
            )
        self.conn = conn or get_conn(self.settings.db_path)
        self.llm = llm or AzureLLMClient(self.settings)
        self.retriever = CatalogRetriever(
            self.llm, self.conn, self.settings.chroma_path
        )
        self.inventory = SqliteInventoryService(
            self.conn,
            self.settings.stub_latency_ms,
            self.settings.low_stock_threshold,
        )
        self.pricing = SqlitePricingService(
            self.conn, self.settings.stub_latency_ms
        )
        self.audit = AuditLogger(self.conn)
        self.agent = RecommendationAgent(self.llm, self.settings)

    def list_customers(self) -> list[dict]:
        """List demo customers without exposing direct identifiers."""
        rows = self.conn.execute(
            "SELECT customer_id, persona FROM customers ORDER BY customer_id"
        ).fetchall()
        return [dict(row) for row in rows]

    def start_session(
        self, customer_id: str, mode: Literal["ai", "baseline"] = "ai"
    ) -> SessionContext:
        """Create a pseudonymous session for a seeded demo customer."""
        if mode not in {"ai", "baseline"}:
            raise ValueError("mode must be 'ai' or 'baseline'")
        customer = self.conn.execute(
            """SELECT customer_id, persona, region, age_band,
                      preferred_categories, price_sensitivity,
                      consent_personalization
               FROM customers WHERE customer_id = ?""",
            (customer_id,),
        ).fetchone()
        if customer is None:
            raise KeyError(f"Unknown customer: {customer_id}")
        preferred = [
            category.strip()
            for category in customer["preferred_categories"].split(",")
            if category.strip()
        ]
        started_at = now_iso()
        ctx = SessionContext(
            session_id=f"s_{uuid4().hex[:12]}",
            pseudo_id=pseudonymize(customer_id, self.settings.pseudo_salt),
            customer_id=customer_id,
            mode=mode,
            persona=customer["persona"],
            preferred_categories=preferred,
            price_sensitivity=customer["price_sensitivity"],
            consent=bool(customer["consent_personalization"]),
            started_at=started_at,
        )
        self.conn.execute(
            "INSERT INTO sessions (session_id, pseudo_id, mode, started_at) VALUES (?, ?, ?, ?)",
            (ctx.session_id, ctx.pseudo_id, ctx.mode, started_at),
        )
        self.conn.commit()
        return ctx

    def recommend(
        self,
        ctx: SessionContext,
        trigger: Literal["home", "view", "chat"],
        message: str | None = None,
        viewed_sku: str | None = None,
        history: list[dict] | None = None,
    ) -> RecResult:
        """Return recommendations without propagating runtime failures."""
        started = perf_counter()
        rec_id = self.audit.new_rec_id()
        masked_message = ""
        pii_entities: list[str] = []
        seed_candidates: list[dict] = []
        executor: ToolExecutor | None = None
        run: AgentRun | None = None
        flags: list[str] = []
        exclude = {viewed_sku} if viewed_sku else set()
        fallback_used = False
        fallback_reason: str | None = None
        confidence: float | None = None
        items = []
        reply = ""
        intent = "shopping"
        error: str | None = None

        try:
            if trigger not in {"home", "view", "chat"}:
                raise ValueError("Unsupported recommendation trigger")
            customer = self.conn.execute(
                "SELECT display_name FROM customers WHERE customer_id = ?",
                (ctx.customer_id,),
            ).fetchone()
            known_names = [customer["display_name"]] if customer else []
            masked_message, pii_entities = mask_text(message or "", known_names)
            if trigger == "chat":
                record_event(
                    self.conn,
                    ctx,
                    "chat_message",
                    meta={
                        "message_masked": masked_message,
                        "pii_entities_masked": pii_entities,
                    },
                )
            viewed = self._get_viewed_product(viewed_sku) if trigger == "view" else None
            if trigger == "view" and viewed is None:
                raise KeyError("Viewed product was not found")

            if ctx.mode == "baseline":
                items = popular_in_stock(
                    ctx,
                    self.conn,
                    self.inventory,
                    self.pricing,
                    self.settings.top_n,
                    exclude,
                    "baseline",
                )
                reply = "Popular picks for you."
            else:
                recent_names = self._recent_view_names(ctx)
                seed_query = build_seed_query(
                    ctx, trigger, masked_message, viewed, recent_names
                )
                seed = self.retriever.search(seed_query, top_k=10)
                seed_candidates = [
                    {
                        "sku": item.sku,
                        "name": item.name,
                        "category": item.category,
                        "score": item.score,
                    }
                    for item in seed
                ]
                executor = ToolExecutor(
                    self.retriever,
                    self.inventory,
                    self.pricing,
                    self.conn,
                    ctx,
                    self.settings,
                )
                executor.pool.update(
                    {item.sku: item.score for item in seed}
                )
                run = self.agent.run(
                    executor,
                    build_user_message(trigger, masked_message, viewed, seed),
                    self._safe_history(history, known_names),
                )
                flags.extend(run.flags)
                if run.output is None:
                    fallback_reason = run.error or "agent_failed"
                    items, fallback_reason, fallback_used, fallback_flags = (
                        self._fallback(ctx, exclude, fallback_reason)
                    )
                    flags.extend(fallback_flags)
                    reply = self._fallback_reply(items)
                else:
                    output = run.output
                    reply = output.reply
                    confidence = output.confidence
                    intent = output.intent
                    if output.intent == "off_topic":
                        items = []
                    elif output.confidence < self.settings.confidence_threshold:
                        fallback_reason = "low_confidence"
                        items, fallback_reason, fallback_used, fallback_flags = (
                            self._fallback(ctx, exclude, fallback_reason)
                        )
                        flags.extend(fallback_flags)
                        confidence = None
                        reply = self._fallback_reply(items)
                    else:
                        tools_used = [
                            call["name"] for call in executor.calls
                        ]
                        items, guardrail_flags = enforce_live_constraints(
                            output,
                            executor.pool,
                            self.retriever,
                            self.inventory,
                            self.pricing,
                            self.settings.top_n,
                            exclude,
                            rec_id,
                            tools_used,
                        )
                        flags.extend(guardrail_flags)
                        if not items:
                            fallback_reason = "empty_after_guardrails"
                            items, fallback_reason, fallback_used, fallback_flags = (
                                self._fallback(ctx, exclude, fallback_reason)
                            )
                            flags.extend(fallback_flags)
                            confidence = None
                            reply = self._fallback_reply(items)
            items = self._attach_rec_id(items, rec_id)
        except Exception as exc:
            error = type(exc).__name__
            logger.error("Recommendation failed (%s)", error)
            fallback_reason = error
            items, fallback_reason, fallback_used, fallback_flags = self._fallback(
                ctx, exclude, fallback_reason
            )
            flags.extend(fallback_flags)
            reply = self._fallback_reply(items)
            items = self._attach_rec_id(items, rec_id)
            confidence = None
            intent = "shopping"

        flags = list(dict.fromkeys(flags))
        try:
            for item in items:
                record_event(
                    self.conn,
                    ctx,
                    "rec_impression",
                    sku=item.sku,
                    rec_id=rec_id,
                )
        except Exception as exc:
            error = type(exc).__name__
            logger.error("Recommendation impression logging failed (%s)", error)
            items = []
            reply = "Recommendations are temporarily unavailable."
            confidence = None
            fallback_used = True
            fallback_reason = "event_logging_unavailable"
            intent = "shopping"
            flags.append("event_logging_unavailable")

        latency_ms = round((perf_counter() - started) * 1000)
        try:
            self.audit.write(
                AuditRecord(
                    rec_id=rec_id,
                    session_id=ctx.session_id,
                    pseudo_id=ctx.pseudo_id,
                    ts=now_iso(),
                    trigger=trigger,
                    mode=ctx.mode,
                    user_message_masked=masked_message if trigger == "chat" else None,
                    pii_entities_masked=pii_entities if trigger == "chat" else [],
                    seed_candidates=seed_candidates,
                    tool_calls=executor.calls if executor else [],
                    final_recs=[item.sku for item in items],
                    model_deployment=(
                        self.settings.chat_deployment
                        if ctx.mode == "ai"
                        else None
                    ),
                    iterations=run.iterations if run else 0,
                    validation_retries=run.validation_retries if run else 0,
                    prompt_tokens=run.prompt_tokens if run else 0,
                    completion_tokens=run.completion_tokens if run else 0,
                    latency_ms=latency_ms,
                    confidence=confidence,
                    fallback_used=fallback_used,
                    fallback_reason=fallback_reason,
                    guardrail_flags=flags,
                    error=(run.error if run and run.error else error),
                )
            )
        except Exception as exc:
            logger.error("Recommendation audit write failed (%s)", type(exc).__name__)
            items = []
            reply = "Recommendations are temporarily unavailable."
            confidence = None
            fallback_used = True
            fallback_reason = "audit_unavailable"
            flags.append("audit_unavailable")

        return RecResult(
            rec_id=rec_id,
            trigger=trigger,
            mode=ctx.mode,
            reply=reply,
            items=items,
            confidence=confidence,
            fallback_used=fallback_used,
            fallback_reason=fallback_reason,
            latency_ms=latency_ms,
            pool=(
                [
                    sku
                    for sku, _ in sorted(
                        executor.pool.items(),
                        key=lambda pair: (-pair[1], pair[0]),
                    )
                ]
                if executor
                else []
            ),
            exclude=sorted(exclude),
            flags=list(dict.fromkeys(flags)),
            intent=intent,
        )

    def refresh(self, ctx: SessionContext, last: RecResult) -> RecResult:
        """Revalidate a previous result without making another LLM call."""
        started = perf_counter()
        rec_id = self.audit.new_rec_id()
        items = []
        flags: list[str] = []
        fallback_used = False
        fallback_reason = None
        error = None
        try:
            items, flags = revalidate(
                last.items,
                last.pool,
                self.retriever,
                self.inventory,
                self.pricing,
                self.settings.top_n,
                set(last.exclude),
                rec_id,
                [],
            )
            if not items:
                fallback_reason = "empty_after_guardrails"
                items, fallback_reason, fallback_used, fallback_flags = self._fallback(
                    ctx, set(last.exclude), fallback_reason
                )
                flags.extend(fallback_flags)
            elif not last.pool:
                target = min(
                    self.settings.top_n,
                    max(3, len(last.items)),
                )
                if len(items) < target:
                    fallback_items, fallback_reason, fallback_used, fallback_flags = (
                        self._fallback(
                            ctx,
                            set(last.exclude) | {item.sku for item in items},
                            "refresh_backfill",
                        )
                    )
                    flags.extend(fallback_flags)
                    items.extend(fallback_items[: target - len(items)])
            items = self._attach_rec_id(items, rec_id)
        except Exception as exc:
            error = type(exc).__name__
            logger.error("Recommendation refresh failed (%s)", error)
            items, fallback_reason, fallback_used, fallback_flags = self._fallback(
                ctx, set(last.exclude), error
            )
            flags.extend(fallback_flags)
            items = self._attach_rec_id(items, rec_id)
        new_skus = {item.sku for item in last.items}
        try:
            for item in items:
                if item.sku not in new_skus:
                    record_event(
                        self.conn,
                        ctx,
                        "rec_impression",
                        sku=item.sku,
                        rec_id=rec_id,
                    )
        except Exception as exc:
            error = type(exc).__name__
            logger.error("Refresh impression logging failed (%s)", error)
            items = []
            fallback_used = True
            fallback_reason = "event_logging_unavailable"
            flags.append("event_logging_unavailable")
        latency_ms = round((perf_counter() - started) * 1000)
        try:
            self.audit.write(
                AuditRecord(
                    rec_id=rec_id,
                    session_id=ctx.session_id,
                    pseudo_id=ctx.pseudo_id,
                    ts=now_iso(),
                    trigger="refresh",
                    mode=ctx.mode,
                    final_recs=[item.sku for item in items],
                    iterations=0,
                    latency_ms=latency_ms,
                    confidence=last.confidence,
                    fallback_used=fallback_used,
                    fallback_reason=fallback_reason,
                    guardrail_flags=flags,
                    error=error,
                )
            )
        except Exception as exc:
            logger.error("Refresh audit write failed (%s)", type(exc).__name__)
            items = []
            fallback_used = True
            fallback_reason = "audit_unavailable"
            flags.append("audit_unavailable")
        return RecResult(
            rec_id=rec_id,
            trigger="refresh",
            mode=ctx.mode,
            reply=self._fallback_reply(items) if fallback_used else last.reply,
            items=items,
            confidence=last.confidence,
            fallback_used=fallback_used,
            fallback_reason=fallback_reason,
            latency_ms=latency_ms,
            pool=list(last.pool),
            exclude=list(last.exclude),
            flags=list(dict.fromkeys(flags)),
            intent=last.intent,
        )

    def record_click(self, ctx: SessionContext, rec_id: str, sku: str) -> None:
        """Record a recommendation-card click."""
        record_event(self.conn, ctx, "rec_click", sku=sku, rec_id=rec_id)

    def record_view(self, ctx: SessionContext, sku: str) -> None:
        """Record a shopper opening a product detail view."""
        record_event(self.conn, ctx, "view", sku=sku)

    def add_to_cart(self, ctx: SessionContext, rec_id: str, sku: str) -> None:
        """Record an add-to-cart action."""
        record_event(self.conn, ctx, "add_to_cart", sku=sku, rec_id=rec_id)

    def feedback(
        self, ctx: SessionContext, rec_id: str, sku: str, value: int
    ) -> None:
        """Store a shopper's up/down feedback for one card."""
        if value not in (-1, 1):
            raise ValueError("feedback value must be -1 or 1")
        selected: Literal[-1, 1] = -1 if value == -1 else 1
        record_feedback(self.conn, ctx, rec_id, sku, selected)

    def metrics(self, ctx: SessionContext) -> dict:
        """Return illustrative metrics for the active session."""
        return compute_metrics(self.conn, ctx.session_id)

    def browse(self, category: str, limit: int = 12) -> list[dict]:
        """List popular, currently available catalog items in one category."""
        if limit < 1:
            raise ValueError("limit must be positive")
        rows = self.conn.execute(
            """SELECT sku, name, description, category, subcategory, brand,
                      base_price, tags, rating, popularity, image_url
               FROM products WHERE category = ?
               ORDER BY popularity DESC, sku LIMIT ?""",
            (category, max(limit * 10, limit)),
        ).fetchall()
        stocks = self.inventory.get_stock(row["sku"] for row in rows)
        available = [
            row
            for row in rows
            if row["sku"] in stocks and stocks[row["sku"]].status != "out_of_stock"
        ]
        prices = self.pricing.get_prices(row["sku"] for row in available)
        products: list[dict] = []
        for row in available:
            if row["sku"] not in prices:
                continue
            product = dict(row)
            product["stock"] = stocks[row["sku"]]
            product["price"] = prices[row["sku"]]
            products.append(product)
            if len(products) >= limit:
                break
        return products

    def product_details(self, sku: str) -> dict | None:
        """Return catalog details with live stock and price for one SKU."""
        row = self.conn.execute(
            """SELECT sku, name, description, category, subcategory, brand,
                      base_price, tags, rating, popularity, image_url
               FROM products WHERE sku = ?""",
            (sku,),
        ).fetchone()
        if row is None:
            return None
        stock = self.inventory.get_stock([sku]).get(sku)
        price = self.pricing.get_prices([sku]).get(sku)
        product = dict(row)
        product["stock"] = stock
        product["price"] = price
        return product

    def product_image_url(self, sku: str) -> str | None:
        """Return the catalog image reference without requiring live service calls."""
        row = self.conn.execute(
            "SELECT image_url FROM products WHERE sku = ?", (sku,)
        ).fetchone()
        return row["image_url"] if row else None

    def _recent_view_names(self, ctx: SessionContext) -> list[str]:
        recent = get_recent_events(self.conn, ctx.pseudo_id, limit=30)
        return [
            event["name"]
            for event in recent
            if event["event_type"] == "view" and event["name"]
        ][:3]

    def _get_viewed_product(self, sku: str | None) -> dict | None:
        if not sku:
            return None
        row = self.conn.execute(
            """SELECT sku, name, category, subcategory
               FROM products WHERE sku = ?""",
            (sku,),
        ).fetchone()
        return dict(row) if row else None

    @staticmethod
    def _safe_history(
        history: list[dict] | None, known_names: list[str]
    ) -> list[dict]:
        safe: list[dict] = []
        for message in (history or [])[-12:]:
            role = message.get("role")
            content = message.get("content")
            if role in {"user", "assistant"} and isinstance(content, str):
                safe_content, _ = mask_text(content, known_names)
                safe.append({"role": role, "content": safe_content})
        return safe

    def _fallback(
        self, ctx: SessionContext, exclude: set[str], reason: str
    ) -> tuple[list[EnrichedRec], str, bool, list[str]]:
        try:
            items = popular_in_stock(
                ctx,
                self.conn,
                self.inventory,
                self.pricing,
                self.settings.top_n,
                exclude,
                "fallback",
            )
            return items, reason, True, []
        except Exception as exc:
            logger.error("Live fallback unavailable (%s)", type(exc).__name__)
            return [], "inventory_unavailable", True, ["inventory_unavailable"]

    @staticmethod
    def _fallback_reply(items: list[EnrichedRec]) -> str:
        if items:
            return "Here are some popular picks you may like."
        return "Live inventory is temporarily unavailable. Please try again."

    @staticmethod
    def _attach_rec_id(items: list[EnrichedRec], rec_id: str) -> list[EnrichedRec]:
        updated = []
        for item in items:
            sources = dict(item.sources)
            sources["rec_id"] = rec_id
            updated.append(item.model_copy(update={"sources": sources}))
        return updated
