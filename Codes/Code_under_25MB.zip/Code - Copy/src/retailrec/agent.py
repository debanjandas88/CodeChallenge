"""Bounded tool-calling recommendation agent."""

from dataclasses import dataclass, field
import json

from retailrec.config import Settings
from retailrec.guardrails import ValidationFailed, parse_and_validate
from retailrec.llm import LLMClient, LLMUnavailable
from retailrec.models import AgentOutput
from retailrec.prompts import SYSTEM_PROMPT
from retailrec.tools import TOOL_SPECS, ToolExecutor


@dataclass
class AgentRun:
    """Outcome and usage metadata for one agent execution."""

    output: AgentOutput | None = None
    tool_calls: list[dict] = field(default_factory=list)
    iterations: int = 0
    validation_retries: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    error: str | None = None
    pool: dict[str, float] = field(default_factory=dict)
    flags: list[str] = field(default_factory=list)


class RecommendationAgent:
    """Run the bounded Azure chat/tool loop for a single recommendation."""

    def __init__(self, llm: LLMClient, settings: Settings):
        self.llm = llm
        self.settings = settings

    def run(
        self,
        executor: ToolExecutor,
        user_message_text: str,
        history: list[dict] | None = None,
    ) -> AgentRun:
        """Call the model within iteration, tool-call, and validation budgets."""
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        messages.extend((history or [])[-12:])
        messages.append({"role": "user", "content": user_message_text})
        run = AgentRun()
        calls = 0

        for iteration in range(self.settings.agent_max_iterations):
            choice = (
                "none"
                if iteration == self.settings.agent_max_iterations - 1
                else "auto"
            )
            run.iterations = iteration + 1
            try:
                response = self.llm.chat(
                    messages,
                    tools=TOOL_SPECS,
                    tool_choice=choice,
                    temperature=self.settings.agent_temperature,
                    max_tokens=self.settings.agent_max_tokens,
                )
            except LLMUnavailable:
                run.error = "LLMUnavailable"
                break
            run.prompt_tokens += response.prompt_tokens
            run.completion_tokens += response.completion_tokens

            if response.tool_calls and choice != "none":
                messages.append(
                    {
                        "role": "assistant",
                        "content": response.content or "",
                        "tool_calls": [
                            {
                                "id": tool_call.id,
                                "type": "function",
                                "function": {
                                    "name": tool_call.name,
                                    "arguments": tool_call.arguments,
                                },
                            }
                            for tool_call in response.tool_calls
                        ],
                    }
                )
                for tool_call in response.tool_calls:
                    calls += 1
                    if calls > self.settings.agent_max_tool_calls:
                        run.error = "tool_budget_exceeded"
                        run.flags.append("tool_budget_exceeded")
                        break
                    result = executor.execute(
                        tool_call.name, tool_call.arguments
                    )
                    run.tool_calls = list(executor.calls)
                    messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": tool_call.id,
                            "content": json.dumps(result, default=str),
                        }
                    )
                if run.error:
                    break
                continue

            try:
                run.output = parse_and_validate(response.content)
                break
            except ValidationFailed as exc:
                if run.validation_retries >= self.settings.validation_max_retries:
                    run.error = "validation_failed"
                    break
                run.validation_retries += 1
                messages.extend(
                    [
                        {
                            "role": "assistant",
                            "content": response.content or "",
                        },
                        {
                            "role": "user",
                            "content": (
                                "Your previous answer was invalid: "
                                f"{exc}. Return ONLY a valid JSON object matching the schema."
                            ),
                        },
                    ]
                )
        else:
            run.error = "max_iterations"

        run.tool_calls = list(executor.calls)
        run.pool = dict(executor.pool)
        run.flags.extend(flag for flag in executor.flags if flag not in run.flags)
        return run
