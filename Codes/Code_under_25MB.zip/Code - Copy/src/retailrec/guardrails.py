"""Structured-output validation and live recommendation constraints."""

import json
import re
from typing import Any

from pydantic import ValidationError

from retailrec.models import (
    AgentOutput,
    Candidate,
    EnrichedRec,
    Recommendation,
)


class ValidationFailed(Exception):
    """Raised when an LLM response does not match the output contract."""


def parse_and_validate(raw: str | None) -> AgentOutput:
    """Parse JSON or fenced JSON and validate it against the output model."""
    if not raw or not raw.strip():
        raise ValidationFailed("empty response")
    content = raw.strip()
    fenced = re.fullmatch(r"```(?:json)?\s*(.*?)\s*```", content, re.DOTALL | re.IGNORECASE)
    if fenced:
        content = fenced.group(1).strip()
    try:
        value = json.loads(content)
        if not isinstance(value, dict):
            raise ValueError("response must be a JSON object")
        return AgentOutput.model_validate(value)
    except (json.JSONDecodeError, ValueError, ValidationError) as exc:
        raise ValidationFailed(str(exc)[:300]) from exc


def enforce_live_constraints(
    out: AgentOutput,
    pool: dict[str, float],
    retriever: Any,
    inventory: Any,
    pricing: Any,
    top_n: int,
    exclude: set[str],
    rec_id: str,
    tools_used: list[str],
) -> tuple[list[EnrichedRec], list[str]]:
    """Remove invalid recommendations and backfill from verified retrieval candidates."""
    if top_n < 1:
        raise ValueError("top_n must be positive")
    original = sorted(out.recommendations, key=lambda item: item.rank)
    target = min(top_n, max(3, len(original)))
    proposed_skus = [item.sku for item in original]
    pool_skus = [
        sku for sku, _ in sorted(pool.items(), key=lambda pair: (-pair[1], pair[0]))
    ]
    catalog = retriever.get_candidates_by_sku(
        list(dict.fromkeys(proposed_skus + pool_skus))
    )
    flags: list[str] = []
    seen: set[str] = set()
    valid_proposals: list[tuple[Recommendation, Candidate]] = []
    for recommendation in original:
        sku = recommendation.sku
        if sku in seen:
            flags.append(f"duplicate:{sku}")
            continue
        seen.add(sku)
        if sku not in catalog:
            flags.append(f"hallucinated_sku:{sku}")
        elif sku in exclude:
            flags.append(f"excluded:{sku}")
        else:
            valid_proposals.append((recommendation, catalog[sku]))

    eligible_skus = [candidate.sku for _, candidate in valid_proposals]
    stock = inventory.get_stock(eligible_skus) if eligible_skus else {}
    prices = pricing.get_prices(eligible_skus) if eligible_skus else {}
    enriched: list[EnrichedRec] = []
    for recommendation, candidate in valid_proposals:
        if len(enriched) >= top_n:
            break
        live_stock = stock.get(candidate.sku)
        if live_stock is None or live_stock.status == "out_of_stock":
            flags.append(f"removed_oos:{candidate.sku}")
            continue
        price = prices.get(candidate.sku)
        if price is None:
            flags.append(f"no_price:{candidate.sku}")
            continue
        enriched.append(
            _enriched(
                candidate,
                recommendation.reason,
                len(enriched) + 1,
                live_stock,
                price,
                rec_id,
                pool.get(candidate.sku),
                tools_used,
                "agent",
            )
        )

    for sku in pool_skus:
        if len(enriched) >= target:
            break
        if sku in seen or sku in exclude:
            continue
        seen.add(sku)
        candidate = catalog.get(sku)
        if candidate is None:
            flags.append(f"hallucinated_sku:{sku}")
            continue
        live_stock = inventory.get_stock([sku]).get(sku)
        if live_stock is None or live_stock.status == "out_of_stock":
            flags.append(f"removed_oos:{sku}")
            continue
        price = pricing.get_prices([sku]).get(sku)
        if price is None:
            flags.append(f"no_price:{sku}")
            continue
        flags.append(f"backfilled:{sku}")
        enriched.append(
            _enriched(
                candidate,
                "A popular alternative matching your request.",
                len(enriched) + 1,
                live_stock,
                price,
                rec_id,
                pool.get(sku),
                tools_used,
                "backfill",
            )
        )
    return enriched, flags


def revalidate(
    items: list[EnrichedRec],
    pool: list[str],
    retriever: Any,
    inventory: Any,
    pricing: Any,
    top_n: int,
    exclude: set[str],
    rec_id: str,
    tools_used: list[str] | None = None,
) -> tuple[list[EnrichedRec], list[str]]:
    """Re-check existing cards and refill from the prior candidate pool."""
    prior = {item.sku: item for item in items}
    scores = {
        sku: float(prior[sku].sources.get("retrieval_score") or 0.0)
        for sku in prior
    }
    for sku in pool:
        scores.setdefault(sku, 0.0)
    output = AgentOutput(
        intent="shopping",
        reply="Refreshing live product details.",
        confidence=1.0,
        recommendations=[
            Recommendation(
                sku=item.sku,
                rank=item.rank,
                reason=item.reason,
                highlight_promo=item.highlight_promo,
            )
            for item in items[:5]
        ],
    )
    refreshed, flags = enforce_live_constraints(
        output,
        scores,
        retriever,
        inventory,
        pricing,
        top_n,
        exclude,
        rec_id,
        tools_used or [],
    )
    for index, item in enumerate(refreshed):
        previous = prior.get(item.sku)
        if previous is not None:
            sources = dict(item.sources)
            sources["origin"] = previous.sources.get("origin", "agent")
            refreshed[index] = item.model_copy(update={"sources": sources})
    return refreshed, flags


def _enriched(
    candidate: Candidate,
    reason: str,
    rank: int,
    stock: Any,
    price: Any,
    rec_id: str,
    retrieval_score: float | None,
    tools_used: list[str],
    origin: str,
) -> EnrichedRec:
    return EnrichedRec(
        sku=candidate.sku,
        name=candidate.name,
        category=candidate.category,
        subcategory=candidate.subcategory,
        rank=rank,
        reason=reason,
        highlight_promo=price.discount_pct > 0,
        stock=stock,
        price=price,
        sources={
            "rec_id": rec_id,
            "retrieval_score": retrieval_score,
            "tools_used": list(tools_used),
            "origin": origin,
        },
    )
