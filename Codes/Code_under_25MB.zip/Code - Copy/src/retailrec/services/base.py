"""Protocols and errors for swappable retail services."""

from typing import Iterable, Protocol

from retailrec.models import PriceInfo, StockInfo


class ServiceUnavailable(Exception):
    """Raised when stock or price information cannot be verified."""


class InventoryService(Protocol):
    """Read live inventory for product SKUs."""

    def get_stock(self, skus: Iterable[str]) -> dict[str, StockInfo]: ...


class PricingService(Protocol):
    """Read effective prices and active promotions."""

    def get_prices(self, skus: Iterable[str]) -> dict[str, PriceInfo]: ...
