"""SQLite-backed live inventory stub."""

import sqlite3
from time import sleep
from typing import Iterable

from retailrec.db import now_iso
from retailrec.models import StockInfo


class SqliteInventoryService:
    """SQLite inventory reader and demo stock simulator."""

    def __init__(
        self, conn: sqlite3.Connection, latency_ms: int, low_threshold: int
    ):
        self.conn = conn
        self.latency_ms = latency_ms
        self.low_threshold = low_threshold

    def get_stock(self, skus: Iterable[str]) -> dict[str, StockInfo]:
        """Return stock state for requested SKUs; unknown products are out of stock."""
        requested = list(dict.fromkeys(skus))
        if self.latency_ms > 0:
            sleep(self.latency_ms / 1000)
        if not requested:
            return {}
        placeholders = ",".join("?" for _ in requested)
        rows = self.conn.execute(
            f"SELECT sku, stock_qty FROM inventory WHERE sku IN ({placeholders})",
            requested,
        ).fetchall()
        found = {
            row["sku"]: self._stock_info(row["sku"], row["stock_qty"])
            for row in rows
        }
        for sku in requested:
            found.setdefault(sku, StockInfo(sku=sku, qty=0, status="out_of_stock"))
        return found

    def _stock_info(self, sku: str, qty: int) -> StockInfo:
        """Create status data using the configured low-stock threshold."""
        if qty <= 0:
            status = "out_of_stock"
        elif qty <= self.low_threshold:
            status = "low_stock"
        else:
            status = "in_stock"
        return StockInfo(sku=sku, qty=qty, status=status)

    def set_stock(self, sku: str, qty: int) -> None:
        """Set a product's stock quantity for demo simulation."""
        if qty < 0:
            raise ValueError("qty must not be negative")
        cursor = self.conn.execute(
            "UPDATE inventory SET stock_qty = ?, updated_at = ? WHERE sku = ?",
            (qty, now_iso(), sku),
        )
        if cursor.rowcount == 0:
            raise KeyError(f"Unknown SKU: {sku}")
        self.conn.commit()

    def reset_stock(self) -> int:
        """Restore all rows to their initial stock values."""
        cursor = self.conn.execute(
            "UPDATE inventory SET stock_qty = initial_qty, updated_at = ?",
            (now_iso(),),
        )
        self.conn.commit()
        return cursor.rowcount
