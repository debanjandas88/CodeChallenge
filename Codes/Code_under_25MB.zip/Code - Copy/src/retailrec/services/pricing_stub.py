"""SQLite-backed pricing and promotion stub."""

from datetime import datetime, timedelta, timezone
import sqlite3
from time import sleep
from typing import Iterable
from uuid import uuid4

from retailrec.db import now_iso
from retailrec.models import PriceInfo


class SqlitePricingService:
    """Calculate verified effective prices from active database promotions."""

    def __init__(self, conn: sqlite3.Connection, latency_ms: int):
        self.conn = conn
        self.latency_ms = latency_ms

    def get_prices(self, skus: Iterable[str]) -> dict[str, PriceInfo]:
        """Return current prices, applying the highest active discount per SKU."""
        requested = list(dict.fromkeys(skus))
        if self.latency_ms > 0:
            sleep(self.latency_ms / 1000)
        prices: dict[str, PriceInfo] = {}
        current = now_iso()
        for sku in requested:
            product = self.conn.execute(
                "SELECT sku, category, base_price FROM products WHERE sku = ?",
                (sku,),
            ).fetchone()
            if product is None:
                continue
            promo = self.conn.execute(
                """SELECT promo_id, discount_pct, label
                   FROM promotions
                   WHERE starts_at <= ?
                     AND (ends_at IS NULL OR ends_at > ?)
                     AND ((scope_type = 'sku' AND scope_value = ?)
                       OR (scope_type = 'category' AND scope_value = ?))
                   ORDER BY discount_pct DESC, promo_id
                   LIMIT 1""",
                (current, current, sku, product["category"]),
            ).fetchone()
            discount = float(promo["discount_pct"]) if promo else 0.0
            base_price = float(product["base_price"])
            prices[sku] = PriceInfo(
                sku=sku,
                base_price=base_price,
                effective_price=round(base_price * (1 - discount / 100), 2),
                discount_pct=discount,
                promo_id=promo["promo_id"] if promo else None,
                promo_label=promo["label"] if promo else None,
            )
        return prices

    def start_flash_sale(
        self, category: str, discount_pct: float, minutes: int
    ) -> str:
        """Create a category-wide flash promotion that expires after minutes."""
        if not 5 <= discount_pct <= 80:
            raise ValueError("discount_pct must be between 5 and 80")
        if not 1 <= minutes <= 240:
            raise ValueError("minutes must be between 1 and 240")
        exists = self.conn.execute(
            "SELECT 1 FROM products WHERE category = ? LIMIT 1", (category,)
        ).fetchone()
        if exists is None:
            raise KeyError(f"Unknown category: {category}")
        promo_id = f"FLASH-{uuid4().hex[:4]}"
        now = datetime.now(timezone.utc)
        self.conn.execute(
            """INSERT INTO promotions
               (promo_id, scope_type, scope_value, discount_pct, label, is_flash,
                starts_at, ends_at)
               VALUES (?, 'category', ?, ?, ?, 1, ?, ?)""",
            (
                promo_id,
                category,
                discount_pct,
                f"Flash Sale {discount_pct:g}% off",
                now.isoformat(timespec="seconds"),
                (now + timedelta(minutes=minutes)).isoformat(timespec="seconds"),
            ),
        )
        self.conn.commit()
        return promo_id

    def clear_flash_sales(self) -> int:
        """Delete all flash-sale promotion rows."""
        cursor = self.conn.execute("DELETE FROM promotions WHERE is_flash = 1")
        self.conn.commit()
        return cursor.rowcount

    def list_active_promotions(self, limit: int = 10) -> list[dict]:
        """Return a bounded list of currently active promotions."""
        if limit < 1:
            raise ValueError("limit must be positive")
        current = now_iso()
        rows = self.conn.execute(
            """SELECT promo_id, scope_type, scope_value, discount_pct, label,
                      is_flash, starts_at, ends_at
               FROM promotions
               WHERE starts_at <= ? AND (ends_at IS NULL OR ends_at > ?)
               ORDER BY discount_pct DESC, promo_id
               LIMIT ?""",
            (current, current, limit),
        ).fetchall()
        return [dict(row) for row in rows]
