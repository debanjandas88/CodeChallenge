"""Inventory and pricing integrations."""
