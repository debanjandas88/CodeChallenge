"""Function schemas and safe local execution for recommendation tools."""

import json
import logging
import math
import sqlite3
from time import perf_counter
from typing import Any

from retailrec.config import Settings
from retailrec.events import get_recent_events
from retailrec.models import SessionContext
from retailrec.privacy import build_llm_profile, mask_text
from retailrec.retrieval import CatalogRetriever
from retailrec.services.base import InventoryService, PricingService


logger = logging.getLogger(__name__)

CATEGORIES = [
    "Electronics",
    "Home & Kitchen",
    "Fashion",
    "Sports & Outdoors",
    "Beauty & Personal Care",
    "Toys & Baby",
    "Books & Stationery",
    "Office & Work",
    "Garden & Outdoor Living",
    "Pet Supplies",
]

TOOL_SPECS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "search_catalog",
            "description": "Semantic search over the product catalog. Returns candidate products (not verified for stock).",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "category": {"type": "string", "enum": CATEGORIES},
                    "max_price": {"type": "number"},
                    "top_k": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 15,
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "check_inventory",
            "description": "Live stock status for SKUs.",
            "parameters": {
                "type": "object",
                "properties": {
                    "skus": {
                        "type": "array",
                        "items": {"type": "string"},
                        "maxItems": 15,
                    }
                },
                "required": ["skus"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_pricing_and_promotions",
            "description": "Live effective price and active promotion for SKUs.",
            "parameters": {
                "type": "object",
                "properties": {
                    "skus": {
                        "type": "array",
                        "items": {"type": "string"},
                        "maxItems": 15,
                    }
                },
                "required": ["skus"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_user_profile",
            "description": "Anonymous shopper profile and recent browsing/purchase events.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
]


class ToolExecutor:
    """Validate, execute, and audit the four supported function tools."""

    def __init__(
        self,
        retriever: CatalogRetriever,
        inventory: InventoryService,
        pricing: PricingService,
        conn: sqlite3.Connection,
        ctx: SessionContext,
        settings: Settings,
    ):
        self.retriever = retriever
        self.inventory = inventory
        self.pricing = pricing
        self.conn = conn
        self.ctx = ctx
        self.settings = settings
        self.calls: list[dict[str, Any]] = []
        self.pool: dict[str, float] = {}
        self.flags: list[str] = []

    def execute(self, name: str, arguments_json: str) -> dict[str, Any]:
        """Run one tool and convert all failures into explicit error results."""
        started = perf_counter()
        try:
            arguments = json.loads(arguments_json)
            if not isinstance(arguments, dict):
                raise ValueError("tool arguments must be an object")
            result = self._dispatch(name, arguments)
        except json.JSONDecodeError:
            arguments = {}
            result = {"error": "invalid_arguments"}
        except (ValueError, KeyError, TypeError):
            arguments = {}
            result = {"error": "invalid_arguments"}
        except Exception as exc:
            arguments = {}
            result = {"error": "tool_execution_failed"}
            logger.warning(
                "Tool execution failed for %s (%s)", name, type(exc).__name__
            )

        safe_args = self._mask_arguments(arguments)
        self.calls.append(
            {
                "name": name,
                "args": safe_args,
                "result_summary": self._result_summary(result),
                "latency_ms": round((perf_counter() - started) * 1000),
            }
        )
        return result

    def _dispatch(self, name: str, args: dict[str, Any]) -> dict[str, Any]:
        if name == "search_catalog":
            query = args.get("query")
            category = args.get("category")
            max_price = args.get("max_price")
            top_k = args.get("top_k", 10)
            if not isinstance(query, str) or not query.strip():
                raise ValueError("query is required")
            if category is not None and category not in CATEGORIES:
                raise ValueError("unknown category")
            if (
                max_price is not None
                and (
                    isinstance(max_price, bool)
                    or not isinstance(max_price, (int, float))
                    or not math.isfinite(max_price)
                    or max_price < 0
                )
            ):
                raise ValueError("max_price must be a non-negative number")
            if isinstance(top_k, bool) or not isinstance(top_k, int) or not 1 <= top_k <= 15:
                raise ValueError("top_k must be between 1 and 15")
            results = self.retriever.search(
                query,
                top_k=top_k,
                category=category,
                max_price=max_price,
            )
            for candidate in results:
                self.pool[candidate.sku] = max(
                    self.pool.get(candidate.sku, float("-inf")),
                    candidate.score,
                )
            return {
                "results": [
                    {
                        "sku": item.sku,
                        "name": item.name,
                        "category": item.category,
                        "subcategory": item.subcategory,
                        "base_price": item.base_price,
                        "score": item.score,
                    }
                    for item in results
                ]
            }
        if name in {"check_inventory", "get_pricing_and_promotions"}:
            skus = self._validated_skus(args)
            if name == "check_inventory":
                items = self.inventory.get_stock(skus)
                return {
                    "items": [
                        {
                            "sku": sku,
                            "qty": items[sku].qty,
                            "status": items[sku].status,
                        }
                        for sku in skus
                    ]
                }
            prices = self.pricing.get_prices(skus)
            return {
                "items": [
                    {
                        "sku": sku,
                        "base_price": prices[sku].base_price,
                        "effective_price": prices[sku].effective_price,
                        "discount_pct": prices[sku].discount_pct,
                        "promo_label": prices[sku].promo_label,
                    }
                    for sku in skus
                    if sku in prices
                ]
            }
        if name == "get_user_profile":
            if args:
                raise ValueError("get_user_profile takes no arguments")
            return self._user_profile()
        return {"error": "unknown_tool"}

    @staticmethod
    def _validated_skus(args: dict[str, Any]) -> list[str]:
        skus = args.get("skus")
        if (
            not isinstance(skus, list)
            or len(skus) > 15
            or any(not isinstance(sku, str) or not sku for sku in skus)
        ):
            raise ValueError("skus must be a list of at most 15 strings")
        return list(dict.fromkeys(skus))

    def _user_profile(self) -> dict[str, Any]:
        if not self.ctx.consent:
            if "no_consent" not in self.flags:
                self.flags.append("no_consent")
            return {"consent": False}
        customer = self.conn.execute(
            """SELECT persona, age_band, region, preferred_categories,
                      price_sensitivity
               FROM customers WHERE customer_id = ?""",
            (self.ctx.customer_id,),
        ).fetchone()
        if customer is None:
            raise KeyError("shopper profile is unavailable")
        profile = build_llm_profile(customer, True)
        recent_events = get_recent_events(self.conn, self.ctx.pseudo_id, limit=10)
        purchases = self.conn.execute(
            """SELECT DISTINCT p.category
               FROM events e JOIN products p ON p.sku = e.sku
               WHERE e.pseudo_id = ? AND e.event_type = 'purchase'
               ORDER BY p.category""",
            (self.ctx.pseudo_id,),
        ).fetchall()
        return {
            **profile,
            "recent_events": [
                {
                    "event_type": event["event_type"],
                    "sku": event["sku"],
                    "name": event["name"],
                    "category": event["category"],
                }
                for event in recent_events
            ],
            "purchased_categories": [row["category"] for row in purchases],
        }

    def _mask_arguments(self, arguments: dict[str, Any]) -> dict[str, Any]:
        known_names = [
            row["display_name"]
            for row in self.conn.execute(
                "SELECT display_name FROM customers"
            ).fetchall()
        ]

        def mask(value: Any) -> Any:
            if isinstance(value, str):
                return mask_text(value, known_names)[0]
            if isinstance(value, list):
                return [mask(item) for item in value]
            if isinstance(value, dict):
                return {key: mask(item) for key, item in value.items()}
            return value

        return mask(arguments)

    @staticmethod
    def _result_summary(result: dict[str, Any]) -> dict[str, Any]:
        """Keep audit summaries compact while retaining explicit errors."""
        if "error" in result:
            return {"error": result["error"]}
        for key in ("results", "items"):
            if key in result:
                return {"count": len(result[key])}
        return {"keys": sorted(result)}
