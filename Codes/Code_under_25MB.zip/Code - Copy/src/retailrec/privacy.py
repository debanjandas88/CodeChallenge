"""PII masking, pseudonymization, and LLM-safe customer profiles."""

import hashlib
import re
from collections.abc import Iterable, Mapping


CARD_RE = re.compile(r"\b(?:\d[ -]?){13,19}\b")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
PHONE_RE = re.compile(r"(?<!\w)\+?\d[\d\s().-]{8,}\d(?!\w)")


def mask_text(
    text: str, known_names: Iterable[str] = ()
) -> tuple[str, list[str]]:
    """Mask payment cards, email, phone numbers, and known customer names."""
    entities: set[str] = set()
    masked = text

    def replace(pattern: re.Pattern, token: str, entity: str, value: str) -> str:
        updated, count = pattern.subn(token, value)
        if count:
            entities.add(entity)
        return updated

    masked = replace(CARD_RE, "[CARD]", "CARD", masked)
    masked = replace(EMAIL_RE, "[EMAIL]", "EMAIL", masked)
    masked = replace(PHONE_RE, "[PHONE]", "PHONE", masked)
    for name in sorted(
        (name.strip() for name in known_names if name and name.strip()),
        key=len,
        reverse=True,
    ):
        pattern = re.compile(rf"(?<!\w){re.escape(name)}(?!\w)", re.IGNORECASE)
        masked = replace(pattern, "[NAME]", "NAME", masked)
    return masked, sorted(entities)


def pseudonymize(customer_id: str, salt: str) -> str:
    """Return a stable salted hash without revealing the customer ID."""
    digest = hashlib.sha256(f"{salt}:{customer_id}".encode("utf-8")).hexdigest()
    return "u_" + digest[:12]


def build_llm_profile(customer: Mapping, consent: bool) -> dict:
    """Return only permitted profile attributes for the language model."""
    if not consent:
        return {"consent": False}
    preferred = customer["preferred_categories"]
    if isinstance(preferred, str):
        preferred_categories = [
            category.strip()
            for category in preferred.split(",")
            if category.strip()
        ]
    else:
        preferred_categories = list(preferred)
    region = customer["region"]
    return {
        "consent": True,
        "persona": customer["persona"],
        "age_band": customer["age_band"],
        "region_group": str(region).split("-")[0],
        "preferred_categories": preferred_categories,
        "price_sensitivity": customer["price_sensitivity"],
    }
