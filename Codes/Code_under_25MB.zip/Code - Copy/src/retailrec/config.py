"""Environment-backed application settings."""

from dataclasses import dataclass
from functools import lru_cache
import os

from dotenv import load_dotenv


class ConfigError(Exception):
    """Raised when required application configuration is missing."""


@dataclass(frozen=True)
class Settings:
    azure_endpoint: str
    azure_api_key: str
    azure_api_version: str
    chat_deployment: str
    embed_deployment: str
    db_path: str
    chroma_path: str
    pseudo_salt: str
    agent_max_iterations: int = 5
    agent_max_tool_calls: int = 8
    agent_temperature: float = 0.2
    agent_max_tokens: int = 800
    validation_max_retries: int = 2
    confidence_threshold: float = 0.5
    top_n: int = 5
    low_stock_threshold: int = 5
    stub_latency_ms: int = 40
    catalog_size: int = 50000
    embed_subset_per_subcategory: int = 40
    random_seed: int = 42
    currency_symbol: str = "$"
    api_backend: str = "stub"
    mock_api_base_url: str = "http://127.0.0.1:8001"
    mock_api_timeout_s: float = 3.0
    log_level: str = "INFO"


def _int_setting(name: str, default: int) -> int:
    """Read an integer setting or use its default."""
    return int(os.getenv(name, str(default)))


def _float_setting(name: str, default: float) -> float:
    """Read a floating-point setting or use its default."""
    return float(os.getenv(name, str(default)))


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Load settings and raise one error listing every missing required key."""
    load_dotenv()
    required = {
        "AZURE_OPENAI_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT"),
        "AZURE_OPENAI_API_KEY": os.getenv("AZURE_OPENAI_API_KEY"),
        "AZURE_OPENAI_CHAT_DEPLOYMENT": os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT"),
        "AZURE_OPENAI_EMBED_DEPLOYMENT": os.getenv("AZURE_OPENAI_EMBED_DEPLOYMENT"),
        "PSEUDO_SALT": os.getenv("PSEUDO_SALT"),
    }
    missing = [key for key, value in required.items() if not value or value.startswith("<")]
    if missing:
        raise ConfigError("Missing required configuration: " + ", ".join(missing))

    return Settings(
        azure_endpoint=required["AZURE_OPENAI_ENDPOINT"] or "",
        azure_api_key=required["AZURE_OPENAI_API_KEY"] or "",
        azure_api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21"),
        chat_deployment=required["AZURE_OPENAI_CHAT_DEPLOYMENT"] or "",
        embed_deployment=required["AZURE_OPENAI_EMBED_DEPLOYMENT"] or "",
        db_path=os.getenv("DB_PATH", "data/catalog.db"),
        chroma_path=os.getenv("CHROMA_PATH", "data/chroma"),
        pseudo_salt=required["PSEUDO_SALT"] or "",
        agent_max_iterations=_int_setting("AGENT_MAX_ITERATIONS", 5),
        agent_max_tool_calls=_int_setting("AGENT_MAX_TOOL_CALLS", 8),
        agent_temperature=_float_setting("AGENT_TEMPERATURE", 0.2),
        confidence_threshold=_float_setting("CONFIDENCE_THRESHOLD", 0.5),
        stub_latency_ms=_int_setting("STUB_LATENCY_MS", 40),
        catalog_size=_int_setting("CATALOG_SIZE", 50000),
        embed_subset_per_subcategory=_int_setting(
            "EMBED_SUBSET_PER_SUBCATEGORY", 40
        ),
        random_seed=_int_setting("RANDOM_SEED", 42),
        api_backend=os.getenv("API_BACKEND", "stub"),
        mock_api_base_url=os.getenv(
            "MOCK_API_BASE_URL", "http://127.0.0.1:8001"
        ),
        mock_api_timeout_s=_float_setting("MOCK_API_TIMEOUT_S", 3.0),
        log_level=os.getenv("LOG_LEVEL", "INFO"),
    )
