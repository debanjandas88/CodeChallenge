"""Azure OpenAI chat and embedding client."""

from dataclasses import dataclass
from time import perf_counter
from typing import Protocol

from openai import (
    APIConnectionError,
    APITimeoutError,
    AuthenticationError,
    AzureOpenAI,
    BadRequestError,
    NotFoundError,
    RateLimitError,
)
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from retailrec.config import Settings


class LLMUnavailable(Exception):
    """Raised when the configured Azure OpenAI deployment cannot be used."""


@dataclass
class ToolCall:
    """A function call returned by the chat deployment."""

    id: str
    name: str
    arguments: str


@dataclass
class ChatResult:
    """Chat content, tool calls, usage, and elapsed time."""

    content: str | None
    tool_calls: list[ToolCall]
    prompt_tokens: int
    completion_tokens: int
    latency_ms: int


class LLMClient(Protocol):
    """Interface used by retrieval and recommendation modules."""

    def chat(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        tool_choice: str = "auto",
        temperature: float = 0.2,
        max_tokens: int = 800,
    ) -> ChatResult: ...

    def embed(self, texts: list[str]) -> list[list[float]]: ...


class AzureLLMClient:
    """Azure OpenAI SDK implementation of the project LLM interface."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = AzureOpenAI(
            azure_endpoint=settings.azure_endpoint,
            api_key=settings.azure_api_key,
            api_version=settings.azure_api_version,
            timeout=30,
            max_retries=0,
        )

    @retry(
        retry=retry_if_exception_type(
            (RateLimitError, APIConnectionError, APITimeoutError)
        ),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=8),
        reraise=True,
    )
    def _chat_request(
        self,
        messages: list[dict],
        tools: list[dict] | None,
        tool_choice: str,
        temperature: float,
        max_tokens: int,
    ):
        request: dict[str, object] = {
            "model": self.settings.chat_deployment,
            "messages": messages,
            "tools": tools,
        }
        if tools:
            request["tool_choice"] = tool_choice
        if "gpt-5" in self.settings.chat_deployment.lower():
            request["max_completion_tokens"] = max_tokens
            request["reasoning_effort"] = "minimal"
        else:
            request["temperature"] = temperature
            request["max_tokens"] = max_tokens
        return self.client.chat.completions.create(**request)

    def chat(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        tool_choice: str = "auto",
        temperature: float = 0.2,
        max_tokens: int = 800,
    ) -> ChatResult:
        """Call Azure chat and normalize content, tool calls, and usage."""
        started = perf_counter()
        try:
            response = self._chat_request(
                messages, tools, tool_choice, temperature, max_tokens
            )
        except (AuthenticationError, NotFoundError, BadRequestError) as exc:
            raise LLMUnavailable(
                f"Azure chat configuration or request failed: {type(exc).__name__}"
            ) from exc
        except (RateLimitError, APIConnectionError, APITimeoutError) as exc:
            raise LLMUnavailable(
                f"Azure chat unavailable after retries: {type(exc).__name__}"
            ) from exc

        if not response.choices:
            raise LLMUnavailable("Azure chat returned no choices")
        message = response.choices[0].message
        tool_calls = [
            ToolCall(
                id=call.id,
                name=call.function.name,
                arguments=call.function.arguments,
            )
            for call in (message.tool_calls or [])
        ]
        usage = response.usage
        return ChatResult(
            content=message.content,
            tool_calls=tool_calls,
            prompt_tokens=usage.prompt_tokens if usage else 0,
            completion_tokens=usage.completion_tokens if usage else 0,
            latency_ms=round((perf_counter() - started) * 1000),
        )

    @retry(
        retry=retry_if_exception_type(
            (RateLimitError, APIConnectionError, APITimeoutError)
        ),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=8),
        reraise=True,
    )
    def _embed_batch(self, texts: list[str]):
        return self.client.embeddings.create(
            model=self.settings.embed_deployment,
            input=texts,
        )

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed texts in batches of 100 using the configured deployment."""
        vectors: list[list[float]] = []
        try:
            for start in range(0, len(texts), 100):
                response = self._embed_batch(texts[start : start + 100])
                vectors.extend(
                    [item.embedding for item in sorted(response.data, key=lambda x: x.index)]
                )
        except (AuthenticationError, NotFoundError, BadRequestError) as exc:
            raise LLMUnavailable(
                f"Azure embeddings configuration or request failed: {type(exc).__name__}"
            ) from exc
        except (RateLimitError, APIConnectionError, APITimeoutError) as exc:
            raise LLMUnavailable(
                f"Azure embeddings unavailable after retries: {type(exc).__name__}"
            ) from exc
        return vectors
