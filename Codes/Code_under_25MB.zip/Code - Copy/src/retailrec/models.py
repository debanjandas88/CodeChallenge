"""Typed data models shared across application boundaries."""

from typing import Literal

from pydantic import BaseModel, Field


class Recommendation(BaseModel):
    """One product recommendation proposed by the agent."""

    sku: str
    rank: int = Field(ge=1, le=5)
    reason: str = Field(max_length=200)
    highlight_promo: bool = False


class AgentOutput(BaseModel):
    """Validated structured response returned by the recommendation agent."""

    intent: Literal["shopping", "off_topic"]
    reply: str = Field(min_length=1, max_length=600)
    recommendations: list[Recommendation] = Field(default_factory=list, max_length=5)
    confidence: float = Field(ge=0, le=1)
    follow_up_question: str | None = None


class StockInfo(BaseModel):
    """Live stock data for one SKU."""

    sku: str
    qty: int
    status: Literal["in_stock", "low_stock", "out_of_stock"]


class PriceInfo(BaseModel):
    """Verified effective price and active promotion for one SKU."""

    sku: str
    base_price: float
    effective_price: float
    discount_pct: float
    promo_id: str | None = None
    promo_label: str | None = None


class Candidate(BaseModel):
    """Retrieved product candidate with a relevance score."""

    sku: str
    name: str
    category: str
    subcategory: str
    base_price: float
    score: float
    snippet: str


class EnrichedRec(BaseModel):
    """Recommendation enriched with live stock, pricing, and provenance."""

    sku: str
    name: str
    category: str
    subcategory: str
    rank: int
    reason: str
    highlight_promo: bool
    stock: StockInfo
    price: PriceInfo
    sources: dict[str, object]


class SessionContext(BaseModel):
    """Pseudonymous state for one in-memory demo session."""

    session_id: str
    pseudo_id: str
    mode: Literal["ai", "baseline"] = "ai"
    customer_id: str
    persona: str
    preferred_categories: list[str]
    price_sensitivity: str
    consent: bool
    started_at: str


class RecResult(BaseModel):
    """Complete recommendation response and refresh state."""

    rec_id: str
    trigger: str
    mode: str
    reply: str
    items: list[EnrichedRec]
    confidence: float | None
    fallback_used: bool
    fallback_reason: str | None
    latency_ms: int
    pool: list[str]
    exclude: list[str] = Field(default_factory=list)
    flags: list[str]
    intent: str = "shopping"
