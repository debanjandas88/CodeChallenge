"""ShopSmart demo storefront."""

import logging
import re
import sqlite3
from urllib.error import URLError
from urllib.request import urlopen
from uuid import uuid4

import streamlit as st

from retailrec.config import ConfigError
from retailrec.privacy import mask_text
from retailrec.service import RecommendationService
from retailrec.tools import CATEGORIES


LOGGER = logging.getLogger(__name__)
CATEGORY_EMOJI = {
    "Electronics": "🎧",
    "Home & Kitchen": "☕",
    "Fashion": "👕",
    "Sports & Outdoors": "🏃",
    "Beauty & Personal Care": "💄",
    "Toys & Baby": "🧸",
    "Books & Stationery": "📚",
    "Office & Work": "💼",
    "Garden & Outdoor Living": "🌿",
    "Pet Supplies": "🐾",
}
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@st.cache_data(ttl=3600, max_entries=256, show_spinner=False)
def _load_image(url: str) -> bytes | None:
    """Fetch a bounded image payload; callers render a placeholder on failure."""
    try:
        with urlopen(url, timeout=4) as response:
            content_type = response.headers.get("Content-Type", "")
            if not content_type.lower().startswith("image/"):
                return None
            data = response.read(5_000_001)
            if len(data) > 5_000_000:
                return None
            return data
    except (OSError, URLError, ValueError, TimeoutError):
        return None


def _show_image(product: dict) -> None:
    url = product.get("image_url")
    image = _load_image(url) if url else None
    if image:
        st.image(image, width="stretch")
    else:
        category = product.get("category", "")
        emoji = CATEGORY_EMOJI.get(category, "🛍️")
        st.markdown(
            "<div style='height:150px;display:flex;align-items:center;"
            "justify-content:center;background:#f2f4f7;border-radius:8px;"
            f"font-size:48px' role='img' aria-label='{category or 'Product'}'>"
            f"{emoji}</div>",
            unsafe_allow_html=True,
        )


def _show_price(price) -> None:
    if price is None:
        st.caption("Price temporarily unavailable")
    elif price.discount_pct > 0:
        label = price.promo_label or "Promotion"
        st.markdown(
            f"~~${price.base_price:.2f}~~ **${price.effective_price:.2f}** "
            f":red[-{price.discount_pct:g}% {label}]"
        )
    else:
        st.markdown(f"**${price.effective_price:.2f}**")


def _set_notice(message: str) -> None:
    st.session_state.notice = message


def _run_home(svc: RecommendationService, customer_id: str, mode: str) -> None:
    try:
        ctx = svc.start_session(customer_id, mode=mode)
        with st.spinner("Finding picks..."):
            result = svc.recommend(ctx, trigger="home")
        st.session_state.ctx = ctx
        st.session_state.result = result
        st.session_state.chat = []
        st.session_state.viewed_sku = None
        st.session_state.notice = ""
    except Exception as exc:
        LOGGER.error("Could not start storefront session (%s)", type(exc).__name__)
        st.session_state.notice = (
            f"Could not start the demo session ({type(exc).__name__})."
        )


def _create_account(svc: RecommendationService, name: str, email: str) -> str | None:
    display_name = name.strip()
    normalized_email = email.strip().lower()
    if not display_name or len(display_name) > 80:
        return "Enter a display name of 1–80 characters."
    if not normalized_email or not EMAIL_RE.fullmatch(normalized_email):
        return "Enter a valid email address."
    duplicate = svc.conn.execute(
        "SELECT 1 FROM customers WHERE LOWER(email) = ?", (normalized_email,)
    ).fetchone()
    if duplicate:
        return "That email is already in use. Continue with the existing demo account."
    customer_id = f"D{uuid4().hex[:8].upper()}"
    try:
        svc.conn.execute(
            """INSERT INTO customers
               (customer_id, display_name, email, persona, age_band, region,
                preferred_categories, price_sensitivity, consent_personalization)
               VALUES (?, ?, ?, 'new_shopper', 'unknown', 'Unknown', '',
                       'medium', 1)""",
            (customer_id, display_name, normalized_email),
        )
        svc.conn.commit()
    except sqlite3.IntegrityError:
        svc.conn.rollback()
        return "That email is already in use. Continue with the existing demo account."
    except Exception as exc:
        svc.conn.rollback()
        LOGGER.error("Demo account creation failed (%s)", type(exc).__name__)
        return f"Account creation failed ({type(exc).__name__})."
    _run_home(svc, customer_id, "ai")
    return None


def _render_entry(svc: RecommendationService) -> None:
    st.title("ShopSmart")
    st.write("Create a local demo account or continue with a seeded shopper.")
    customers = svc.list_customers()
    with st.sidebar:
        st.subheader("Create demo account")
        with st.form("create_demo_account"):
            name = st.text_input("Display name", max_chars=80)
            email = st.text_input("Email")
            created = st.form_submit_button("Create account")
        if created:
            error = _create_account(svc, name, email)
            if error:
                st.error(error)
            elif st.session_state.get("ctx"):
                st.rerun()

        st.divider()
        st.subheader("Existing demo account")
        labels = {
            f"{customer['customer_id']} - {customer['persona']}": customer[
                "customer_id"
            ]
            for customer in customers
        }
        selected = st.selectbox(
            "Customer",
            list(labels),
            key="entry_customer",
        )
        mode = st.radio(
            "Recommendation mode",
            ["AI assistant", "Baseline (popularity)"],
            key="entry_mode",
        )
        if st.button("Continue to storefront", width="stretch"):
            mode_value = "ai" if mode == "AI assistant" else "baseline"
            _run_home(svc, labels[selected], mode_value)
            if st.session_state.get("ctx"):
                st.rerun()
    st.info("This is a local demo account, not secure authentication.")


def _refresh_result(message: str) -> None:
    svc = st.session_state.svc
    ctx = st.session_state.ctx
    current = st.session_state.result
    if current is None:
        _set_notice("There are no recommendations to refresh yet.")
        return
    try:
        with st.spinner("Refreshing live stock and prices..."):
            st.session_state.result = svc.refresh(ctx, current)
        _set_notice(message)
    except Exception as exc:
        LOGGER.error("Storefront refresh failed (%s)", type(exc).__name__)
        _set_notice(f"Refresh failed ({type(exc).__name__}).")


def _mark_out_of_stock(sku: str) -> None:
    try:
        st.session_state.svc.inventory.set_stock(sku, 0)
        _refresh_result(f"{sku} marked out of stock.")
    except Exception as exc:
        LOGGER.error("Stock simulation failed (%s)", type(exc).__name__)
        _set_notice(f"Stock simulation failed ({type(exc).__name__}).")


def _start_flash_sale() -> None:
    state = st.session_state
    try:
        state.svc.pricing.start_flash_sale(
            state.flash_category,
            state.flash_discount,
            state.flash_minutes,
        )
        _refresh_result("Flash sale started and recommendations refreshed.")
    except Exception as exc:
        LOGGER.error("Flash sale simulation failed (%s)", type(exc).__name__)
        _set_notice(f"Flash sale failed ({type(exc).__name__}).")


def _reset_simulations() -> None:
    try:
        svc = st.session_state.svc
        svc.inventory.reset_stock()
        svc.pricing.clear_flash_sales()
        _refresh_result("Stock and flash sales reset.")
    except Exception as exc:
        LOGGER.error("Simulation reset failed (%s)", type(exc).__name__)
        _set_notice(f"Reset failed ({type(exc).__name__}).")


def _record_feedback(rec_id: str, sku: str, value: int) -> None:
    try:
        st.session_state.svc.feedback(st.session_state.ctx, rec_id, sku, value)
        _set_notice("Feedback saved.")
    except Exception as exc:
        LOGGER.error("Feedback save failed (%s)", type(exc).__name__)
        _set_notice(f"Feedback failed ({type(exc).__name__}).")


def _add_to_cart(rec_id: str, sku: str) -> None:
    try:
        st.session_state.svc.add_to_cart(st.session_state.ctx, rec_id, sku)
        _set_notice("Added to demo cart.")
    except Exception as exc:
        LOGGER.error("Cart event failed (%s)", type(exc).__name__)
        _set_notice(f"Cart update failed ({type(exc).__name__}).")


def _view_product(sku: str, rec_id: str | None = None) -> None:
    state = st.session_state
    try:
        if rec_id:
            state.svc.record_click(state.ctx, rec_id, sku)
        state.svc.record_view(state.ctx, sku)
        state.viewed_sku = sku
        with st.spinner("Finding complementary picks..."):
            state.result = state.svc.recommend(
                state.ctx,
                trigger="view",
                viewed_sku=sku,
                history=state.chat,
            )
        _set_notice(f"Opened {sku}; recommendations updated.")
    except Exception as exc:
        LOGGER.error("Product view failed (%s)", type(exc).__name__)
        _set_notice(f"Product view failed ({type(exc).__name__}).")


def _render_recommendation_card(item, rec_id: str) -> None:
    with st.container(border=True):
        _show_image(
            {
                "image_url": st.session_state.svc.product_image_url(item.sku),
                "category": item.category,
            }
        )
        st.markdown(f"**{item.name}**")
        st.caption(f"{item.category} · {item.subcategory}")
        _show_price(item.price)
        if item.stock.status == "low_stock":
            st.caption(f":orange[Only {item.stock.qty} left]")
        else:
            st.caption(":green[In stock]")
        st.write(item.reason)
        actions = st.columns(4)
        actions[0].button(
            "👍",
            key=f"like_{rec_id}_{item.sku}",
            on_click=_record_feedback,
            args=(rec_id, item.sku, 1),
        )
        actions[1].button(
            "👎",
            key=f"dislike_{rec_id}_{item.sku}",
            on_click=_record_feedback,
            args=(rec_id, item.sku, -1),
        )
        actions[2].button(
            "View",
            key=f"rec_view_{rec_id}_{item.sku}",
            on_click=_view_product,
            args=(item.sku, rec_id),
        )
        actions[3].button(
            "Add to cart",
            key=f"cart_{rec_id}_{item.sku}",
            on_click=_add_to_cart,
            args=(rec_id, item.sku),
        )
        with st.expander("Why this?"):
            st.write(f"Origin: {item.sources.get('origin', 'unknown')}")
            st.write(f"Retrieval score: {item.sources.get('retrieval_score')}")
            st.write(f"Tools used: {', '.join(item.sources.get('tools_used', []))}")
            st.write(f"Recommendation ID: {rec_id}")


def _render_sidebar(svc: RecommendationService) -> None:
    state = st.session_state
    ctx = state.ctx
    customers = svc.list_customers()
    labels = {
        f"{customer['customer_id']} - {customer['persona']}": customer[
            "customer_id"
        ]
        for customer in customers
    }
    label_for_id = {customer_id: label for label, customer_id in labels.items()}
    if ctx.customer_id not in label_for_id:
        st.error("The active demo customer no longer exists.")
        return

    with st.sidebar:
        st.subheader("Shopper")
        selected_label = st.selectbox(
            "Customer",
            list(labels),
            index=list(labels).index(label_for_id[ctx.customer_id]),
            key="active_customer",
        )
        mode = st.radio(
            "Recommendation mode",
            ["AI assistant", "Baseline (popularity)"],
            index=0 if ctx.mode == "ai" else 1,
            key="active_mode",
        )
        selected_customer = labels[selected_label]
        selected_mode = "ai" if mode == "AI assistant" else "baseline"
        if (
            selected_customer != ctx.customer_id
            or selected_mode != ctx.mode
        ):
            _run_home(svc, selected_customer, selected_mode)
            st.rerun()

        st.subheader("Simulate")
        result = state.result
        displayed_skus = [item.sku for item in result.items] if result else []
        if displayed_skus:
            sku = st.selectbox("Displayed product", displayed_skus, key="stock_sku")
            st.button(
                "Mark out of stock",
                on_click=_mark_out_of_stock,
                args=(sku,),
                width="stretch",
            )
        else:
            st.caption("No displayed product to simulate.")
        st.selectbox("Flash sale category", CATEGORIES, key="flash_category")
        st.slider("Discount (%)", 10, 50, 25, key="flash_discount")
        st.slider("Duration (minutes)", 5, 60, 30, key="flash_minutes")
        st.button(
            "Start flash sale",
            on_click=_start_flash_sale,
            width="stretch",
        )
        st.button(
            "Reset stock and sales",
            on_click=_reset_simulations,
            width="stretch",
        )
        st.button(
            "Refresh",
            on_click=_refresh_result,
            args=("Recommendations refreshed.",),
            width="stretch",
        )

        metrics = svc.metrics(ctx)
        mode_metrics = metrics["by_mode"].get(ctx.mode, {})
        st.subheader("Metrics")
        columns = st.columns(2)
        columns[0].metric("Impressions", mode_metrics.get("impressions", 0))
        columns[1].metric("CTR", f"{mode_metrics.get('ctr', 0):.0%}")
        columns[0].metric("Add-to-cart rate", f"{mode_metrics.get('cart_rate', 0):.0%}")
        columns[1].metric(
            "Satisfaction", f"{mode_metrics.get('satisfaction', 0):.0%}"
        )
        st.metric("Session duration", f"{metrics['session_duration_s']:.0f}s")
        if metrics["by_mode"]:
            st.dataframe(
                [
                    {"Mode": name, **values}
                    for name, values in metrics["by_mode"].items()
                ],
                width="stretch",
                hide_index=True,
            )
        with st.expander("Audit log"):
            st.json(svc.audit.recent(5))
        if state.notice:
            st.info(state.notice)


def _render_details(svc: RecommendationService, sku: str) -> None:
    try:
        product = svc.product_details(sku)
    except Exception as exc:
        LOGGER.error("Product details unavailable (%s)", type(exc).__name__)
        st.error("Live stock and price details are temporarily unavailable.")
        return
    if product is None:
        st.warning("This product is no longer available.")
        return
    st.subheader("Product details")
    columns = st.columns([1, 2])
    with columns[0]:
        _show_image(product)
    with columns[1]:
        st.markdown(f"### {product['name']}")
        st.caption(f"{product['category']} · {product['subcategory']}")
        _show_price(product["price"])
        if product["stock"] and product["stock"].status == "low_stock":
            st.caption(f":orange[Only {product['stock'].qty} left]")
        st.write(product["description"])


def _render_chat(svc: RecommendationService) -> None:
    state = st.session_state
    st.subheader("Shopping Assistant")
    for message in state.chat:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    result = state.result
    if result and result.confidence is not None:
        st.caption(f"Last recommendation confidence: {result.confidence:.0%}")
    prompt = st.chat_input("Ask for ideas, gifts, budgets...")
    if prompt:
        customer = svc.conn.execute(
            "SELECT display_name FROM customers WHERE customer_id = ?",
            (state.ctx.customer_id,),
        ).fetchone()
        known_names = [customer["display_name"]] if customer else []
        masked, _ = mask_text(prompt, known_names)
        state.chat.append({"role": "user", "content": masked})
        history = state.chat[:-1]
        with st.spinner("Finding picks..."):
            state.result = svc.recommend(
                state.ctx,
                trigger="chat",
                message=prompt,
                history=history,
            )
        state.chat.append(
            {"role": "assistant", "content": state.result.reply}
        )
        state.chat = state.chat[-12:]
        state.notice = ""
        st.rerun()


def main() -> None:
    """Render the account entry or active ShopSmart storefront."""
    st.set_page_config(layout="wide", page_title="ShopSmart")
    st.session_state.setdefault("chat", [])
    st.session_state.setdefault("result", None)
    st.session_state.setdefault("browse_cat", CATEGORIES[0])
    st.session_state.setdefault("notice", "")
    st.session_state.setdefault("viewed_sku", None)
    if "svc" not in st.session_state:
        try:
            st.session_state.svc = RecommendationService()
        except ConfigError as exc:
            st.error(f"Configuration required: {exc}")
            return
        except Exception as exc:
            LOGGER.error("ShopSmart initialization failed (%s)", type(exc).__name__)
            st.error(f"ShopSmart could not start ({type(exc).__name__}).")
            return
    svc = st.session_state.svc
    if not st.session_state.get("ctx"):
        _render_entry(svc)
        return

    _render_sidebar(svc)
    if not st.session_state.get("ctx"):
        return
    left, right = st.columns([3, 2])
    with left:
        st.title("ShopSmart")
        st.subheader("Recommended for you")
        result = st.session_state.result
        if result and result.items:
            card_columns = st.columns(min(5, len(result.items)))
            for index, item in enumerate(result.items[:5]):
                with card_columns[index]:
                    _render_recommendation_card(item, result.rec_id)
        elif result and result.intent == "off_topic":
            st.info(result.reply)
        elif result:
            st.info(result.reply)
        if result and result.fallback_used:
            st.caption("Showing popular picks.")

        viewed_sku = st.session_state.viewed_sku
        if viewed_sku:
            _render_details(svc, viewed_sku)

        st.subheader("Browse")
        category = st.selectbox(
            "Category",
            CATEGORIES,
            key="browse_cat",
        )
        products = svc.browse(category, limit=12)
        if not products:
            st.info("No in-stock products are available in this category.")
        for start in range(0, len(products), 4):
            columns = st.columns(4)
            for offset, product in enumerate(products[start : start + 4]):
                with columns[offset]:
                    with st.container(border=True):
                        _show_image(product)
                        st.markdown(f"**{product['name']}**")
                        st.caption(product["subcategory"])
                        _show_price(product["price"])
                        if product["stock"].status == "low_stock":
                            st.caption(
                                f":orange[Only {product['stock'].qty} left]"
                            )
                        st.button(
                            "View",
                            key=f"browse_view_{product['sku']}",
                            on_click=_view_product,
                            args=(product["sku"], None),
                        )
    with right:
        _render_chat(svc)


if __name__ == "__main__":
    main()
