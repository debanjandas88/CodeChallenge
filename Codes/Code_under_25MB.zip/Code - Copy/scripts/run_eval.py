"""Run the labelled recommendation evaluation set."""

import json
import logging
import sqlite3
import sys
from pathlib import Path
from typing import Any

from retailrec.config import ConfigError, get_settings
from retailrec.db import get_conn
from retailrec.llm import AzureLLMClient
from retailrec.models import RecResult
from retailrec.privacy import EMAIL_RE, PHONE_RE
from retailrec.service import RecommendationService


LOGGER = logging.getLogger("run_eval")
EVAL_PATH = Path(__file__).resolve().parents[1] / "data" / "eval_set.json"
REPORT_PATH = Path(__file__).resolve().parents[1] / "data" / "eval_report.json"
PASS_THRESHOLD = 0.8
LATENCY_LIMIT_MS = 15_000


class _SuppressRequestUrlFilter(logging.Filter):
    """Keep SDK request URLs out of evaluation output."""

    def filter(self, record: logging.LogRecord) -> bool:
        return not record.getMessage().startswith("HTTP Request:")


def _check(failures: list[str], condition: bool, name: str) -> None:
    if not condition:
        failures.append(name)


def _viewed_sku(conn: sqlite3.Connection, subcategory: str) -> str:
    row = conn.execute(
        """SELECT p.sku
           FROM products p JOIN inventory i ON i.sku = p.sku
           WHERE p.subcategory = ? AND i.stock_qty > 0
           ORDER BY p.sku LIMIT 1""",
        (subcategory,),
    ).fetchone()
    if row is None:
        raise ValueError(f"No in-stock product in subcategory {subcategory!r}")
    return row["sku"]


def _audit_row(conn: sqlite3.Connection, rec_id: str) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM audit_log WHERE rec_id = ?", (rec_id,)
    ).fetchone()


def _run_case(
    case: dict[str, Any], service: RecommendationService
) -> dict[str, Any]:
    failures: list[str] = []
    initial: RecResult | None = None
    result: RecResult | None = None
    scenario = case.get("scenario")
    try:
        ctx = service.start_session(case["customer"], mode="ai")
        viewed_sku = (
            _viewed_sku(service.conn, case["viewed_subcategory"])
            if scenario == "exclude_viewed"
            else None
        )
        initial = service.recommend(
            ctx,
            trigger=case["trigger"],
            message=case.get("message"),
            viewed_sku=viewed_sku,
        )
        result = initial

        if scenario == "stock_out_top_rec":
            if not initial.items:
                failures.append("stock_scenario_no_initial_recommendation")
            else:
                removed_sku = initial.items[0].sku
                service.inventory.set_stock(removed_sku, 0)
                try:
                    result = service.refresh(ctx, initial)
                finally:
                    service.inventory.reset_stock()
                _check(
                    failures,
                    removed_sku not in {item.sku for item in result.items},
                    "stock_scenario_removed_top_item",
                )
                _check(
                    failures,
                    len(result.items) >= 3,
                    "stock_scenario_backfilled_three_items",
                )
        elif scenario == "flash_sale":
            category = case["sale_category"]
            sale_pct = float(case["sale_pct"])
            service.pricing.start_flash_sale(category, sale_pct, 30)
            try:
                result = service.refresh(ctx, initial)
            finally:
                service.pricing.clear_flash_sales()
            _check(
                failures,
                any(
                    item.price.discount_pct >= sale_pct
                    and item.highlight_promo
                    for item in result.items
                ),
                "flash_sale_visible_after_refresh",
            )
        elif scenario == "exclude_viewed":
            _check(
                failures,
                viewed_sku not in {item.sku for item in result.items},
                "viewed_sku_excluded",
            )

        if result is None:
            failures.append("no_result")
            return _result_row(case, initial, result, failures)

        _check(
            failures,
            all(item.stock.status != "out_of_stock" for item in result.items),
            "all_items_live_in_stock",
        )
        audit_ids = {result.rec_id}
        if initial is not None:
            audit_ids.add(initial.rec_id)
        audits = {rec_id: _audit_row(service.conn, rec_id) for rec_id in audit_ids}
        _check(
            failures,
            all(row is not None for row in audits.values()),
            "audit_row_written",
        )
        _check(
            failures,
            initial is not None
            and initial.latency_ms <= LATENCY_LIMIT_MS
            and result.latency_ms <= LATENCY_LIMIT_MS,
            "latency_within_15_seconds",
        )
        initial_audit = audits.get(initial.rec_id) if initial else None
        masked_message = (
            initial_audit["user_message_masked"]
            if initial_audit is not None
            else ""
        ) or ""
        _check(
            failures,
            not EMAIL_RE.search(masked_message)
            and not PHONE_RE.search(masked_message),
            "audit_message_has_no_email_or_phone",
        )
        _check(
            failures,
            viewed_sku is None
            or viewed_sku not in {item.sku for item in result.items},
            "viewed_sku_not_recommended",
        )
        _check(
            failures,
            len(result.items) >= int(case.get("min_recs", 0)),
            "minimum_recommendation_count",
        )
        categories_any = case.get("categories_any", [])
        if categories_any and result.items:
            matching = sum(
                item.category in categories_any for item in result.items
            )
            _check(
                failures,
                matching / len(result.items) >= 0.6,
                "category_match_at_least_60_percent",
            )
        max_price = case.get("max_effective_price")
        if max_price is not None:
            _check(
                failures,
                all(
                    item.price.effective_price <= float(max_price)
                    for item in result.items
                ),
                "effective_price_within_budget",
            )

        if scenario == "off_topic":
            _check(failures, result.intent == "off_topic", "off_topic_intent")
            _check(failures, bool(result.reply.strip()), "off_topic_reply")
            _check(failures, not result.items, "off_topic_has_no_cards")
        elif scenario == "no_consent":
            _check(
                failures,
                "no_consent" in initial.flags,
                "no_consent_flag",
            )
            tool_calls = (
                initial_audit["tool_calls"] if initial_audit is not None else "[]"
            )
            _check(
                failures,
                "recent_events" not in tool_calls,
                "no_consent_profile_has_no_recent_events",
            )

        return _result_row(case, initial, result, failures)
    except Exception as exc:
        LOGGER.error(
            "Evaluation case %s failed (%s)",
            case.get("id", "unknown"),
            type(exc).__name__,
        )
        failures.append(f"exception:{type(exc).__name__}")
        return _result_row(case, initial, result, failures)


def _result_row(
    case: dict[str, Any],
    initial: RecResult | None,
    result: RecResult | None,
    failures: list[str],
) -> dict[str, Any]:
    return {
        "id": case.get("id", "unknown"),
        "passed": not failures,
        "failures": failures,
        "recommendation_count": len(result.items) if result else 0,
        "latency_ms": initial.latency_ms if initial else None,
        "fallback_used": result.fallback_used if result else None,
    }


def main() -> int:
    """Run all labelled cases, persist the report, and enforce the pass threshold."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    for handler in logging.getLogger().handlers:
        handler.addFilter(_SuppressRequestUrlFilter())
    try:
        settings = get_settings()
    except ConfigError as exc:
        LOGGER.error("%s", exc)
        return 1

    try:
        cases = json.loads(EVAL_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        LOGGER.error("Could not load evaluation set (%s)", type(exc).__name__)
        return 1
    if not isinstance(cases, list) or not cases:
        LOGGER.error("Evaluation set must be a non-empty JSON list.")
        return 1

    conn = get_conn(settings.db_path)
    try:
        service = RecommendationService(
            settings=settings,
            llm=AzureLLMClient(settings),
            conn=conn,
        )
        results = [_run_case(case, service) for case in cases]
    finally:
        conn.close()

    passed = sum(result["passed"] for result in results)
    total = len(results)
    pass_rate = passed / total
    report = {
        "passed": passed,
        "total": total,
        "pass_rate": round(pass_rate, 4),
        "threshold": PASS_THRESHOLD,
        "results": results,
    }
    try:
        REPORT_PATH.write_text(
            json.dumps(report, indent=2) + "\n",
            encoding="utf-8",
        )
    except OSError as exc:
        LOGGER.error("Could not write evaluation report (%s)", type(exc).__name__)
        return 1

    print(f"{'CASE':<5} {'RESULT':<6} {'RECS':>4} {'LATENCY_MS':>10} DETAILS")
    for result in results:
        detail = ", ".join(result["failures"]) or "-"
        latency = (
            str(result["latency_ms"])
            if result["latency_ms"] is not None
            else "n/a"
        )
        print(
            f"{result['id']:<5} "
            f"{'PASS' if result['passed'] else 'FAIL':<6} "
            f"{result['recommendation_count']:>4} "
            f"{latency:>10} {detail}"
        )
    print(f"Overall: {passed}/{total} ({pass_rate:.0%}); threshold {PASS_THRESHOLD:.0%}")
    print(f"Report: {REPORT_PATH}")
    return 0 if pass_rate >= PASS_THRESHOLD else 1


if __name__ == "__main__":
    sys.exit(main())
