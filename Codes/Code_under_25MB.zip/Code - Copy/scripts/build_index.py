"""Build the persistent Chroma index for curated product records."""

import argparse
import chromadb
from pathlib import Path

from retailrec.config import get_settings
from retailrec.db import get_conn
from retailrec.llm import AzureLLMClient


BATCH_SIZE = 100


def build_index(reset: bool = False) -> int:
    """Embed curated catalog rows and return the resulting collection count."""
    settings = get_settings()
    conn = get_conn(settings.db_path)
    rows = conn.execute(
        """SELECT sku, name, category, subcategory, base_price, brand,
                  description, tags
           FROM products WHERE embedded = 1 ORDER BY sku"""
    ).fetchall()
    conn.close()
    if not rows:
        raise RuntimeError("No embedded products found; run scripts/generate_data.py")

    chroma_path = Path(settings.chroma_path)
    chroma_path.mkdir(parents=True, exist_ok=True)
    client = chromadb.PersistentClient(
        path=str(chroma_path),
        settings=chromadb.Settings(anonymized_telemetry=False),
    )
    existing = {collection.name for collection in client.list_collections()}
    if "products" in existing and reset:
        client.delete_collection("products")
        existing.remove("products")
    if "products" in existing:
        collection = client.get_collection("products")
    else:
        collection = client.create_collection(
            name="products",
            metadata={"hnsw:space": "cosine"},
        )

    llm = AzureLLMClient(settings)
    for start in range(0, len(rows), BATCH_SIZE):
        batch = rows[start : start + BATCH_SIZE]
        documents = [
            f"{row['name']}. {row['category']} / {row['subcategory']}. "
            f"{row['description']} Tags: {row['tags']}"
            for row in batch
        ]
        vectors = llm.embed(documents)
        if len(vectors) != len(batch):
            raise RuntimeError(
                f"Embedding batch returned {len(vectors)} vectors for {len(batch)} products"
            )
        collection.add(
            ids=[row["sku"] for row in batch],
            embeddings=vectors,
            documents=documents,
            metadatas=[
                {
                    "sku": row["sku"],
                    "category": row["category"],
                    "subcategory": row["subcategory"],
                    "base_price": float(row["base_price"]),
                    "brand": row["brand"],
                }
                for row in batch
            ],
        )
        print(f"Embedded {min(start + len(batch), len(rows))}/{len(rows)}")

    count = collection.count()
    print(f"Chroma products count: {count}")
    query_vector = llm.embed(["running shoes"])
    results = collection.query(
        query_embeddings=query_vector,
        n_results=min(5, count),
        include=["metadatas", "distances", "documents"],
    )
    hits = results.get("metadatas", [[]])[0]
    print(
        "Self-test running shoes: "
        + ", ".join(
            f"{hit['sku']} ({hit['subcategory']})" for hit in hits
        )
    )
    return count


def main() -> int:
    """Parse build options and create the product collection."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Delete and rebuild the Chroma products collection.",
    )
    args = parser.parse_args()
    count = build_index(reset=args.reset)
    if count != 2000:
        raise RuntimeError(f"Expected 2000 indexed products, found {count}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
