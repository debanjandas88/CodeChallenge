"""Generate deterministic synthetic products, shoppers, and events."""

import argparse
from datetime import datetime, timedelta, timezone
from faker import Faker
import hashlib
import json
from pathlib import Path
import random
import sqlite3
import statistics

from retailrec.config import get_settings
from retailrec.db import get_conn, init_schema, now_iso


ROOT = Path(__file__).resolve().parents[1]
BATCH_SIZE = 5000
MODEL_NAMES = ("Pro", "Lite", "Max", "2", "3", "X", "Plus", "One")
REGIONS = ("EU-DE", "EU-FR", "UK-LON", "US-CA")
AGE_BANDS = ("18-24", "25-34", "35-44", "45-54")
EVENT_WEIGHTS = (("view", 70), ("add_to_cart", 20), ("purchase", 10))
CATEGORY_IMAGE_IDS = {
    "Electronics": "photo-1498049794561-7780e7231661",
    "Home & Kitchen": "photo-1556911220-e15b29be8c8f",
    "Fashion": "photo-1483985988355-763728e1935b",
    "Sports & Outdoors": "photo-1461896836934-ffe607ba8211",
    "Beauty & Personal Care": "photo-1596462502278-27bfdc403348",
    "Toys & Baby": "photo-1596461404969-9ae70f2830c1",
    "Books & Stationery": "photo-1512820790803-83ca734da794",
    "Office & Work": "photo-1497366216548-37526070297c",
    "Garden & Outdoor Living": "photo-1416879595882-3373a0480b5b",
    "Pet Supplies": "photo-1450778869180-41d0601e046e",
}


def _image_url(category: str) -> str | None:
    """Return a category illustration URL when one is configured."""
    photo_id = CATEGORY_IMAGE_IDS.get(category)
    if photo_id is None:
        return None
    return f"https://images.unsplash.com/{photo_id}?auto=format&fit=crop&w=640&q=80"


def _load_json(path: Path) -> dict:
    """Load a UTF-8 JSON object."""
    with path.open(encoding="utf-8") as file:
        return json.load(file)


def _product_rows(
    categories: list[dict], rng: random.Random, catalog_size: int
) -> tuple[list[tuple], list[tuple], dict[str, list[tuple]]]:
    """Build product and inventory rows in deterministic category order."""
    subcategories = [
        (category, subcategory)
        for category in categories
        for subcategory in category["subcategories"]
    ]
    if catalog_size != 50000:
        if catalog_size <= 0 or catalog_size % len(subcategories):
            raise ValueError("CATALOG_SIZE must be a positive multiple of 50")
        products_per_subcategory = catalog_size // len(subcategories)
    else:
        products_per_subcategory = 1000

    products: list[tuple] = []
    inventory: list[tuple] = []
    product_details: dict[str, list[tuple]] = {
        category["name"]: [] for category in categories
    }
    sku_number = 1
    for category, subcategory in subcategories:
        for _ in range(products_per_subcategory):
            brand = rng.choice(subcategory["brands"])
            adjective = rng.choice(subcategory["adjectives"])
            noun = rng.choice(subcategory["nouns"])
            model = rng.choice(MODEL_NAMES)
            name = f"{brand} {adjective} {noun} {model}"
            features = rng.sample(subcategory["features"], 2)
            use_case = rng.choice(subcategory["use_cases"])
            description = (
                f"{adjective} {noun} from {brand}. {features[0]} {features[1]} "
                f"Ideal for {use_case}."
            )
            tags = ",".join(rng.sample(subcategory["tags"], 4))
            raw_price = rng.uniform(
                subcategory["price_min"], subcategory["price_max"]
            )
            price = min(
                subcategory["price_max"], float(int(raw_price)) + 0.99
            )
            rating = round(rng.triangular(3.0, 5.0, 4.4), 1)
            popularity = round(min(100.0, rng.paretovariate(1.5) * 8), 1)

            stock_roll = rng.random()
            if stock_roll < 0.10:
                qty = 0
            elif stock_roll < 0.30:
                qty = rng.randint(1, 19)
            else:
                qty = rng.randint(20, 200)

            sku = f"{category['code']}-{sku_number:05d}"
            sku_number += 1
            products.append(
                (
                    sku,
                    name,
                    description,
                    category["name"],
                    subcategory["name"],
                    brand,
                    price,
                    tags,
                    rating,
                    popularity,
                    0,
                    _image_url(category["name"]),
                )
            )
            inventory.append((sku, qty, qty, now_iso()))
            product_details[category["name"]].append(
                (sku, name, category["name"], qty, popularity)
            )
    return products, inventory, product_details


def _insert_products(
    conn: sqlite3.Connection, products: list[tuple], inventory: list[tuple]
) -> None:
    """Insert product and inventory rows in bounded batches."""
    for start in range(0, len(products), BATCH_SIZE):
        batch = products[start : start + BATCH_SIZE]
        conn.executemany(
            """INSERT INTO products
               (sku, name, description, category, subcategory, brand, base_price,
                tags, rating, popularity, embedded, image_url)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            batch,
        )
        conn.executemany(
            """INSERT INTO inventory (sku, stock_qty, initial_qty, updated_at)
               VALUES (?, ?, ?, ?)""",
            inventory[start : start + BATCH_SIZE],
        )


def _insert_promotions(
    conn: sqlite3.Connection, products: list[tuple], rng: random.Random
) -> None:
    """Insert the 300 deterministic standing SKU promotions."""
    now = datetime.now(timezone.utc)
    starts_at = (now - timedelta(days=1)).isoformat(timespec="seconds")
    selected = rng.sample(products, 300)
    conn.executemany(
        """INSERT INTO promotions
           (promo_id, scope_type, scope_value, discount_pct, label, is_flash,
            starts_at, ends_at)
           VALUES (?, 'sku', ?, ?, ?, 0, ?, NULL)""",
        [
            (
                f"STD-{index:04d}",
                row[0],
                pct,
                f"Weekly Deal {pct}% off",
                starts_at,
            )
            for index, (row, pct) in enumerate(
                ((row, rng.choice((10, 15, 20, 25, 30))) for row in selected),
                start=1,
            )
        ],
    )


def _make_customers(
    conn: sqlite3.Connection,
    personas: list[dict],
    rng: random.Random,
    pseudo_salt: str,
    product_details: dict[str, list[tuple]],
) -> None:
    """Insert synthetic customers and 25 pseudonymous history events each."""
    faker = Faker()
    faker.seed_instance(rng.randint(0, 2**31 - 1))
    for persona in personas:
        for customer_id in persona["customer_ids"]:
            display_name = faker.name()
            email = f"{customer_id.lower()}.{faker.unique.user_name()}@example.com"
            region = REGIONS[(int(customer_id[1:]) - 1) % len(REGIONS)]
            age_band = AGE_BANDS[(int(customer_id[1:]) - 1) % len(AGE_BANDS)]
            preferred = persona["preferred_categories"]
            consent = int(customer_id != "C12")
            conn.execute(
                """INSERT INTO customers
                   (customer_id, display_name, email, persona, age_band, region,
                    preferred_categories, price_sensitivity,
                    consent_personalization)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    customer_id,
                    display_name,
                    email,
                    persona["name"],
                    age_band,
                    region,
                    ", ".join(preferred),
                    persona["price_sensitivity"],
                    consent,
                ),
            )

            pseudo_id = "u_" + hashlib.sha256(
                f"{pseudo_salt}:{customer_id}".encode("utf-8")
            ).hexdigest()[:12]
            category_medians = {
                category: statistics.median(
                    product[4] for product in products
                )
                for category, products in product_details.items()
            }
            preferred_products = [
                product
                for category in preferred
                for product in product_details[category]
                if product[3] > 0 and product[4] > category_medians[category]
            ]
            other_products = [
                product
                for category, items in product_details.items()
                if category not in preferred
                for product in items
                if product[3] > 0 and product[4] > category_medians[category]
            ]
            if not preferred_products or not other_products:
                raise ValueError("Cannot create event history without in-stock products")
            history = []
            now = datetime.now(timezone.utc)
            for _ in range(25):
                pool = preferred_products if rng.random() < 0.8 else other_products
                product = rng.choice(pool)
                event_type = rng.choices(
                    [name for name, _ in EVENT_WEIGHTS],
                    weights=[weight for _, weight in EVENT_WEIGHTS],
                    k=1,
                )[0]
                event_ts = now - timedelta(
                    seconds=rng.randint(0, 30 * 24 * 60 * 60)
                )
                history.append(
                    (
                        pseudo_id,
                        None,
                        event_type,
                        product[0],
                        None,
                        None,
                        None,
                        event_ts.isoformat(timespec="seconds"),
                    )
                )
            conn.executemany(
                """INSERT INTO events
                   (pseudo_id, session_id, event_type, sku, rec_id, mode,
                    meta_json, ts)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                history,
            )


def _mark_embedded(
    conn: sqlite3.Connection, categories: list[dict], per_subcategory: int
) -> None:
    """Mark the most popular in-stock SKUs in each subcategory."""
    if per_subcategory <= 0:
        raise ValueError("EMBED_SUBSET_PER_SUBCATEGORY must be positive")
    for category in categories:
        for subcategory in category["subcategories"]:
            conn.execute(
                """UPDATE products SET embedded = 1 WHERE sku IN (
                       SELECT p.sku FROM products p
                       JOIN inventory i ON i.sku = p.sku
                       WHERE p.subcategory = ? AND i.stock_qty > 0
                       ORDER BY p.popularity DESC, p.sku
                       LIMIT ?
                   )""",
                (subcategory["name"], per_subcategory),
            )


def generate(seed: int | None = None) -> dict[str, int]:
    """Rebuild the synthetic database and return table counts."""
    settings = get_settings()
    actual_seed = settings.random_seed if seed is None else seed
    rng = random.Random(actual_seed)
    vocab = _load_json(ROOT / "data" / "vocab.json")
    personas_data = _load_json(ROOT / "data" / "personas.json")

    conn = get_conn(settings.db_path)
    conn.execute("PRAGMA synchronous=OFF")
    init_schema(conn, reset=True)
    products, inventory, product_details = _product_rows(
        vocab["categories"], rng, settings.catalog_size
    )
    with conn:
        _insert_products(conn, products, inventory)
        _insert_promotions(conn, products, rng)
        _make_customers(
            conn,
            personas_data["personas"],
            rng,
            settings.pseudo_salt,
            product_details,
        )
        _mark_embedded(
            conn, vocab["categories"], settings.embed_subset_per_subcategory
        )
    counts = {
        table: conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        for table in ("products", "inventory", "promotions", "customers", "events")
    }
    counts["embedded"] = conn.execute(
        "SELECT COUNT(*) FROM products WHERE embedded = 1"
    ).fetchone()[0]
    conn.close()
    return counts


def main() -> int:
    """Parse options, generate data, and print actual row counts."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=None)
    args = parser.parse_args()
    counts = generate(args.seed)
    for table, count in counts.items():
        print(f"{table}: {count}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
