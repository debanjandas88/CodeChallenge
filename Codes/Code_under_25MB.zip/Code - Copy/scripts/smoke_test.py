"""Run Azure, data/index, and recommendation smoke checks."""

import argparse
import logging
import sys

import chromadb

from retailrec.config import ConfigError, get_settings
from retailrec.llm import AzureLLMClient, LLMUnavailable


LOGGER = logging.getLogger("smoke_test")


class _SuppressRequestUrlFilter(logging.Filter):
    """Keep SDK request URLs out of smoke-test output."""

    def filter(self, record: logging.LogRecord) -> bool:
        return not record.getMessage().startswith("HTTP Request:")


def main() -> int:
    """Run selected smoke checks and return a process status."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--azure-only",
        action="store_true",
        help="Run only the Azure chat and embedding check (S-01).",
    )
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)
    for handler in logging.getLogger().handlers:
        handler.addFilter(_SuppressRequestUrlFilter())

    try:
        settings = get_settings()
    except ConfigError as exc:
        LOGGER.error("%s", exc)
        return 1

    try:
        llm = AzureLLMClient(settings)
        chat = llm.chat(
            [{"role": "user", "content": "Reply with OK"}],
            tool_choice="none",
            temperature=0,
            max_tokens=800,
        )
        if not chat.content or not chat.content.strip():
            LOGGER.error("FAIL S-01 Azure chat returned empty content")
            return 1
        vectors = llm.embed(["ShopSmart Azure embedding smoke test"])
        if not vectors or not vectors[0]:
            LOGGER.error("FAIL S-01 Azure embeddings returned no vector")
            return 1
        LOGGER.info("PASS S-01 Azure chat and embedding")
    except LLMUnavailable as exc:
        LOGGER.error("FAIL S-01 Azure service unavailable (%s)", type(exc).__name__)
        return 1

    if args.azure_only:
        return 0

    from retailrec.db import get_conn
    from retailrec.service import RecommendationService

    conn = get_conn(settings.db_path)
    counts = {
        "products": conn.execute("SELECT COUNT(*) FROM products").fetchone()[0],
        "inventory": conn.execute("SELECT COUNT(*) FROM inventory").fetchone()[0],
        "customers": conn.execute("SELECT COUNT(*) FROM customers").fetchone()[0],
        "events": conn.execute("SELECT COUNT(*) FROM events").fetchone()[0],
        "embedded": conn.execute(
            "SELECT COUNT(*) FROM products WHERE embedded = 1"
        ).fetchone()[0],
    }
    client = chromadb.PersistentClient(
        path=settings.chroma_path,
        settings=chromadb.Settings(anonymized_telemetry=False),
    )
    chroma_count = client.get_collection("products").count()
    if (
        counts["products"] != 50000
        or counts["inventory"] != 50000
        or counts["customers"] != 12
        or counts["events"] < 300
        or counts["embedded"] != 2000
        or chroma_count != 2000
    ):
        LOGGER.error(
            "FAIL S-02 data/index counts: products=%d inventory=%d customers=%d "
            "events=%d embedded=%d chroma=%d",
            counts["products"],
            counts["inventory"],
            counts["customers"],
            counts["events"],
            counts["embedded"],
            chroma_count,
        )
        return 1
    LOGGER.info("PASS S-02 data and index counts")

    service = RecommendationService(settings=settings, llm=llm, conn=conn)
    customer = next(
        c for c in service.list_customers() if c["customer_id"] == "C01"
    )
    ctx = service.start_session(customer["customer_id"], mode="ai")
    result = service.recommend(ctx, trigger="home")
    valid_items = bool(result.items) and all(
        item.stock.status != "out_of_stock" for item in result.items
    )
    audit_exists = conn.execute(
        "SELECT 1 FROM audit_log WHERE rec_id = ?", (result.rec_id,)
    ).fetchone() is not None
    if not (3 <= len(result.items) <= 5 and valid_items and audit_exists):
        LOGGER.error(
            "FAIL S-03 audited recommendation: item_count=%d live_valid=%s audit=%s",
            len(result.items),
            valid_items,
            audit_exists,
        )
        return 1
    LOGGER.info("PASS S-03 audited live-valid recommendation")
    return 0


if __name__ == "__main__":
    sys.exit(main())
