# ShopSmart Walkthrough

This guide follows the implemented local demo from a clean data build through browsing, recommendations, simulation, and evaluation. Use a configured Azure OpenAI resource; no live retailer service is connected.

## 1. Prepare the demo

From the repository root in PowerShell, activate the project virtual environment and make sure `.env` has the required Azure settings and a non-default `PSEUDO_SALT`. Do not share the API key.

For a clean local dataset and index:

```powershell
python scripts/generate_data.py
python scripts/build_index.py --reset
python scripts/smoke_test.py
```

`generate_data.py` drops and recreates the SQLite application tables. It resets demo accounts and prior sessions, feedback, events, and audit history. The default generation contains 50,000 products and inventory rows, 300 standing promotions, 12 synthetic shoppers, and 300 seeded history events. The build script embeds the selected 2,000 products in the persistent Chroma `products` collection.

The full smoke command checks Azure chat/embeddings (S-01), database/index counts (S-02), and an audited recommendation with live-valid items (S-03). To check only the Azure connection before generating data, run:

```powershell
python scripts/smoke_test.py --azure-only
```

## 2. Enter the storefront

Start Streamlit:

```powershell
streamlit run app/streamlit_app.py
```

Open the local address printed in the terminal, normally `http://localhost:8501`.

On the entry screen, either:

- Create a demo account with a display name and email. No password is requested. A new local shopper record is created and the app opens its AI storefront; or
- Select one of the seeded shoppers and choose **AI assistant** or **Baseline (popularity)**, then click **Continue to storefront**.

The seeded C12 profile has personalization consent disabled. Demo account creation is lightweight local onboarding, not secure authentication.

## 3. Browse, view, and inspect recommendations

The storefront shows up to five recommendation cards, a category browser, and a shopping assistant. Cards show the product name, category, price, stock state, and recommendation reason. A promotion is shown when a current discount applies. If a remote image cannot be loaded, the UI renders a category-based placeholder.

Choose a category in **Browse** and click **View** on a product. The app records a view event, opens product details, and asks for complementary or alternative picks. The viewed SKU is excluded from that recommendation result. On a recommendation card, **View** also records a recommendation click before recording the view.

The **Why this?** expander shows the card origin, retrieval score, tools used, and recommendation ID. This is provenance for the demo, not a guarantee that every natural-language explanation is independently verified.

## 4. Chat with the shopping assistant

Try a shopping request such as:

> I need a gift for my dad who loves coffee, under $60.

The app masks common personal identifiers in chat text before it is displayed in the chat history or passed into the recommendation flow. The Azure model can call four local tools:

1. `search_catalog` for semantic retrieval with optional category and base-price filters;
2. `check_inventory` for current stock;
3. `get_pricing_and_promotions` for effective prices; and
4. `get_user_profile` for consent-appropriate profile and recent-event data.

The agent returns a structured response that is validated before use. The service verifies proposed items against the SQLite catalog and live stub data, removes unavailable or excluded SKUs, and backfills from the retrieved candidate pool where possible. If the model fails, returns low confidence, or leaves no valid recommendations, the service uses a popular in-stock fallback. Off-topic requests may return a redirect without product cards.

The UI keeps a short chat history (up to 12 role messages). A `rec_impression` event is recorded when recommendations are generated or refreshed, not on ordinary Streamlit reruns.

## 5. Try feedback and storefront simulations

Each recommendation card has **👍**, **👎**, **View**, and **Add to cart** actions. Feedback is stored for the current recommendation card, and the click/cart controls record events.

In the sidebar:

- **Mark out of stock** sets the selected displayed SKU to zero stock and refreshes the prior recommendation result. Refresh rechecks stock and price without making another LLM call; an unavailable item is removed and other verified candidates may replace it.
- **Start flash sale** creates a time-limited category promotion and refreshes the result, so the UI can show updated effective prices and promotion labels.
- **Reset stock and sales** restores inventory to initial quantities and clears flash sales.
- **Refresh** revalidates the current cards without another LLM call.

The metrics panel shows impressions, CTR, add-to-cart rate, satisfaction, and session duration. These are illustrative session counters: CTR is recommendation clicks divided by impressions; add-to-cart rate is carts divided by impressions; satisfaction is thumbs-up divided by all ratings. The app also shows a per-mode table and the most recent five audit records.

## 6. Follow one recommendation through the code

```mermaid
sequenceDiagram
    participant Shopper
    participant UI as Streamlit app
    participant Service as RecommendationService
    participant Retrieval as Chroma + SQLite
    participant Agent as Azure agent + tools
    participant Retail as SQLite stock/pricing stubs
    participant Store as SQLite audit/events

    Shopper->>UI: Browse, view, or submit chat
    UI->>Service: recommend(context, trigger, ...)
    Service->>Service: Mask input and build consent-aware context
    Service->>Retrieval: Embed query and fetch candidate products
    Retrieval-->>Service: Candidate pool
    Service->>Agent: Run bounded tool-calling loop
    Agent->>Retail: Check inventory and effective prices
    Retail-->>Agent: Stock and promotion results
    Agent-->>Service: Structured recommendation output
    Service->>Service: Validate schema, SKU, stock, price, exclusions
    Service->>Store: Persist events and recommendation audit
    Service-->>UI: Verified cards, reply, and state
    UI-->>Shopper: Render storefront
```

The relevant implementation is organized as follows:

| Area                                | Files                                                                                 |
| ----------------------------------- | ------------------------------------------------------------------------------------- |
| UI and session state                | `app/streamlit_app.py`                                                              |
| Orchestration and refresh           | `src/retailrec/service.py`, `src/retailrec/agent.py`                              |
| Azure client and prompts            | `src/retailrec/llm.py`, `src/retailrec/prompts.py`                                |
| Retrieval and tool execution        | `src/retailrec/retrieval.py`, `src/retailrec/tools.py`                            |
| Output checks and fallback          | `src/retailrec/guardrails.py`, `src/retailrec/fallback.py`                        |
| Privacy, audit, events, and metrics | `src/retailrec/privacy.py`, `src/retailrec/audit.py`, `src/retailrec/events.py` |
| SQLite services and schema          | `src/retailrec/services/`, `src/retailrec/db.py`                                  |

SQLite stores products, inventory, promotions, customers, sessions, events, feedback, and audit records. Chroma stores the persistent vector index. Azure OpenAI is used for chat/tool calls and embeddings; there is no alternate LLM provider or orchestration framework.

### Test coverage and extension seams

The 32-test unit suite uses SQLite fixtures and injects `FakeLLM` for agent/service tests; it makes no Azure calls. It covers PII masking, pseudonymization and consent, retrieval filters, tool schemas, structured-output validation, stock/price simulation, recommendation fallback and fail-closed behavior, audit/events/metrics, and Streamlit onboarding, browsing, viewing, and image placeholders. The smoke script separately checks the configured Azure deployments and the generated database/index. The 15-case evaluation exercises recommendation quality and operational scenarios such as no-consent, viewed-item exclusion, stock-out refresh, and flash-sale refresh.

`InventoryService` and `PricingService` in `src/retailrec/services/base.py` define the stock and pricing contracts, and `LLMClient` in `src/retailrec/llm.py` defines the interface used by retrieval and the agent. These are implementation seams, not selectable production integrations: the current service wires SQLite stubs and raises an error for any `API_BACKEND` other than `stub`; the optional HTTP backend is not implemented. Unit tests can inject `FakeLLM` without changing the app's Azure-only runtime behavior.

## 7. Run the evaluation

Run the 15 labelled scenarios from the repository root:

```powershell
python scripts/run_eval.py
```

The evaluator checks live stock, auditing, masked chat data, viewed-SKU exclusion, case-specific category/budget behavior, consent, off-topic handling, stock-out refresh, flash-sale refresh, and per-case latency. It writes `data/eval_report.json` and exits successfully when at least 12 of 15 cases pass.

Latest recorded run: **14/15 (93%)**, exit code **0** against the 80% overall threshold. **E01 took 15,465 ms**, exceeding the per-case 15,000 ms limit by 465 ms, so the overall pass does not mean every case passed. Model output and Azure latency vary across runs. The evaluation adds local test sessions/events/audit records; its stock and flash-sale scenarios restore stock and clear simulated promotions.

## 8. Demo boundaries

This project uses synthetic shopper/product data and local SQLite stubs. It does not provide production authentication, checkout, payments, product administration, real retailer integrations, a deployed service, or a functioning HTTP mock backend. The AI-vs-baseline metrics are not a statistically valid A/B test. PII masking and consent handling are prototype controls, not legal certification.
