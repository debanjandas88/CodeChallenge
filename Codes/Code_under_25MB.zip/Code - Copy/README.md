# ShopSmart

ShopSmart is a local proof-of-concept retail storefront with synthetic products and shoppers. It combines a Streamlit shopping experience with Azure OpenAI recommendations, Chroma retrieval, and SQLite-backed stock and promotion simulations.

This is a demo, not a production storefront: accounts are local demo records without passwords, and the catalog, shoppers, inventory, and purchase history are synthetic.

## What it demonstrates

- Create a lightweight demo account or continue with one of 12 seeded shoppers; switch between AI recommendations and a popularity baseline.
- Browse 50,000 synthetic products, open details, and see an image or category placeholder.
- Search a curated 2,000-product Chroma index, then use an Azure OpenAI tool-calling agent to produce conversational recommendations.
- Recheck stock and effective prices before recommendations are displayed; simulate stock-outs and flash sales with SQLite-backed stubs.
- Mask common personal identifiers in shopper messages, use salted pseudonymous event IDs, honor personalization consent, and record recommendation audit rows.
- Capture clicks, add-to-cart events, and thumbs-up/down feedback; display illustrative session metrics.

The optional HTTP inventory/pricing API described in the design is deferred. `API_BACKEND=stub` is the only supported mode.

## Requirements

- Windows with Python 3.11 or newer. The project was validated with Python 3.12.8.
- An Azure OpenAI resource with a chat deployment that supports function calling and an embedding deployment.
- PowerShell opened in the repository root.

Python package versions are pinned in [`requirements.txt`](./requirements.txt). The package is installed from [`pyproject.toml`](./pyproject.toml).

## Setup

Create and activate a virtual environment, then install the project:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pip install -e .
```

Create your local configuration from [`.env.example`](./.env.example) and edit `.env` on your machine:

```powershell
Copy-Item .env.example .env
```

Set these required variables in `.env`:

| Variable | Purpose |
|---|---|
| `AZURE_OPENAI_ENDPOINT` | Azure OpenAI resource endpoint |
| `AZURE_OPENAI_API_KEY` | Azure OpenAI API key |
| `AZURE_OPENAI_API_VERSION` | API version; defaults to `2024-10-21` |
| `AZURE_OPENAI_CHAT_DEPLOYMENT` | Chat deployment name |
| `AZURE_OPENAI_EMBED_DEPLOYMENT` | Embedding deployment name |
| `PSEUDO_SALT` | Non-default salt used to pseudonymize shopper IDs |

Replace the sample `PSEUDO_SALT` value with a non-default local value. Keep the real `.env` local. It is ignored by Git; do not paste credentials into chat or commit them. Optional paths and data-generation settings are prefilled in `.env.example`.

## Build data and run checks

Run these commands from the repository root with the virtual environment active:

```powershell
python scripts/smoke_test.py --azure-only
python scripts/generate_data.py
python scripts/build_index.py --reset
python scripts/smoke_test.py
python -m pytest -q
python scripts/run_eval.py
```

`generate_data.py` rebuilds the SQLite database. With the default settings it creates 50,000 products and inventory rows, 300 standing promotions, 12 synthetic customers, and 300 historical events; 2,000 in-stock products are selected for embeddings. `build_index.py --reset` recreates the persistent Chroma `products` collection from that selection.

The smoke checks are:

- S-01: Azure chat and embedding responses are non-empty.
- S-02: expected database and Chroma counts.
- S-03: an audited recommendation returns live-valid products.

The evaluation runs the 15 cases in [`data/eval_set.json`](./data/eval_set.json), prints per-case results, and writes the generated report to `data/eval_report.json`. It passes when at least 80% of cases pass. Evaluation calls Azure and writes test sessions/events/audit data to the local database; its stock and flash-sale scenarios restore stock and clear simulated sales afterward.

Latest recorded validation: 32 unit tests passed, S-01–S-03 passed, and the clean-start evaluation passed 14/15 cases (93%) with exit code 0 against the 80% threshold. E01 took 15,465 ms, exceeding the per-case 15-second limit by 465 ms; this is a known evaluation limitation. Azure latency and model output can vary between runs.

## Start the storefront

After configuration, data generation, and index construction:

```powershell
streamlit run app/streamlit_app.py
```

Open the local URL printed by Streamlit (normally `http://localhost:8501`). Create a demo account or choose a seeded shopper. The sidebar can switch between AI and baseline modes, simulate stock/promotion changes, refresh recommendations, and show metrics and recent audit records. The browse and recommendation cards include image fallbacks when a remote image is missing or unavailable.

## Project layout

```text
app/streamlit_app.py            Streamlit storefront
src/retailrec/                  Recommendation, privacy, retrieval, and data services
src/retailrec/services/         SQLite inventory and pricing/promotion stubs
scripts/generate_data.py        Synthetic SQLite data generation
scripts/build_index.py          Azure embedding and Chroma index build
scripts/smoke_test.py           Azure, data/index, and recommendation checks
scripts/run_eval.py             Labelled recommendation evaluation
data/vocab.json                 Synthetic catalog vocabulary
data/personas.json              Synthetic shopper personas
data/eval_set.json              E01–E15 evaluation cases
tests/                          Unit and Streamlit AppTest coverage
SDD.md                          Design source of truth
implementation_plan.md          Approved build plan
task_tracker.md                 Current progress and handoff record
```

Generated files such as `data/catalog.db`, `data/chroma/`, and `data/eval_report.json` are local and ignored.

## Configuration and troubleshooting

- Missing required settings: check the five required variables in `.env`, then restart the app or command.
- Azure deployment or connectivity errors: confirm the endpoint, deployment names, API version, and resource availability locally. Never include the API key in error reports.
- Missing Chroma collection or embeddings: run `python scripts/generate_data.py`, then `python scripts/build_index.py --reset`.
- Missing or broken product images: the UI uses a category-based placeholder; browsing remains available.
- Empty results after a simulated stock change: use **Refresh** or reset the simulation; only live-verified stock and price data are shown.

## Limitations

- All shoppers, products, prices, and events are synthetic; stock and promotion integrations are local SQLite stubs.
- The AI vs baseline metrics are illustrative counters, not a statistically valid experiment.
- Demo accounts are not authentication. There is no checkout, payment processing, product administration, or connection to a real retailer.
- PII masking and consent controls are prototype safeguards, not a claim of legal or regulatory certification.
- The optional HTTP API backend is not implemented; leave `API_BACKEND=stub`.
- The latest evaluation met the overall 80% gate but had one latency failure (E01); see the exact result above and `data/eval_report.json`.
