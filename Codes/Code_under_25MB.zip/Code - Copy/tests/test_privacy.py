"""Tests for masking and pseudonymization."""

from retailrec.privacy import build_llm_profile, mask_text, pseudonymize


def test_mask_email_phone_card_name():
    text = (
        "I am Anna Lee, mail anna.lee@x.com, call +44 7700 900123, "
        "card 4111 1111 1111 1111"
    )
    masked, entities = mask_text(text, known_names=["Anna Lee"])
    assert masked == (
        "I am [NAME], mail [EMAIL], call [PHONE], card [CARD]"
    )
    assert entities == ["CARD", "EMAIL", "NAME", "PHONE"]


def test_pseudonym_stable_and_opaque():
    first = pseudonymize("C01", "salt-one")
    assert first == pseudonymize("C01", "salt-one")
    assert first != pseudonymize("C01", "salt-two")
    assert first.startswith("u_")
    assert "C01" not in first


def test_llm_profile_honors_consent():
    customer = {
        "customer_id": "C01",
        "display_name": "Anna Lee",
        "email": "anna.lee@example.com",
        "persona": "fitness_fan",
        "age_band": "25-34",
        "region": "EU-DE",
        "preferred_categories": "Sports & Outdoors, Electronics",
        "price_sensitivity": "medium",
    }
    assert build_llm_profile(customer, False) == {"consent": False}
    profile = build_llm_profile(customer, True)
    assert profile["preferred_categories"] == ["Sports & Outdoors", "Electronics"]
    assert profile["region_group"] == "EU"
    assert "customer_id" not in profile and "display_name" not in profile
    assert "email" not in profile
