"""Tests for structured output and live recommendation validation."""

import json

import pytest

from retailrec.guardrails import (
    ValidationFailed,
    enforce_live_constraints,
    parse_and_validate,
)
from retailrec.models import AgentOutput, Recommendation
from retailrec.services.inventory_stub import SqliteInventoryService
from retailrec.services.pricing_stub import SqlitePricingService


def test_schema_validation():
    valid = {
        "intent": "shopping",
        "reply": "Here are a few useful options.",
        "recommendations": [
            {"sku": "HK-00001", "rank": 1, "reason": "Fits the request."}
        ],
        "confidence": 0.8,
    }
    parsed = parse_and_validate(f"```json\n{json.dumps(valid)}\n```")
    assert parsed.recommendations[0].sku == "HK-00001"
    with pytest.raises(ValidationFailed):
        parse_and_validate("not json")
    with pytest.raises(ValidationFailed):
        parse_and_validate(json.dumps({key: value for key, value in valid.items() if key != "confidence"}))
    too_many = dict(valid)
    too_many["recommendations"] = [
        {"sku": f"SKU-{index}", "rank": index, "reason": "Fits."}
        for index in range(1, 7)
    ]
    with pytest.raises(ValidationFailed):
        parse_and_validate(json.dumps(too_many))


def test_oos_removed_and_backfilled(conn, ctx):
    class Retriever:
        def get_candidates_by_sku(self, skus):
            from retailrec.retrieval import CatalogRetriever

            retriever = CatalogRetriever.__new__(CatalogRetriever)
            retriever.conn = conn
            return retriever.get_candidates_by_sku(skus)

    inventory = SqliteInventoryService(conn, latency_ms=0, low_threshold=5)
    inventory.set_stock("HK-00002", 0)
    pricing = SqlitePricingService(conn, latency_ms=0)
    output = AgentOutput(
        intent="shopping",
        reply="Here are useful options.",
        confidence=0.8,
        recommendations=[
            Recommendation(sku="HK-00001", rank=1, reason="Matches your request."),
            Recommendation(sku="HK-00002", rank=2, reason="Matches your request."),
            Recommendation(sku="SO-00001", rank=3, reason="Matches your request."),
            Recommendation(sku="FAKE-99999", rank=4, reason="Invented item."),
        ],
    )
    items, flags = enforce_live_constraints(
        output,
        {"PT-00001": 0.7},
        Retriever(),
        inventory,
        pricing,
        top_n=3,
        exclude=set(),
        rec_id="rec-test",
        tools_used=["search_catalog"],
    )
    assert [item.sku for item in items] == [
        "HK-00001",
        "SO-00001",
        "PT-00001",
    ]
    assert "removed_oos:HK-00002" in flags
    assert "hallucinated_sku:FAKE-99999" in flags
    assert "backfilled:PT-00001" in flags
    assert all(item.stock.status != "out_of_stock" for item in items)
    assert all(item.sources["rec_id"] == "rec-test" for item in items)
