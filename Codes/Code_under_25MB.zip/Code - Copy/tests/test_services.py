"""Tests for SQLite inventory and pricing simulations."""

import pytest

from retailrec.services.inventory_stub import SqliteInventoryService
from retailrec.services.pricing_stub import SqlitePricingService


def test_inventory_stock_update_visible(conn):
    inventory = SqliteInventoryService(conn, latency_ms=0, low_threshold=5)
    inventory.set_stock("HK-00001", 0)
    assert inventory.get_stock(["HK-00001"])["HK-00001"].status == "out_of_stock"
    assert inventory.get_stock(["missing"])["missing"].qty == 0
    assert inventory.reset_stock() == 4
    assert inventory.get_stock(["HK-00001"])["HK-00001"].qty == 10
    inventory.set_stock("HK-00001", 3)
    assert inventory.get_stock(["HK-00001"])["HK-00001"].status == "low_stock"


def test_flash_sale_price_and_highest_discount(conn):
    pricing = SqlitePricingService(conn, latency_ms=0)
    promo_id = pricing.start_flash_sale("Home & Kitchen", 25, 30)
    price = pricing.get_prices(["HK-00001"])["HK-00001"]
    assert price.effective_price == 75.0
    assert price.discount_pct == 25
    assert price.promo_id == promo_id
    assert pricing.clear_flash_sales() == 1
    assert pricing.get_prices(["HK-00001"])["HK-00001"].effective_price == 100.0

    conn.execute(
        """INSERT INTO promotions
           (promo_id, scope_type, scope_value, discount_pct, label, is_flash,
            starts_at, ends_at)
           VALUES ('STD-TEST', 'sku', 'HK-00001', 10, 'Standard', 0,
                   '2000-01-01T00:00:00+00:00', NULL)"""
    )
    conn.commit()
    pricing.start_flash_sale("Home & Kitchen", 25, 30)
    price = pricing.get_prices(["HK-00001"])["HK-00001"]
    assert price.discount_pct == 25
    assert price.effective_price == 75.0


def test_invalid_simulation_values_raise(conn):
    inventory = SqliteInventoryService(conn, latency_ms=0, low_threshold=5)
    pricing = SqlitePricingService(conn, latency_ms=0)
    with pytest.raises(ValueError):
        inventory.set_stock("HK-00001", -1)
    with pytest.raises(KeyError):
        inventory.set_stock("missing", 2)
    with pytest.raises(ValueError):
        pricing.start_flash_sale("Home & Kitchen", 90, 30)
    with pytest.raises(KeyError):
        pricing.start_flash_sale("Unknown", 25, 30)
