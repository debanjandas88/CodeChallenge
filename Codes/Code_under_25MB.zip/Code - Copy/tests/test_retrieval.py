"""Tests for vector query normalization and SQL keyword search."""

from retailrec.models import Candidate
from retailrec.retrieval import CatalogRetriever


class FakeLLM:
    def embed(self, texts):
        return [[0.1, 0.2] for _ in texts]


class FakeCollection:
    def __init__(self):
        self.query_args = None

    def query(self, **kwargs):
        self.query_args = kwargs
        return {
            "metadatas": [[
                {
                    "sku": "HK-00001",
                    "category": "Home & Kitchen",
                    "subcategory": "Coffee & Tea",
                    "base_price": 100.0,
                }
            ]],
            "distances": [[0.2]],
            "documents": [["Coffee Grinder. Burr grinder."]],
        }


def test_search_builds_filters_and_merges_keyword_hits(conn, monkeypatch):
    collection = FakeCollection()

    class FakeClient:
        def get_collection(self, name):
            assert name == "products"
            return collection

    monkeypatch.setattr(
        "retailrec.retrieval.chromadb.PersistentClient",
        lambda **kwargs: FakeClient(),
    )
    retriever = CatalogRetriever(FakeLLM(), conn, "unused")
    results = retriever.search(
        "coffee grinder", top_k=5, category="Home & Kitchen", max_price=120
    )

    assert collection.query_args["where"] == {
        "$and": [
            {"category": "Home & Kitchen"},
            {"base_price": {"$lte": 120}},
        ]
    }
    assert collection.query_args["include"] == [
        "metadatas",
        "distances",
        "documents",
    ]
    assert len(results) == 1
    assert results[0].name == "Coffee Grinder"
    assert results[0].score == 0.8
    assert results[0].snippet == "Coffee Grinder. Burr grinder."


def test_keyword_search_matches_any_term_and_applies_filters(conn):
    retriever = CatalogRetriever.__new__(CatalogRetriever)
    retriever.conn = conn
    results = retriever.keyword_search(
        "running tea", category=None, max_price=30, limit=10
    )
    assert [item.sku for item in results] == ["HK-00002"]
    assert results[0].score == 0.7


def test_candidate_lookup_deduplicates_and_ignores_unknown(conn):
    retriever = CatalogRetriever.__new__(CatalogRetriever)
    retriever.conn = conn
    found = retriever.get_candidates_by_sku(
        ["HK-00001", "missing", "HK-00001"]
    )
    assert list(found) == ["HK-00001"]
    assert isinstance(found["HK-00001"], Candidate)
