"""Tests for the popular-product fallback path."""

from retailrec.fallback import popular_in_stock
from retailrec.services.inventory_stub import SqliteInventoryService
from retailrec.services.pricing_stub import SqlitePricingService


def test_fallback_respects_consent_and_live_stock(conn, ctx):
    inventory = SqliteInventoryService(conn, latency_ms=0, low_threshold=5)
    pricing = SqlitePricingService(conn, latency_ms=0)
    inventory.set_stock("SO-00001", 0)

    personalized = popular_in_stock(
        ctx, conn, inventory, pricing, 3, set(), "fallback"
    )
    assert personalized == []

    anonymous = popular_in_stock(
        ctx.model_copy(update={"consent": False}),
        conn,
        inventory,
        pricing,
        2,
        {"HK-00001"},
        "baseline",
    )
    assert [item.sku for item in anonymous] == ["HK-00002", "PT-00001"]
    assert all(item.sources["origin"] == "baseline" for item in anonymous)
    assert all(item.stock.status != "out_of_stock" for item in anonymous)
