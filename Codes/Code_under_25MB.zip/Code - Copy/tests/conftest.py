"""Shared in-memory fixtures for foundation tests."""

from datetime import timedelta
import pytest

from retailrec.db import get_conn, init_schema, now_iso
from retailrec.models import SessionContext


@pytest.fixture
def conn():
    """Create an isolated initialized SQLite database with small test data."""
    connection = get_conn(":memory:")
    init_schema(connection, reset=True)
    products = [
        ("HK-00001", "Coffee Grinder", "Burr grinder", "Home & Kitchen", "Coffee & Tea", "Hearthwell", 100.0, "coffee,grinder", 4.5, 90.0, 0, None),
        ("HK-00002", "Tea Infuser", "Steel infuser", "Home & Kitchen", "Coffee & Tea", "Culina", 25.0, "tea,infuser", 4.2, 70.0, 0, None),
        ("SO-00001", "Running Shoe", "Trail shoe", "Sports & Outdoors", "Running", "Stridex", 80.0, "running,shoe", 4.6, 95.0, 0, None),
        ("PT-00001", "Dog Treats", "Training treats", "Pet Supplies", "Dog Food & Treats", "Pawberry", 10.0, "dog,treats", 4.3, 60.0, 0, None),
    ]
    connection.executemany(
        """INSERT INTO products
           (sku, name, description, category, subcategory, brand, base_price,
            tags, rating, popularity, embedded, image_url)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        products,
    )
    initial_stock = (10, 3, 12, 20)
    connection.executemany(
        """INSERT INTO inventory (sku, stock_qty, initial_qty, updated_at)
           VALUES (?, ?, ?, ?)""",
        [(row[0], qty, qty, now_iso()) for row, qty in zip(products, initial_stock)],
    )
    connection.execute(
        """INSERT INTO customers
           (customer_id, display_name, email, persona, age_band, region,
            preferred_categories, price_sensitivity, consent_personalization)
           VALUES ('C01', 'Anna Lee', 'anna.lee@example.com', 'fitness_fan',
                   '25-34', 'EU-DE', 'Sports & Outdoors, Electronics', 'medium', 1)"""
    )
    started = (now_iso())
    connection.execute(
        "INSERT INTO sessions (session_id, pseudo_id, mode, started_at) VALUES (?, ?, ?, ?)",
        ("s_test", "u_test12345678", "ai", started),
    )
    connection.commit()
    yield connection
    connection.close()


@pytest.fixture
def ctx():
    """Return a pseudonymous demo session context."""
    return SessionContext(
        session_id="s_test",
        pseudo_id="u_test12345678",
        customer_id="C01",
        persona="fitness_fan",
        preferred_categories=["Sports & Outdoors", "Electronics"],
        price_sensitivity="medium",
        consent=True,
        started_at=now_iso(),
    )
