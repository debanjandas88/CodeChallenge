"""Tests for agent iteration budgets, tool order, and validation retries."""

import json

from retailrec.agent import RecommendationAgent
from retailrec.llm import ChatResult, ToolCall
from retailrec.services.inventory_stub import SqliteInventoryService
from retailrec.services.pricing_stub import SqlitePricingService
from retailrec.tools import ToolExecutor
from tests.fakes import FakeLLM, FakeRetriever, settings_with


def _output(recommendations=None, confidence=0.8):
    return json.dumps(
        {
            "intent": "shopping",
            "reply": "Here are some options.",
            "recommendations": recommendations or [],
            "confidence": confidence,
            "follow_up_question": None,
        }
    )


def _executor(conn, ctx):
    return ToolExecutor(
        FakeRetriever(None, conn, "unused"),
        SqliteInventoryService(conn, 0, 5),
        SqlitePricingService(conn, 0),
        conn,
        ctx,
        settings_with(),
    )


def test_retry_on_invalid_json_then_success(conn, ctx):
    llm = FakeLLM(
        [
            ChatResult("not json", [], 10, 4, 2),
            ChatResult(_output(), [], 12, 8, 2),
        ]
    )
    run = RecommendationAgent(llm, settings_with()).run(
        _executor(conn, ctx), "recommend coffee"
    )
    assert run.output is not None
    assert run.validation_retries == 1
    assert run.iterations == 2
    assert run.prompt_tokens == 22


def test_tool_message_order_and_final_iteration_tool_choice(conn, ctx):
    llm = FakeLLM(
        [
            ChatResult(
                None,
                [
                    ToolCall(
                        id="call-1",
                        name="check_inventory",
                        arguments='{"skus":["HK-00001"]}',
                    )
                ],
                10,
                3,
                1,
            ),
            ChatResult(_output(), [], 12, 8, 1),
        ]
    )
    settings = settings_with(agent_max_iterations=2)
    run = RecommendationAgent(llm, settings).run(
        _executor(conn, ctx), "recommend coffee"
    )
    assert run.output is not None
    assert [call["tool_choice"] for call in llm.calls] == ["auto", "none"]
    messages = llm.calls[1]["messages"]
    assistant_index = next(
        index
        for index, item in enumerate(messages)
        if item.get("tool_calls")
    )
    assert messages[assistant_index + 1]["role"] == "tool"
    assert messages[assistant_index + 1]["tool_call_id"] == "call-1"
    assert json.loads(messages[assistant_index + 1]["content"])["items"][0][
        "status"
    ] == "in_stock"
