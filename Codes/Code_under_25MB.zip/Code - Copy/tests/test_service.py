"""Tests for end-to-end recommendation service behavior using offline fakes."""

import json

from retailrec.llm import ChatResult, LLMUnavailable, ToolCall
from retailrec.service import RecommendationService
from retailrec.services.base import ServiceUnavailable
from tests.fakes import FakeLLM, FakeRetriever, settings_with


def _final(recommendations, confidence=0.85):
    return json.dumps(
        {
            "intent": "shopping",
            "reply": "Here are some useful choices.",
            "recommendations": recommendations,
            "confidence": confidence,
            "follow_up_question": None,
        }
    )


def _recommendations(skus):
    return [
        {"sku": sku, "rank": rank, "reason": "Matches the shopping request."}
        for rank, sku in enumerate(skus, 1)
    ]


def _service(conn, monkeypatch, llm):
    monkeypatch.setattr("retailrec.service.CatalogRetriever", FakeRetriever)
    return RecommendationService(
        settings=settings_with(),
        llm=llm,
        conn=conn,
    )


def test_recommend_audits_masked_chat_and_tool_calls(conn, monkeypatch):
    llm = FakeLLM(
        [
            ChatResult(
                None,
                [
                    ToolCall(
                        id="search-1",
                        name="search_catalog",
                        arguments='{"query":"coffee grinders"}',
                    )
                ],
                20,
                5,
                1,
            ),
            ChatResult(
                _final(_recommendations(["HK-00001", "SO-00001", "PT-00001"])),
                [],
                30,
                20,
                1,
            ),
        ]
    )
    service = _service(conn, monkeypatch, llm)
    ctx = service.start_session("C01")
    result = service.recommend(
        ctx,
        "chat",
        message="Anna Lee needs coffee; email anna.lee@example.com",
        history=[
            {
                "role": "user",
                "content": "Anna Lee wrote anna.lee@example.com",
            }
        ],
    )

    assert len(result.items) == 3
    assert all(item.stock.status != "out_of_stock" for item in result.items)
    assert conn.execute(
        "SELECT COUNT(*) FROM audit_log WHERE rec_id = ?", (result.rec_id,)
    ).fetchone()[0] == 1
    audit = conn.execute(
        "SELECT * FROM audit_log WHERE rec_id = ?", (result.rec_id,)
    ).fetchone()
    assert "[NAME]" in audit["user_message_masked"]
    assert "[EMAIL]" in audit["user_message_masked"]
    assert "anna.lee@example.com" not in audit["user_message_masked"]
    calls = json.loads(audit["tool_calls"])
    assert [call["name"] for call in calls] == ["search_catalog"]
    assert json.loads(audit["final_recs"]) == [
        "HK-00001",
        "SO-00001",
        "PT-00001",
    ]
    sent_history = llm.calls[0]["messages"]
    assert all(
        "anna.lee@example.com" not in message["content"]
        for message in sent_history
        if isinstance(message.get("content"), str)
    )


def test_low_confidence_uses_audited_popular_fallback(conn, monkeypatch):
    llm = FakeLLM(
        [
            ChatResult(
                _final(_recommendations(["HK-00001"]), confidence=0.3),
                [],
                10,
                6,
                1,
            )
        ]
    )
    service = _service(conn, monkeypatch, llm)
    ctx = service.start_session("C01")
    result = service.recommend(ctx, "home")
    assert result.fallback_used is True
    assert result.fallback_reason == "low_confidence"
    assert result.confidence is None
    assert result.items
    assert all(item.sources["origin"] == "fallback" for item in result.items)
    assert conn.execute(
        "SELECT fallback_used FROM audit_log WHERE rec_id = ?",
        (result.rec_id,),
    ).fetchone()[0] == 1


def test_azure_failure_returns_audited_fallback(conn, monkeypatch):
    llm = FakeLLM([LLMUnavailable("redacted")])
    service = _service(conn, monkeypatch, llm)
    ctx = service.start_session("C01")
    result = service.recommend(ctx, "home")
    assert result.fallback_used is True
    assert result.fallback_reason == "LLMUnavailable"
    assert result.items
    audit = conn.execute(
        "SELECT error, fallback_reason FROM audit_log WHERE rec_id = ?",
        (result.rec_id,),
    ).fetchone()
    assert audit["error"] == "LLMUnavailable"
    assert audit["fallback_reason"] == "LLMUnavailable"


def test_unavailable_live_services_fail_closed_and_are_audited(
    conn, monkeypatch
):
    llm = FakeLLM(
        [
            ChatResult(
                _final(_recommendations(["HK-00001", "SO-00001", "PT-00001"])),
                [],
                10,
                6,
                1,
            )
        ]
    )
    service = _service(conn, monkeypatch, llm)
    ctx = service.start_session("C01")

    class UnavailableInventory:
        def get_stock(self, skus):
            raise ServiceUnavailable("stock check unavailable")

    service.inventory = UnavailableInventory()
    result = service.recommend(ctx, "home")
    assert result.items == []
    assert result.fallback_used is True
    assert result.fallback_reason == "inventory_unavailable"
    assert "inventory_unavailable" in result.flags
    audit = conn.execute(
        "SELECT error, fallback_reason FROM audit_log WHERE rec_id = ?",
        (result.rec_id,),
    ).fetchone()
    assert audit["error"] == "ServiceUnavailable"
    assert audit["fallback_reason"] == "inventory_unavailable"


def test_baseline_browse_events_metrics_and_refresh(conn, monkeypatch):
    service = _service(conn, monkeypatch, FakeLLM([]))
    ctx = service.start_session("C01", mode="baseline").model_copy(
        update={"preferred_categories": []}
    )
    result = service.recommend(ctx, "home")
    assert result.items
    assert all(item.sources["origin"] == "baseline" for item in result.items)
    result = result.model_copy(update={"items": result.items[:3]})
    category_items = service.browse("Sports & Outdoors", limit=3)
    assert category_items
    assert all(
        item["category"] == "Sports & Outdoors"
        and item["stock"].status != "out_of_stock"
        for item in category_items
    )
    sku = result.items[0].sku
    service.record_click(ctx, result.rec_id, sku)
    service.add_to_cart(ctx, result.rec_id, sku)
    service.feedback(ctx, result.rec_id, sku, 1)
    metrics = service.metrics(ctx)
    assert metrics["by_mode"]["baseline"]["clicks"] == 1
    assert metrics["by_mode"]["baseline"]["carts"] == 1
    service.inventory.set_stock(sku, 0)
    refreshed = service.refresh(ctx, result)
    assert refreshed.trigger == "refresh"
    assert refreshed.fallback_used is True
    assert len(refreshed.items) == len(result.items)
    assert any(item.sku == "PT-00001" for item in refreshed.items)
    assert all(item.stock.status != "out_of_stock" for item in refreshed.items)
    assert conn.execute(
        "SELECT 1 FROM audit_log WHERE rec_id = ?", (refreshed.rec_id,)
    ).fetchone() is not None


def test_refresh_revalidates_stock_and_applies_flash_sale(conn, monkeypatch):
    service = _service(conn, monkeypatch, FakeLLM([]))
    ctx = service.start_session("C01", mode="baseline").model_copy(
        update={"preferred_categories": []}
    )
    result = service.recommend(ctx, "home")
    out_of_stock_sku = result.items[0].sku
    service.inventory.set_stock(out_of_stock_sku, 0)

    refreshed = service.refresh(ctx, result)
    assert out_of_stock_sku not in {item.sku for item in refreshed.items}
    assert all(item.stock.status != "out_of_stock" for item in refreshed.items)
    assert conn.execute(
        "SELECT 1 FROM audit_log WHERE rec_id = ?", (refreshed.rec_id,)
    ).fetchone() is not None

    sale_category = refreshed.items[0].category
    service.pricing.start_flash_sale(sale_category, 25, 30)
    promoted = service.refresh(ctx, refreshed)
    assert any(
        item.category == sale_category
        and item.price.discount_pct >= 25
        and item.highlight_promo
        for item in promoted.items
    )
    assert all(item.stock.status != "out_of_stock" for item in promoted.items)
    assert conn.execute(
        "SELECT 1 FROM audit_log WHERE rec_id = ?", (promoted.rec_id,)
    ).fetchone() is not None
