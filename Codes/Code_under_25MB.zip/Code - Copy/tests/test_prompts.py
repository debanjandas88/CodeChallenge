"""Tests for context-aware recommendation prompt builders."""

import json

import pytest

from retailrec.models import Candidate
from retailrec.prompts import (
    SYSTEM_PROMPT,
    build_seed_query,
    build_user_message,
)


def test_seed_queries_follow_trigger_and_consent(ctx):
    assert build_seed_query(
        ctx, "home", None, None, ["Old", "Recent one", "Recent two", "Recent three"]
    ) == "Sports & Outdoors, Electronics Recent one Recent two Recent three"
    assert build_seed_query(
        ctx.model_copy(update={"consent": False}),
        "home",
        None,
        None,
        ["Personal history"],
    ) == "popular products"
    assert build_seed_query(
        ctx, "view", None, {"name": "Running Shoe", "subcategory": "Running"}, []
    ) == "Running Shoe Running"
    assert build_seed_query(ctx, "chat", "masked request", None, []) == "masked request"


def test_user_message_includes_compact_seed_and_masks_only_given_text():
    candidate = Candidate(
        sku="SO-00001",
        name="Running Shoe",
        category="Sports & Outdoors",
        subcategory="Running",
        base_price=80,
        score=0.9,
        snippet="Not included",
    )
    message = build_user_message("chat", "[EMAIL] needs shoes", None, [candidate])
    assert 'Shopper says: "[EMAIL] needs shoes"' in message
    seed = json.loads(message.split("\n", 2)[2].split("\n", 1)[1])
    assert seed == [
        {
            "sku": "SO-00001",
            "name": "Running Shoe",
            "category": "Sports & Outdoors",
            "price": 80.0,
        }
    ]
    assert "Not included" not in message
    assert "Never recommend the viewed product." in SYSTEM_PROMPT


def test_view_prompts_require_viewed_product(ctx):
    with pytest.raises(ValueError):
        build_user_message("view", None, None, [])
    with pytest.raises(ValueError):
        build_seed_query(ctx, "view", None, None, [])
