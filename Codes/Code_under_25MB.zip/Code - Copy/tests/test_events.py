"""Tests for event, feedback, and metric persistence."""

import pytest

from retailrec.audit import AuditLogger, AuditRecord
from retailrec.events import (
    compute_metrics,
    get_recent_events,
    record_event,
    record_feedback,
)


def test_feedback_upsert_and_metrics(conn, ctx):
    audit = AuditLogger(conn)
    rec_id = audit.new_rec_id()
    for _ in range(4):
        record_event(conn, ctx, "rec_impression", "HK-00001", rec_id)
    record_event(conn, ctx, "rec_click", "HK-00001", rec_id)
    record_event(conn, ctx, "add_to_cart", "HK-00001", rec_id)
    record_feedback(conn, ctx, rec_id, "HK-00001", 1)
    record_feedback(conn, ctx, rec_id, "HK-00001", -1)

    row = conn.execute("SELECT COUNT(*) AS n, MAX(value) AS value FROM feedback").fetchone()
    assert row["n"] == 1
    assert row["value"] == -1
    metrics = compute_metrics(conn, ctx.session_id)["by_mode"]["ai"]
    assert metrics["ctr"] == 0.25
    assert metrics["cart_rate"] == 0.25
    assert metrics["satisfaction"] == 0.0
    assert metrics["thumbs_down"] == 1


def test_audit_record_round_trip(conn, ctx):
    audit = AuditLogger(conn)
    rec_id = audit.new_rec_id()
    audit.write(
        AuditRecord(
            rec_id=rec_id,
            session_id=ctx.session_id,
            pseudo_id=ctx.pseudo_id,
            ts=ctx.started_at,
            trigger="home",
            mode="ai",
            seed_candidates=["HK-00001"],
            tool_calls=[{"name": "search_catalog"}],
            final_recs=["HK-00001"],
            fallback_used=True,
            guardrail_flags=["no_consent"],
        )
    )
    recent = audit.recent(5)
    assert recent[0]["rec_id"] == rec_id
    assert recent[0]["fallback_used"] == 1


def test_recent_events_and_invalid_type(conn, ctx):
    record_event(conn, ctx, "view", "HK-00001")
    recent = get_recent_events(conn, ctx.pseudo_id, limit=1)
    assert recent[0]["name"] == "Coffee Grinder"
    assert recent[0]["category"] == "Home & Kitchen"
    with pytest.raises(ValueError):
        record_event(conn, ctx, "unsupported")
