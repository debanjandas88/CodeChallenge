"""Reusable offline test doubles for Azure chat and catalog retrieval."""

from copy import deepcopy
from dataclasses import replace

from retailrec.config import Settings
from retailrec.models import Candidate


TEST_SETTINGS = Settings(
    azure_endpoint="https://example.invalid",
    azure_api_key="not-used",
    azure_api_version="2024-10-21",
    chat_deployment="test-chat",
    embed_deployment="test-embedding",
    db_path=":memory:",
    chroma_path="unused",
    pseudo_salt="test-salt",
    stub_latency_ms=0,
)


def settings_with(**updates) -> Settings:
    """Return isolated deterministic test settings."""
    return replace(TEST_SETTINGS, **updates)


class FakeLLM:
    """Return scripted chat results and deterministic fake embeddings."""

    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def chat(
        self,
        messages,
        tools=None,
        tool_choice="auto",
        temperature=0.2,
        max_tokens=800,
    ):
        self.calls.append(
            {
                "messages": deepcopy(messages),
                "tools": tools,
                "tool_choice": tool_choice,
                "temperature": temperature,
                "max_tokens": max_tokens,
            }
        )
        if not self.responses:
            raise AssertionError("FakeLLM has no scripted response")
        response = self.responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response

    def embed(self, texts):
        return [[0.1, 0.2, 0.3] for _ in texts]


class FakeRetriever:
    """Use the SQLite fixture as an offline semantic-candidate source."""

    def __init__(self, llm, conn, chroma_path):
        self.conn = conn

    def search(self, query, top_k=10, category=None, max_price=None):
        rows = self.conn.execute(
            """SELECT sku, name, category, subcategory, base_price,
                      description, popularity
               FROM products
               WHERE (? IS NULL OR category = ?)
                 AND (? IS NULL OR base_price <= ?)
               ORDER BY popularity DESC, sku LIMIT ?""",
            (category, category, max_price, max_price, top_k),
        ).fetchall()
        return [self._candidate(row) for row in rows]

    def get_candidates_by_sku(self, skus):
        requested = list(dict.fromkeys(skus))
        if not requested:
            return {}
        placeholders = ",".join("?" for _ in requested)
        rows = self.conn.execute(
            f"""SELECT sku, name, category, subcategory, base_price,
                       description, popularity
                FROM products WHERE sku IN ({placeholders})""",
            requested,
        ).fetchall()
        return {row["sku"]: self._candidate(row) for row in rows}

    @staticmethod
    def _candidate(row):
        return Candidate(
            sku=row["sku"],
            name=row["name"],
            category=row["category"],
            subcategory=row["subcategory"],
            base_price=float(row["base_price"]),
            score=float(row["popularity"]) / 100,
            snippet=row["description"],
        )
