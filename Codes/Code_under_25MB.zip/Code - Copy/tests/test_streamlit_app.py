"""Tests for demo onboarding input validation and account creation."""

from types import SimpleNamespace
from pathlib import Path

from app import streamlit_app
from retailrec.llm import ChatResult
from retailrec.service import RecommendationService
from tests.fakes import FakeLLM, FakeRetriever, settings_with
from streamlit.testing.v1 import AppTest


def test_demo_account_validation_and_creation(conn, monkeypatch):
    monkeypatch.setattr(streamlit_app, "_run_home", lambda *args: None)
    service = SimpleNamespace(conn=conn)

    assert streamlit_app._create_account(service, "", "new@example.com")
    assert streamlit_app._create_account(service, "Demo Shopper", "invalid")
    duplicate = streamlit_app._create_account(
        service, "Demo Shopper", "ANNA.LEE@example.com"
    )
    assert "already in use" in duplicate

    assert streamlit_app._create_account(
        service, "Demo Shopper", "new.shopper@example.com"
    ) is None
    customer = conn.execute(
        """SELECT display_name, email, persona, age_band, region,
                  preferred_categories, price_sensitivity,
                  consent_personalization
           FROM customers WHERE email = ?""",
        ("new.shopper@example.com",),
    ).fetchone()
    assert tuple(customer) == (
        "Demo Shopper",
        "new.shopper@example.com",
        "new_shopper",
        "unknown",
        "Unknown",
        "",
        "medium",
        1,
    )


def test_create_account_enters_storefront(conn, monkeypatch):
    monkeypatch.setattr("retailrec.service.CatalogRetriever", FakeRetriever)
    llm = FakeLLM(
        [
            ChatResult(
                '{"intent":"shopping","reply":"Here are useful picks.",'
                '"recommendations":['
                '{"sku":"HK-00001","rank":1,"reason":"A useful choice."},'
                '{"sku":"SO-00001","rank":2,"reason":"Another useful choice."},'
                '{"sku":"PT-00001","rank":3,"reason":"A third useful choice."}],'
                '"confidence":0.8,"follow_up_question":null}',
                [],
                10,
                8,
                1,
            )
        ]
    )
    service = RecommendationService(settings=settings_with(), llm=llm, conn=conn)
    app_path = Path(__file__).parent.parent / "app" / "streamlit_app.py"
    at = AppTest.from_file(app_path)
    at.session_state["svc"] = service
    at.run()
    at.text_input[0].set_value("Demo Shopper")
    at.text_input[1].set_value("demo.shopper@example.com")
    next(button for button in at.button if button.label == "Create account").click().run()

    assert not at.exception
    assert at.session_state["ctx"].customer_id.startswith("D")
    assert at.session_state["result"].items
    assert any(item.value == "Recommended for you" for item in at.subheader)
    assert any(
        "aria-label='Home & Kitchen'" in item.value for item in at.markdown
    )


def test_existing_customer_can_browse_view_and_see_image_placeholder(
    conn, monkeypatch
):
    monkeypatch.setattr("retailrec.service.CatalogRetriever", FakeRetriever)
    content = (
        '{"intent":"shopping","reply":"Here are useful picks.",'
        '"recommendations":['
        '{"sku":"HK-00001","rank":1,"reason":"A useful choice."},'
        '{"sku":"SO-00001","rank":2,"reason":"Another useful choice."},'
        '{"sku":"PT-00001","rank":3,"reason":"A third useful choice."}],'
        '"confidence":0.8,"follow_up_question":null}'
    )
    llm = FakeLLM(
        [ChatResult(content, [], 10, 8, 1), ChatResult(content, [], 10, 8, 1)]
    )
    service = RecommendationService(settings=settings_with(), llm=llm, conn=conn)
    app_path = Path(__file__).parent.parent / "app" / "streamlit_app.py"
    at = AppTest.from_file(app_path)
    at.session_state["svc"] = service
    at.run()

    next(
        button for button in at.button if button.label == "Continue to storefront"
    ).click().run()
    assert at.session_state["ctx"].customer_id == "C01"

    next(selectbox for selectbox in at.selectbox if selectbox.label == "Category").set_value(
        "Home & Kitchen"
    ).run()
    assert any("Coffee Grinder" in item.value for item in at.markdown)
    assert any(
        "aria-label='Home & Kitchen'" in item.value for item in at.markdown
    )

    next(
        button for button in at.button if button.key == "browse_view_HK-00001"
    ).click().run()
    assert not at.exception
    assert at.session_state["viewed_sku"] == "HK-00001"
    assert all(
        item.sku != at.session_state["viewed_sku"]
        for item in at.session_state["result"].items
    )
    assert any(item.value == "Product details" for item in at.subheader)
    assert any(
        "aria-label='Home & Kitchen'" in item.value for item in at.markdown
    )
