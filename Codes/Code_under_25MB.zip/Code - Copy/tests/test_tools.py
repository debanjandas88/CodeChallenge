"""Tests for the recommendation function schemas and executor."""

import json

from retailrec.config import Settings
from retailrec.models import Candidate, SessionContext
from retailrec.services.inventory_stub import SqliteInventoryService
from retailrec.services.pricing_stub import SqlitePricingService
from retailrec.tools import TOOL_SPECS, ToolExecutor


TEST_SETTINGS = Settings(
    azure_endpoint="https://example.invalid",
    azure_api_key="not-used",
    azure_api_version="2024-10-21",
    chat_deployment="test",
    embed_deployment="test",
    db_path=":memory:",
    chroma_path="unused",
    pseudo_salt="test",
)


class FakeRetriever:
    def __init__(self):
        self.queries = []

    def search(self, query, top_k, category, max_price):
        self.queries.append((query, top_k, category, max_price))
        return [
            Candidate(
                sku="HK-00001",
                name="Coffee Grinder",
                category="Home & Kitchen",
                subcategory="Coffee & Tea",
                base_price=100,
                score=0.8,
                snippet="Burr grinder",
            )
        ]


def test_tool_schemas_and_compact_search_result(conn, ctx):
    retriever = FakeRetriever()
    executor = ToolExecutor(
        retriever,
        SqliteInventoryService(conn, latency_ms=0, low_threshold=5),
        SqlitePricingService(conn, latency_ms=0),
        conn,
        ctx,
        settings=TEST_SETTINGS,
    )
    assert [item["function"]["name"] for item in TOOL_SPECS] == [
        "search_catalog",
        "check_inventory",
        "get_pricing_and_promotions",
        "get_user_profile",
    ]

    result = executor.execute(
        "search_catalog",
        json.dumps(
            {
                "query": "Anna Lee wants coffee",
                "category": "Home & Kitchen",
                "max_price": 120,
                "top_k": 5,
            }
        ),
    )
    assert result["results"][0]["sku"] == "HK-00001"
    assert "snippet" not in result["results"][0]
    assert executor.pool == {"HK-00001": 0.8}
    assert executor.calls[0]["args"]["query"] == "[NAME] wants coffee"
    assert retriever.queries[0][1:] == (5, "Home & Kitchen", 120)


def test_profile_consent_and_live_tools(conn, ctx):
    executor = ToolExecutor(
        FakeRetriever(),
        SqliteInventoryService(conn, latency_ms=0, low_threshold=5),
        SqlitePricingService(conn, latency_ms=0),
        conn,
        ctx,
        settings=TEST_SETTINGS,
    )
    profile = executor.execute("get_user_profile", "{}")
    assert profile["consent"] is True
    assert profile["persona"] == "fitness_fan"
    assert "customer_id" not in profile and "email" not in profile

    no_consent = ctx.model_copy(update={"consent": False})
    executor.ctx = no_consent
    assert executor.execute("get_user_profile", "{}") == {"consent": False}
    assert "no_consent" in executor.flags
    assert executor.execute(
        "check_inventory", '{"skus":["HK-00001"]}'
    )["items"][0]["status"] == "in_stock"
    assert executor.execute(
        "get_pricing_and_promotions", '{"skus":["HK-00001"]}'
    )["items"][0]["effective_price"] == 100


def test_invalid_and_unknown_tool_calls_are_explicit(conn, ctx):
    executor = ToolExecutor(
        FakeRetriever(),
        SqliteInventoryService(conn, latency_ms=0, low_threshold=5),
        SqlitePricingService(conn, latency_ms=0),
        conn,
        ctx,
        settings=TEST_SETTINGS,
    )
    assert executor.execute("check_inventory", "not-json") == {
        "error": "invalid_arguments"
    }
    assert executor.execute("unknown", "{}") == {"error": "unknown_tool"}
    assert executor.execute(
        "check_inventory",
        json.dumps({"skus": ["HK-00001"] * 16}),
    ) == {"error": "invalid_arguments"}
    assert len(executor.calls) == 3
