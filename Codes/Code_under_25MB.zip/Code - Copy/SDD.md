# Solution Design Document: AI-Enhanced Personalized Retail Product Recommendation Generator

## 1. Document Control

| Field | Value |
|---|---|
| Title | AI-Enhanced Personalized Retail Product Recommendation Generator (POC) |
| Event | AI Friday Season 3 |
| Version | 1.1 (adds optional FastAPI mock API in section 7.4b, and Copilot setup in sections 11.5-11.6) |
| Date | 2026-11-06 |
| Author | Principal Solution Architect (AI-assisted); builder: solo developer with GitHub Copilot |
| Status | Approved for build (all interview decisions confirmed) |
| Build budget | 4 hours planned (+1 hour buffer), solo, GitHub Copilot |
| LLM access | Azure OpenAI only (chat deployment with function calling + embedding deployment) |

---

## 2. Executive Summary

**Problem.** A mid-size online retailer (50,000 SKUs, millions of monthly visits) uses traditional recommenders that are not contextual, ignore live inventory and promotions, and are static. This causes low conversion, frustrated customers and lost sales.

**Solution in 5 lines.**
1. A Streamlit mock storefront with an embedded AI shopping-assistant widget (recommendation cards plus a chat box).
2. A hybrid pipeline: Chroma vector retrieval over ~2,000 embedded SKUs seeds candidates, then a single Azure OpenAI tool-calling agent (4 tools) re-ranks and explains them in conversation.
3. Every recommendation is re-validated against live inventory and pricing/promotion services (stubbed behind swappable interfaces) before display, so out-of-stock items are never shown and promotions are highlighted.
4. GDPR-minded by design: synthetic customers, pseudonymous session IDs, PII masking before any LLM call, consent flag, and an audit log row for every recommendation.
5. Feedback (thumbs up/down), click-through, add-to-cart and session-duration counters are tracked, with an AI vs Baseline toggle and an automated evaluation script.

**Expected demo outcome.** In a live browsing session, the presenter selects a shopper, sees personalized recommendations update as products are viewed, chats ("gift for my dad who loves coffee, under $60"), flips a product out of stock and starts a flash sale from the sidebar (cards update instantly), gives feedback, toggles AI vs Baseline to show metrics, opens the audit log, and runs the evaluation script showing a pass rate of at least 80%.

---

## 3. Scope

### 3.1 In scope
- Synthetic catalog of 50,000 SKUs in SQLite (10 categories x 5 subcategories), 12 synthetic customers with browsing/purchase history.
- Embedding and Chroma indexing of 2,000 curated SKUs (40 per subcategory).
- Streamlit storefront: lightweight demo account creation, customer picker, category browsing, product views with product images, recommendation cards, chat widget, simulation sidebar, metrics panel, audit viewer.
- Hybrid agent (retrieval + tool calling) using the Azure OpenAI SDK directly (no orchestration framework).
- Stubbed Inventory, Pricing and Promotion services with realistic, live-changing data behind Python Protocol interfaces.
- Optional (Block 8): FastAPI mock inventory/pricing API and HTTP clients selected by `API_BACKEND=http` (section 7.4b).
- Guardrails: JSON schema validation with retries, live inventory/price re-check, citations/audit reference, PII masking, confidence fallback to popular in-stock items.
- Feedback capture, event tracking, metrics (CTR, add-to-cart rate, session duration, thumbs-up satisfaction) with AI vs Baseline toggle.
- Audit log table (one row per recommendation generation or refresh).
- Unit tests, smoke test, labelled evaluation set (15 cases) with pass/fail script, demo script.

### 3.2 Out of scope
- Real retailer systems, real customer data, real checkout/payment, production authentication, password-based identity management, and SSO. A lightweight demo account creation flow is in scope (see FR-17); it is not production authentication.
- Embedding all 50k SKUs, fine-tuning, multi-agent orchestration, LangChain/LangGraph.
- Real browser-embedded JavaScript widget (the widget is simulated inside Streamlit).
- Statistically valid A/B testing (the metrics panel is illustrative for the demo).
- Docker, cloud deployment, CI/CD, monitoring stack.

### 3.3 Assumptions (confirmed by the user)
- The Azure OpenAI resource has one **chat deployment supporting function calling** (e.g. GPT-4o, GPT-4.1 or a mini variant) and one **embedding deployment** (e.g. text-embedding-3-small). Deployment names, endpoint and API version are supplied by the builder in `.env`.
- Azure OpenAI authentication is by API key stored in `.env`. Demo shoppers can create a lightweight local account using a display name and email; no password or production identity provider is required.
- All data is synthetic; the demo runs locally on one machine for one presenter.
- Currency is displayed as `$` (configurable).
- Hosting is a local Python 3.11+ virtual environment; no Docker.

### 3.4 Constraints
- Total build time 4-5 hours, solo, with GitHub Copilot.
- LLM provider is Azure OpenAI only. No other LLM or external AI API.
- Must satisfy the problem statement constraints: GDPR compliance posture, inventory/pricing API integration (stubbed), real-time updates, responsive performance, and audit logs for recommendation generation.

---

## 4. Decision Log

| # | Decision area | Chosen option | Source |
|---|---|---|---|
| 1 | Problem and scope | Personalized, conversational recommendation widget with real-time inventory and promotions, feedback capture and audit log | Derived from use case |
| 2 | Data source | Synthetic: 50,000 SKUs generated by script, plus synthetic customer profiles and sessions | Derived from use case |
| 3 | Catalog and retrieval | 50k SKUs in SQLite, ~2,000 curated SKUs embedded | User (Q1) |
| 4 | AI pattern | Hybrid: vector retrieval for candidates, then single tool-using agent | User (Q2) |
| 5 | Azure OpenAI | Chat deployment (function calling) + embedding deployment, API key in `.env` | User (Q3, Q9) |
| 6 | Orchestration | None: plain `openai` SDK (AzureOpenAI client) with hand-written tool loop | Architect, high confidence |
| 7 | Vector store | Chroma, local persistent, metadata filters | User (Q5) |
| 8 | Guardrails | JSON schema validation + retries; inventory/price re-check; citations and audit reference; PII masking; confidence score + fallback to popular items | User (Q6) |
| 9 | Quality evaluation | Small labelled test set + pass/fail script | User (Q7) |
| 10 | Real-time demo mechanism | Sidebar "Simulate" buttons (flip stock, flash sale) | User (Q8) |
| 11 | Language, UI, backend | Python 3.11+, Streamlit mock storefront with chat widget, no separate API server | Architect, high confidence |
| 12 | External systems | Inventory, pricing and promotions stubbed behind swappable interfaces | Architect, high confidence |
| 13 | Storage | SQLite (catalog, inventory, promotions, sessions, events, feedback, audit log) | Architect, high confidence |
| 14 | Config, run target, security | `.env` + python-dotenv, local venv; lightweight demo accounts only, no production auth | Architect, high confidence |
| 15 | Observability and testing | Audit table + console logs; smoke script, unit tests, eval set, demo script | Architect, high confidence |
| 16 | Team and SDD template | Solo + GitHub Copilot, default SDD structure | User / Architect |
| 17 | API integration mode | Default: SQLite-backed stubs (`API_BACKEND=stub`); optional FastAPI mock API (`API_BACKEND=http`) built only if time allows | User (accepted recommendation) |

---

## 5. Requirements

### 5.1 Functional requirements

| ID | Requirement | Acceptance criteria |
|---|---|---|
| FR-1 | Generate synthetic data deterministically (seed 42): 50,000 SKUs, inventory, standing promotions, 12 customers, ~25 historical events per customer | After `python scripts/generate_data.py`: `products`=50,000, `customers`=12, `inventory`=50,000, `events`>=300; rerun with the same seed yields identical SKU list |
| FR-2 | Embed 2,000 curated SKUs (40 per subcategory) into a persistent Chroma collection `products` | After `python scripts/build_index.py`: Chroma count = 2,000; `products.embedded=1` for exactly 2,000 rows; a query "running shoes" returns >=5 results with category "Sports & Outdoors" in the top 10 |
| FR-3 | Mock storefront: choose a customer, browse a category grid, view a product (logs a `view` event) | Selecting a customer starts a session; clicking "View" on a product writes an `events` row with `event_type='view'` |
| FR-4 | Proactive personalized recommendations on triggers `home` (customer selected) and `view` (product viewed) | 3-5 cards are shown within 10 s; each has a reason of <=25 words grounded in profile/viewed item; the viewed SKU is never recommended |
| FR-5 | Conversational recommendations via chat widget with short history (last 6 turns) | A chat message returns a reply plus 0-5 cards; follow-up messages use earlier turns |
| FR-6 | Real-time inventory validation: no out-of-stock SKU is ever displayed; low stock (<=5) is badged | Setting stock to 0 for a displayed SKU and refreshing removes it and backfills a replacement; a low-stock SKU shows "Only N left" |
| FR-7 | Real-time price and promotion highlighting: display effective price, strike-through base price and promo label from the pricing service (never from LLM text) | Starting a flash sale on a category shows discounted price and badge on affected cards after refresh |
| FR-8 | Simulation controls in the sidebar: mark a displayed SKU out of stock, start a flash sale (category, %, minutes), reset stock/promos | Each action takes effect on the next refresh without app restart and without an LLM call (refresh path) |
| FR-9 | Feedback capture: thumbs up/down per card, stored with `rec_id` and SKU | Clicking a thumb writes one `feedback` row (value +1 or -1); repeated clicks on the same card update rather than duplicate |
| FR-10 | Audit log: one `audit_log` row for every recommendation generation and refresh containing trigger, masked user message, seed candidates, tool calls, final recs, model deployment, token counts, latency, confidence, fallback flag, guardrail flags | After any recommendation, `audit_log` has a row with a unique `rec_id`; sidebar audit viewer shows the last 5 rows |
| FR-11 | Privacy: pseudonymous session ID; PII (email, phone, card number, known customer name) masked before any LLM call and before storage; customer without consent (C12) gets no profile/history | A chat message containing an email/phone appears masked in the audit row and in LLM requests; the LLM never receives `display_name` or `email`; C12 results carry guardrail flag `no_consent` |
| FR-12 | Structured output: agent final answer must validate against the `AgentOutput` schema; up to 2 correction retries | Invalid JSON triggers a retry with the validation error; after 2 failed retries fallback is used (FR-13) |
| FR-13 | Fallback: if confidence < 0.5, validation fails, Azure errors, or the agent hits iteration limits, show popular in-stock items for the customer's preferred categories and flag `fallback_used` | Unit tests simulate each failure; UI shows a "Showing popular picks" caption; audit row has `fallback_used=1` and `fallback_reason` |
| FR-14 | Metrics panel: CTR, add-to-cart rate, thumbs-up satisfaction, session duration; AI vs Baseline mode toggle (Baseline = popularity ranking with the same live validation) | Metrics update after clicks/feedback; toggling mode changes the generator and the per-mode breakdown rows |
| FR-15 | Evaluation script runs the 15-case labelled set and prints pass/fail per case and overall | `python scripts/run_eval.py` exits 0 when pass rate >= 80%, else 1; writes `data/eval_report.json` |
| FR-16 (optional) | Mock HTTP API: with `API_BACKEND=http` and the mock API running, the app gets stock, prices and promotions over HTTP and simulate actions call the admin endpoints; if the API is unreachable the system fails closed | `curl /inventory` reflects a stock change made from the sidebar and cards update as in stub mode; with the API stopped no unverified item is shown, the UI shows the unavailable message and an audit row is written |
| FR-17 | Lightweight demo account creation: a new shopper can enter a display name and email, create a local demo account, and immediately start browsing products; existing seeded/demo accounts remain available | A valid, unused email creates one customer row; duplicate/invalid email shows a clear validation message; account creation starts a pseudonymous session and opens the storefront. No password, SSO, or production authentication is implemented |
| FR-18 | Product imagery: show an image for products in browse, recommendation and product-view surfaces when an image URL is available | Product cards/details display the product image; missing or failed images show a consistent category-based placeholder without breaking browsing or recommendations |

### 5.2 Non-functional requirements

| ID | Requirement | Measure |
|---|---|---|
| NFR-1 | Responsiveness | Recommendation generation <= 10 s typical (<= 15 s hard limit in eval); refresh path (no LLM) <= 500 ms; UI never blocks without a spinner |
| NFR-2 | Privacy/GDPR posture | No direct identifiers in LLM payloads, audit rows or events; consent flag honored; pseudonymization via salted SHA-256 |
| NFR-3 | Auditability | 100% of recommendation outputs have an `audit_log` row |
| NFR-4 | Reliability | Any Azure error leads to fallback recommendations, never a crashed page |
| NFR-5 | Swappability | Inventory and pricing accessed only via `InventoryService` and `PricingService` Protocols; stubs can be replaced without touching agent code |
| NFR-6 | Reproducibility | Data generation is seeded; setup is 4 commands; all config via env vars |
| NFR-7 | Cost control | Embeddings built once and cached on disk; agent limited to 5 loop iterations and 8 tool calls per run; `max_tokens` 800 |
| NFR-8 | Maintainability | Python type hints, pydantic models at all boundaries, module responsibilities as in section 8.1 |

### 5.3 Traceability matrix (FR to module, test, demo step)

| FR | Primary modules/files | Tests | Demo step (section 13.3) |
|---|---|---|---|
| FR-1 | `scripts/generate_data.py`, `db.py` | S-02 | D0 |
| FR-2 | `scripts/build_index.py`, `retrieval.py` | S-02 | D0 |
| FR-3 | `app/streamlit_app.py`, `events.py` | T-11, manual | D1, D2 |
| FR-4 | `service.py`, `agent.py`, `prompts.py` | S-03, E-01..E-04, E-15 | D1, D2 |
| FR-5 | `agent.py`, `tools.py`, `app/streamlit_app.py` | E-05..E-09 | D3 |
| FR-6 | `guardrails.py`, `services/inventory_stub.py` | T-03, T-06, E-10 | D5 |
| FR-7 | `services/pricing_stub.py`, `guardrails.py` | T-04, E-11 | D6 |
| FR-8 | `services/*_stub.py`, `service.py` (`refresh`), app sidebar | T-03, T-04, E-10, E-11 | D5, D6 |
| FR-9 | `events.py`, app | T-11 | D7 |
| FR-10 | `audit.py`, `service.py` | T-10, all E cases (audit check) | D9 |
| FR-11 | `privacy.py`, `tools.py` | T-01, T-02, E-12, E-14 | D4 |
| FR-12 | `guardrails.py`, `agent.py` | T-05, T-07 | D9 (retries visible in audit) |
| FR-13 | `fallback.py`, `service.py` | T-08, T-09, E-13 | D11 |
| FR-14 | `events.py` (metrics), app | T-11 | D8 |
| FR-15 | `scripts/run_eval.py`, `data/eval_set.json` | E (all) | D10 |
| FR-16 (optional) | `mock_api/main.py`, `services/http_clients.py`, `service.py` (`build_services`) | T-12, T-13 | D12 |
| FR-17 | `app/streamlit_app.py`, `db.py`, `service.py` | signup validation + session smoke test | D0a |
| FR-18 | `scripts/generate_data.py`, `db.py`, `app/streamlit_app.py` | image fallback + card rendering smoke test | D1-D3 |

---

## 6. Flow Diagrams

### 6.1 End-to-end business/user flow

```mermaid
flowchart TD
    A["Shopper opens mock storefront"] --> B{"Create demo account or continue with existing customer?"}
    B -->|"Create account: name + email"| C["Create local customer profile"]
    B -->|"Existing demo customer"| C
    C --> D["Start session with pseudonymous ID"]
    C --> D["Request home recommendations"]
    D --> E["Recommendation Service"]
    E --> F{"Mode"}
    F -->|"AI"| G["Hybrid agent pipeline"]
    F -->|"Baseline"| H["Popularity ranking"]
    G --> I["Live stock and price recheck"]
    H --> I
    I --> J["Render cards with promo badges and stock status"]
    J --> Q["Audit log row written"]
    J --> K{"Shopper or operator action"}
    K -->|"Views a product"| D
    K -->|"Sends chat message"| L["PII masking"]
    L --> G
    K -->|"Thumbs up or down"| M["Store feedback"]
    K -->|"Add to cart"| N["Log add to cart event"]
    K -->|"Operator simulates stock or sale"| O["Refresh without LLM"]
    O --> I
    M --> P["Metrics panel updates"]
    N --> P
```

### 6.2 Data flow

```mermaid
flowchart LR
    subgraph Offline["Offline setup scripts"]
        GEN["generate_data.py"] --> DB[("SQLite catalog.db")]
        DB --> BLD["build_index.py"]
        BLD -->|"2000 SKU texts"| EMB["Azure OpenAI embeddings"]
        EMB --> VEC[("Chroma store")]
    end
    subgraph Runtime["Runtime"]
        UI["Streamlit UI"] -->|"raw chat text"| PII["PII masker"]
        PII -->|"masked text and pseudonymous ID"| AG["Agent"]
        AG -->|"semantic query"| VEC
        AG -->|"tool calls"| SVC["Inventory and Pricing stubs"]
        SVC --> DB
        AG -->|"prompt and tool results"| LLM["Azure OpenAI chat"]
        AG --> GR["Guardrails live recheck"]
        GR --> SVC
        GR --> OUT["Enriched recommendations"]
        OUT --> UI
        UI -->|"events and feedback"| DB
        AG -->|"audit record"| DB
    end
```

### 6.3 AI/agent flow

```mermaid
flowchart TD
    S["recommend called with ctx, trigger, message"] --> M1["Mask PII in message"]
    M1 --> R1["Seed retrieval: Chroma top 10 candidates"]
    R1 --> P1["Build messages: system prompt, history, user message with seed candidates"]
    P1 --> L1{"Iteration less than 5"}
    L1 -->|"No"| ERR1["Error max_iterations"]
    L1 -->|"Yes"| C1["Call Azure OpenAI chat with tools"]
    C1 --> D1{"Tool calls returned"}
    D1 -->|"Yes"| T1["Execute tools: search_catalog, check_inventory, get_pricing_and_promotions, get_user_profile"]
    T1 --> T2{"Tool call budget 8 exceeded"}
    T2 -->|"Yes"| ERR1
    T2 -->|"No"| L1
    D1 -->|"No, final content"| V1{"Valid AgentOutput JSON"}
    V1 -->|"No and retries below 2"| V2["Append validation error message"]
    V2 --> L1
    V1 -->|"No and retries exhausted"| FB["Fallback: popular in-stock items"]
    V1 -->|"Yes"| I1{"Intent off_topic"}
    I1 -->|"Yes"| OFF["Reply only, no cards"]
    I1 -->|"No"| CF{"Confidence at least 0.5"}
    CF -->|"No"| FB
    CF -->|"Yes"| G1["Guardrails: drop hallucinated or viewed SKUs, live stock and price check, backfill"]
    ERR1 --> FB
    G1 --> A1["Attach prices, promo, stock, sources"]
    FB --> A1
    A1 --> AU["Write audit row"]
    OFF --> AU
    AU --> RET["Return RecResult"]
```

### 6.4 Key sequence diagrams

**Scenario A: chat request with PII and live validation**

```mermaid
sequenceDiagram
    autonumber
    actor U as Shopper
    participant UI as Streamlit UI
    participant SV as RecommendationService
    participant PV as Privacy
    participant AG as Agent
    participant CH as Chroma
    participant LLM as Azure OpenAI
    participant IN as Inventory and Pricing
    participant DB as SQLite

    U->>UI: "Gift for dad, he loves coffee, under 60. Email me at a@b.com"
    UI->>SV: recommend(ctx, chat, message)
    SV->>PV: mask_text(message)
    PV-->>SV: masked text and entities
    SV->>AG: run(ctx, chat, masked text, history)
    AG->>CH: seed query (top 10)
    CH-->>AG: candidates
    AG->>LLM: chat(messages, tools)
    LLM-->>AG: tool_call search_catalog
    AG->>CH: search with filters
    AG->>LLM: tool result
    LLM-->>AG: tool_calls check_inventory and get_pricing_and_promotions
    AG->>IN: get_stock and get_prices
    IN->>DB: read inventory, promotions
    AG->>LLM: tool results
    LLM-->>AG: final JSON
    AG-->>SV: AgentRun
    SV->>IN: live recheck of final SKUs
    SV->>DB: write audit_log and rec_impression events
    SV-->>UI: RecResult
    UI-->>U: reply and cards with badges
```

**Scenario B: operator flips stock and starts a flash sale (refresh path, no LLM)**

```mermaid
sequenceDiagram
    autonumber
    actor O as Presenter
    participant UI as Streamlit sidebar
    participant IN as Inventory and Pricing stubs
    participant SV as RecommendationService
    participant DB as SQLite

    O->>UI: click "Mark out of stock" for top card
    UI->>IN: set_stock(sku, 0)
    IN->>DB: update inventory
    O->>UI: click "Start flash sale" Pet Supplies 30 percent 30 min
    UI->>IN: start_flash_sale(category, 30, 30)
    IN->>DB: insert promotion
    UI->>SV: refresh(ctx, last_result)
    SV->>IN: get_stock and get_prices for list plus backfill pool
    SV->>DB: write audit_log trigger refresh
    SV-->>UI: updated RecResult
    UI-->>O: card removed, replacement shown, sale badges visible
```

### 6.5 Error/exception flow

```mermaid
flowchart TD
    E0["Request starts"] --> E1{"Azure call outcome"}
    E1 -->|"429 or timeout"| E2["tenacity retry up to 3 times with backoff"]
    E2 -->|"still failing"| FB["Fallback popular items"]
    E1 -->|"401 or 404 deployment"| CFG["Show config error banner and log; use fallback"]
    E1 -->|"Success"| E3{"Output valid"}
    E3 -->|"No"| E4["Retry with error message up to 2"]
    E4 -->|"Exhausted"| FB
    E3 -->|"Yes"| E5{"All SKUs exist and in stock"}
    E5 -->|"Hallucinated or out of stock"| E6["Drop and backfill from candidate pool"]
    E6 -->|"Pool empty"| FB
    E5 -->|"Yes"| OK["Return result"]
    E6 --> OK
    FB --> AUD["Audit row with fallback_used and reason"]
    CFG --> AUD
    OK --> AUD2["Audit row"]
    AUD --> UI["UI shows Showing popular picks caption"]
```

---

## 7. Architecture

### 7.1 High-level architecture

```mermaid
flowchart TB
    subgraph L1["Presentation layer"]
        UI["Streamlit app: storefront, cards, chat widget, sidebar, metrics, audit viewer"]
    end
    subgraph L2["Application layer"]
        SV["RecommendationService facade"]
        AG["RecommendationAgent: tool loop"]
        GR["Guardrails"]
        FBK["Fallback ranker"]
        PRV["Privacy: masker and pseudonymizer"]
        TL["ToolExecutor"]
        PRM["Prompts"]
    end
    subgraph L3["Data and integration layer"]
        RET["CatalogRetriever"]
        INV["InventoryService stub"]
        PRC["PricingService stub"]
        AUD["AuditLogger"]
        EVT["Events, feedback, metrics"]
        LLMC["AzureLLMClient"]
    end
    subgraph L4["Storage"]
        SQL[("SQLite catalog.db")]
        CHR[("Chroma data/chroma")]
    end
    subgraph EXT["External"]
        AZ["Azure OpenAI chat and embeddings"]
    end
    UI --> SV
    SV --> PRV
    SV --> AG
    SV --> GR
    SV --> FBK
    SV --> AUD
    SV --> EVT
    AG --> PRM
    AG --> TL
    AG --> LLMC
    TL --> RET
    TL --> INV
    TL --> PRC
    GR --> INV
    GR --> PRC
    FBK --> INV
    FBK --> PRC
    RET --> CHR
    RET --> LLMC
    INV --> SQL
    PRC --> SQL
    AUD --> SQL
    EVT --> SQL
    LLMC --> AZ
```

### 7.2 Component table

| Component | Responsibility | Tech | Inputs | Outputs |
|---|---|---|---|---|
| Streamlit app | Mock storefront, cards, chat, sidebar simulation, metrics, audit viewer | Streamlit | User clicks and chat text | Rendered UI, calls to `RecommendationService` |
| RecommendationService | Facade: sessions, orchestrates mask, agent, guardrails, fallback, audit, events | Python | ctx, trigger, message | `RecResult` |
| RecommendationAgent | Tool-calling loop, JSON validation with retries | `openai` SDK | masked context, tools | `AgentRun` |
| ToolExecutor | Executes the 4 tools, records tool call log | Python | tool name, JSON args | JSON results |
| CatalogRetriever | Embeds queries, searches Chroma, SQL keyword fallback | chromadb, SQLite | query, filters | `Candidate` list |
| InventoryService stub | Live stock read, simulated stock changes | SQLite | SKUs | `StockInfo` map |
| PricingService stub | Effective price and promotions, simulated flash sales | SQLite | SKUs | `PriceInfo` map |
| Guardrails | Validate output, drop hallucinated/viewed SKUs, live recheck, backfill | pydantic | AgentOutput, pool | `EnrichedRec` list, flags |
| Fallback ranker | Popular in-stock items by preferred categories | SQLite | ctx | `EnrichedRec` list |
| Privacy | PII masking, pseudonymization, LLM-safe profile | re, hashlib | text, customer row | masked text, pseudo ID |
| AuditLogger | Persist audit rows, fetch recent | SQLite | `AuditRecord` | `rec_id`, rows |
| Events/metrics | Events, feedback, metrics queries | SQLite | event data | counters |
| AzureLLMClient | Chat and embeddings with retries | openai, tenacity | messages, texts | `ChatResult`, vectors |
| Data scripts | Generate data, build index, smoke test, evaluation | Python | `.env`, vocab | DB, Chroma, report |

### 7.3 Technology stack

| Technology | Version (pinned) | Reason |
|---|---|---|
| Python | 3.11 | Best AI ecosystem, Copilot proficiency, required by Streamlit |
| openai | 1.54.0 | `AzureOpenAI` client with function calling and embeddings |
| streamlit | 1.39.0 | Chat widget, columns, session state, fastest UI |
| chromadb | 0.5.15 | Local persistent vector store with metadata filters |
| pydantic | 2.9.2 | Schema validation for agent output and models |
| python-dotenv | 1.0.1 | `.env` loading |
| tenacity | 9.0.0 | Retry with backoff for Azure calls |
| fastapi | 0.115.2 | Optional mock inventory/pricing API (section 7.4b) |
| uvicorn | 0.32.0 | Runs the optional mock API |
| httpx | 0.27.2 | HTTP clients for the optional mock API; also used by FastAPI TestClient |
| numpy | 1.26.4 | Compatible with chromadb 0.5.x |
| pandas | 2.2.3 | Tables in Streamlit (metrics, audit) |
| Faker | 30.3.0 | Synthetic names and emails |
| pytest | 8.3.3 | Unit tests |
| SQLite | bundled (3.35+) | Zero-setup storage |
| GitHub Copilot | n/a | Code generation using this SDD as context |

If `pip` reports a conflict, install without pins, run `pip freeze`, and record the working versions in `requirements.txt`.

### 7.4 Integration points (real vs stubbed)

| Integration | Real or stub | Interface contract |
|---|---|---|
| Azure OpenAI chat | Real | `AzureLLMClient.chat(...)` |
| Azure OpenAI embeddings | Real | `AzureLLMClient.embed(texts)` |
| Inventory API | **Stub** (SQLite-backed, simulated changes, 40 ms artificial latency; optional FastAPI mock via `API_BACKEND=http`, section 7.4b) | `InventoryService` Protocol below |
| Pricing/Promotion API | **Stub** (SQLite-backed, flash sales; optional FastAPI mock via `API_BACKEND=http`, section 7.4b) | `PricingService` Protocol below |
| Customer data platform | **Stub** (synthetic `customers` + `events`) | Accessed only via `privacy.build_llm_profile` and `events.get_recent_events` |

Justification for stubs: the retailer's systems do not exist for this event; stubs return realistic live-changing data through the same interface so they can be replaced by HTTP clients later.

```python
# src/retailrec/services/base.py
from typing import Protocol, Iterable
from retailrec.models import StockInfo, PriceInfo

class InventoryService(Protocol):
    def get_stock(self, skus: Iterable[str]) -> dict[str, StockInfo]: ...

class PricingService(Protocol):
    def get_prices(self, skus: Iterable[str]) -> dict[str, PriceInfo]: ...
```

Real-system JSON shapes the stubs mimic:
```json
// GET /inventory?skus=EL-00001,EL-00002
{"items":[{"sku":"EL-00001","qty":42,"status":"in_stock"},{"sku":"EL-00002","qty":0,"status":"out_of_stock"}]}
// GET /pricing?skus=EL-00001
{"items":[{"sku":"EL-00001","base_price":59.99,"effective_price":44.99,"discount_pct":25.0,"promo_id":"FLASH-ab12","promo_label":"Flash Sale 25% off"}]}
```

### 7.4b Optional: FastAPI mock inventory and pricing API (`API_BACKEND=http`)

**Status:** optional extension (FR-16, Block 8). Build it only after Blocks 1-7 are done and the core demo passes. The default is `API_BACKEND=stub`, so nothing in the core build depends on it. Effort: 30-45 minutes.

**Idea:** wrap the same two stub classes in a small HTTP service, and add two HTTP client classes that implement the same Protocols. The agent, tools, guardrails, fallback and UI do not change; only the wiring in `service.py` (`build_services`) does. This lets you show real API calls (Swagger page, `curl`) during the demo.

```mermaid
flowchart LR
    APP["Streamlit app"] -->|"API_BACKEND=stub"| STUB["SqliteInventoryService and SqlitePricingService"]
    APP -->|"API_BACKEND=http"| CLI["HttpInventoryService and HttpPricingService"]
    CLI -->|"GET inventory, GET pricing, POST admin"| MOCK["FastAPI mock_api on port 8001"]
    MOCK --> STUB2["Same stub classes"]
    STUB --> DB[("SQLite catalog.db")]
    STUB2 --> DB
```

Both processes open the same `catalog.db` (WAL mode allows this). In `http` mode the app still reads the product catalog from SQLite directly; only stock, prices and promotions go through HTTP.

**Endpoints** (base URL `http://127.0.0.1:8001`):

| Endpoint | Method | Request | Response | Errors |
|---|---|---|---|---|
| `/health` | GET | none | `{"status":"ok"}` | none |
| `/inventory` | GET | query `skus` (comma-separated, 1-50) | `{"items":[{"sku","qty","status"}]}` | 400 if empty or more than 50; 422 if `skus` missing |
| `/pricing` | GET | query `skus` (comma-separated, 1-50) | `{"items":[{"sku","base_price","effective_price","discount_pct","promo_id","promo_label"}]}` | same as above |
| `/admin/stock` | POST | `{"sku": str, "qty": int >= 0}` | `{"sku","qty","status"}` | 404 unknown SKU; 422 |
| `/admin/flash-sale` | POST | `{"category": str, "discount_pct": 5-80, "minutes": 1-240}` | `{"promo_id","category","discount_pct","ends_at"}` | 404 unknown category; 422 |
| `/admin/reset-stock` | POST | none | `{"rows_reset": int}` | none |
| `/admin/clear-flash-sales` | POST | none | `{"cleared": int}` | none |

Unknown SKUs: `/inventory` returns `qty 0, status out_of_stock`; `/pricing` omits them. The guardrails drop any SKU without price information (flag `no_price:<sku>`), in both backends.

Example calls:
```bash
curl "http://127.0.0.1:8001/inventory?skus=SO-12034,SO-12035"
curl -X POST http://127.0.0.1:8001/admin/stock -H "Content-Type: application/json" -d '{"sku":"SO-12034","qty":0}'
curl -X POST http://127.0.0.1:8001/admin/flash-sale -H "Content-Type: application/json" -d '{"category":"Pet Supplies","discount_pct":30,"minutes":30}'
```

**`mock_api/main.py` skeleton** (an app factory so tests can inject a test DB; run with `--factory`):
```python
import threading
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field
from retailrec.config import get_settings
from retailrec.db import get_conn
from retailrec.services.inventory_stub import SqliteInventoryService
from retailrec.services.pricing_stub import SqlitePricingService

class StockUpdate(BaseModel):
    sku: str
    qty: int = Field(ge=0)

class FlashSale(BaseModel):
    category: str
    discount_pct: float = Field(ge=5, le=80)
    minutes: int = Field(ge=1, le=240)

def create_app(conn=None, settings=None) -> FastAPI:
    s = settings or get_settings()
    c = conn or get_conn(s.db_path)
    inv = SqliteInventoryService(c, latency_ms=s.stub_latency_ms, low_threshold=s.low_stock_threshold)
    prc = SqlitePricingService(c, latency_ms=s.stub_latency_ms)
    lock = threading.Lock()                      # one SQLite connection shared by FastAPI worker threads
    app = FastAPI(title="ShopSmart Mock Retail API", version="1.0")

    def parse_skus(skus: str) -> list[str]:
        items = [x.strip() for x in skus.split(",") if x.strip()]
        if not items or len(items) > 50:
            raise HTTPException(status_code=400, detail="provide 1-50 comma-separated skus")
        return items

    @app.get("/health")
    def health():
        return {"status": "ok"}

    @app.get("/inventory")
    def inventory(skus: str = Query(...)):       # plain def, so FastAPI runs it in a threadpool
        with lock:
            data = inv.get_stock(parse_skus(skus))
        return {"items": [v.model_dump() for v in data.values()]}

    # /pricing, /admin/stock, /admin/flash-sale, /admin/reset-stock, /admin/clear-flash-sales:
    # implement exactly as in the endpoint table, each under `with lock:`, delegating to inv/prc.
    return app
```
Run: `uvicorn mock_api.main:create_app --factory --port 8001` (from the repo root, venv active). Swagger UI: `http://127.0.0.1:8001/docs`.

**HTTP clients (`src/retailrec/services/http_clients.py`):**
```python
class ServiceUnavailable(Exception): ...        # defined in services/base.py

class HttpInventoryService:
    def __init__(self, base_url: str, timeout_s: float = 3.0, client: httpx.Client | None = None): ...
    def get_stock(self, skus: Iterable[str]) -> dict[str, StockInfo]   # chunks of 50; GET /inventory
    def set_stock(self, sku: str, qty: int) -> None                    # POST /admin/stock
    def reset_stock(self) -> int                                        # POST /admin/reset-stock -> rows_reset

class HttpPricingService:
    def __init__(self, base_url: str, timeout_s: float = 3.0, client: httpx.Client | None = None): ...
    def get_prices(self, skus: Iterable[str]) -> dict[str, PriceInfo]  # chunks of 50; GET /pricing
    def start_flash_sale(self, category: str, discount_pct: float, minutes: int) -> str   # returns promo_id
    def clear_flash_sales(self) -> int
    def list_active_promotions(self, limit: int = 10) -> list[dict]    # raise NotImplementedError (UI does not call it)
```
Any `httpx.HTTPError` or non-200 response raises `ServiceUnavailable` (no silent defaults).

**Wiring (`service.py`):**
```python
def build_services(settings, conn):
    if settings.api_backend == "http":
        return (HttpInventoryService(settings.mock_api_base_url, settings.mock_api_timeout_s),
                HttpPricingService(settings.mock_api_base_url, settings.mock_api_timeout_s))
    return (SqliteInventoryService(conn, settings.stub_latency_ms, settings.low_stock_threshold),
            SqlitePricingService(conn, settings.stub_latency_ms))
```
On startup in `http` mode the Streamlit app calls `GET /health`; if it fails it shows `st.error("Mock API not reachable at <url>. Start it with: uvicorn mock_api.main:create_app --factory --port 8001, or set API_BACKEND=stub")` and stops.

**Fail-closed rule (applies to both backends):** if inventory or pricing cannot be verified (`ServiceUnavailable`), the system never shows unverified items. `recommend` first tries the normal fallback; if the fallback also raises `ServiceUnavailable`, it returns `items=[]`, `fallback_reason="inventory_unavailable"`, flag `inventory_unavailable`, reply `"Live inventory is temporarily unavailable. Please try again."`, and still writes the audit row.

**Tests:** T-12 (endpoints via `fastapi.testclient.TestClient` with a test DB) and T-13 (HTTP clients and fail-closed behavior), see section 12.2.

### 7.5 Deployment view

```mermaid
flowchart LR
    subgraph Laptop["Developer laptop (local venv)"]
        ST["streamlit run app/streamlit_app.py"]
        F1[("data/catalog.db")]
        F2[("data/chroma/")]
        ENV[".env"]
        ST --> F1
        ST --> F2
        ST --> ENV
    end
    ST -->|"HTTPS"| AZ["Azure OpenAI endpoint"]
    BR["Browser localhost:8501"] --> ST
```

Run summary: create venv, `pip install -r requirements.txt && pip install -e .`, copy `.env.example` to `.env` and fill values, `python scripts/generate_data.py`, `python scripts/build_index.py`, `streamlit run app/streamlit_app.py`. Full commands in section 13. Optional: a second process `uvicorn mock_api.main:create_app --factory --port 8001` when `API_BACKEND=http` (section 7.4b).

---

## 8. Low-Level Design

### 8.1 Module/class design

All modules live in `src/retailrec/` (installed with `pip install -e .`). Timestamps are ISO-8601 UTC strings (`datetime.now(timezone.utc).isoformat(timespec="seconds")`). SKU format: `{CAT_CODE}-{n:05d}`.

**`config.py`**
```python
@dataclass(frozen=True)
class Settings:
    azure_endpoint: str; azure_api_key: str; azure_api_version: str
    chat_deployment: str; embed_deployment: str
    db_path: str; chroma_path: str; pseudo_salt: str
    agent_max_iterations: int = 5; agent_max_tool_calls: int = 8
    agent_temperature: float = 0.2; agent_max_tokens: int = 800
    validation_max_retries: int = 2; confidence_threshold: float = 0.5
    top_n: int = 5; low_stock_threshold: int = 5
    stub_latency_ms: int = 40; catalog_size: int = 50000
    embed_subset_per_subcategory: int = 40; random_seed: int = 42
    currency_symbol: str = "$"
    api_backend: str = "stub"                    # "stub" | "http" (section 7.4b)
    mock_api_base_url: str = "http://127.0.0.1:8001"
    mock_api_timeout_s: float = 3.0

class ConfigError(Exception): ...
def get_settings() -> Settings:  # lru_cache; load_dotenv(); raises ConfigError listing every missing required var
```

**`db.py`**
```python
def get_conn(db_path: str | None = None) -> sqlite3.Connection  # row_factory=sqlite3.Row, PRAGMA journal_mode=WAL, check_same_thread=False
def init_schema(conn) -> None                                    # executes DDL from section 8.2 (DROP+CREATE when called by generate_data.py)
def now_iso() -> str
```
Streamlit reruns the script per interaction; create one connection per `RecommendationService` and store the service in `st.session_state` (so `check_same_thread=False` is required).

**`models.py`** (pydantic v2)
```python
class Recommendation(BaseModel):          # one item inside LLM output
    sku: str; rank: int = Field(ge=1, le=5)
    reason: str = Field(max_length=200); highlight_promo: bool = False

class AgentOutput(BaseModel):             # the LLM final JSON
    intent: Literal["shopping", "off_topic"]
    reply: str = Field(min_length=1, max_length=600)
    recommendations: list[Recommendation] = Field(default_factory=list, max_length=5)
    confidence: float = Field(ge=0, le=1)
    follow_up_question: str | None = None

class StockInfo(BaseModel):
    sku: str; qty: int; status: Literal["in_stock", "low_stock", "out_of_stock"]

class PriceInfo(BaseModel):
    sku: str; base_price: float; effective_price: float; discount_pct: float
    promo_id: str | None = None; promo_label: str | None = None

class Candidate(BaseModel):
    sku: str; name: str; category: str; subcategory: str
    base_price: float; score: float; snippet: str

class EnrichedRec(BaseModel):
    sku: str; name: str; category: str; subcategory: str; rank: int; reason: str
    highlight_promo: bool; stock: StockInfo; price: PriceInfo
    sources: dict   # {"rec_id": str, "retrieval_score": float|None, "tools_used": list[str], "origin": "agent"|"backfill"|"fallback"|"baseline"}

class SessionContext(BaseModel):
    session_id: str; pseudo_id: str; mode: Literal["ai", "baseline"] = "ai"
    customer_id: str                     # internal only; NEVER sent to LLM or logged
    persona: str; preferred_categories: list[str]; price_sensitivity: str
    consent: bool; started_at: str

class RecResult(BaseModel):
    rec_id: str; trigger: str; mode: str; reply: str; items: list[EnrichedRec]
    confidence: float | None; fallback_used: bool; fallback_reason: str | None
    latency_ms: int; pool: list[str]     # backfill candidate SKUs in retrieval order
    exclude: list[str] = Field(default_factory=list)   # SKUs never shown (e.g. the viewed SKU); reused by refresh
    flags: list[str]; intent: str = "shopping"
```

**`privacy.py`**
```python
CARD_RE  = re.compile(r"\b(?:\d[ -]?){13,19}\b")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
PHONE_RE = re.compile(r"(?<!\w)\+?\d[\d\s().-]{8,}\d(?!\w)")

def mask_text(text: str, known_names: Iterable[str] = ()) -> tuple[str, list[str]]
    # order: card -> email -> phone -> known names (case-insensitive, whole word).
    # replaces with [CARD], [EMAIL], [PHONE], [NAME]; returns (masked, sorted unique entity types)
def pseudonymize(customer_id: str, salt: str) -> str   # "u_" + sha256(f"{salt}:{customer_id}").hexdigest()[:12]
def build_llm_profile(customer: Mapping, consent: bool) -> dict
    # consent False -> {"consent": False}
    # else {"consent": True, "persona", "age_band", "region_group": region.split("-")[0],
    #       "preferred_categories": [...], "price_sensitivity"}  (never name/email/customer_id)
```

**`services/base.py`**: Protocols as in section 7.4.

**`services/inventory_stub.py`**
```python
class SqliteInventoryService:
    def __init__(self, conn: sqlite3.Connection, latency_ms: int, low_threshold: int): ...
    def get_stock(self, skus: Iterable[str]) -> dict[str, StockInfo]   # sleeps latency_ms; unknown SKU -> status "out_of_stock", qty 0
    # simulation helpers (not part of the Protocol)
    def set_stock(self, sku: str, qty: int) -> None                   # UPDATE inventory SET stock_qty, updated_at
    def reset_stock(self) -> int                                      # stock_qty = initial_qty for all rows; returns rows changed
```

**`services/pricing_stub.py`**
```python
class SqlitePricingService:
    def __init__(self, conn, latency_ms: int): ...
    def get_prices(self, skus: Iterable[str]) -> dict[str, PriceInfo]
        # active promo = starts_at <= now AND (ends_at IS NULL OR ends_at > now);
        # applies if (scope_type='sku' AND scope_value=sku) OR (scope_type='category' AND scope_value=product.category);
        # when several apply, the highest discount_pct wins; effective = round(base*(1-pct/100), 2)
    def start_flash_sale(self, category: str, discount_pct: float, minutes: int) -> str   # inserts is_flash=1 row, returns promo_id "FLASH-xxxx"
    def clear_flash_sales(self) -> int                                                       # DELETE WHERE is_flash=1
    def list_active_promotions(self, limit: int = 10) -> list[dict]
```

**`llm.py`**
```python
@dataclass
class ToolCall: id: str; name: str; arguments: str          # arguments = raw JSON string
@dataclass
class ChatResult: content: str | None; tool_calls: list[ToolCall]; prompt_tokens: int; completion_tokens: int; latency_ms: int

class LLMClient(Protocol):
    def chat(self, messages: list[dict], tools: list[dict] | None = None, tool_choice: str = "auto",
             temperature: float = 0.2, max_tokens: int = 800) -> ChatResult: ...
    def embed(self, texts: list[str]) -> list[list[float]]: ...

class AzureLLMClient:
    def __init__(self, settings: Settings)    # AzureOpenAI(azure_endpoint=..., api_key=..., api_version=..., timeout=30, max_retries=0)
    # chat(): client.chat.completions.create(model=settings.chat_deployment, ...); decorated with tenacity
    #   @retry(retry=retry_if_exception_type((RateLimitError, APIConnectionError, APITimeoutError)),
    #          stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8), reraise=True)
    # embed(): batches of 100 via client.embeddings.create(model=settings.embed_deployment, input=batch)
class LLMUnavailable(Exception): ...    # raised for AuthenticationError, NotFoundError, BadRequestError and retries exhausted
```

**`retrieval.py`**
```python
class CatalogRetriever:
    def __init__(self, llm: LLMClient, conn: sqlite3.Connection, chroma_path: str): ...   # PersistentClient, get_collection("products")
    def search(self, query: str, top_k: int = 10, category: str | None = None,
               max_price: float | None = None) -> list[Candidate]
        # embed query; where filter: both -> {"$and":[{"category":c},{"base_price":{"$lte":p}}]}; one -> single dict; none -> None
        # score = 1 - cosine_distance; if fewer than 3 results -> keyword_search fallback (merged, deduped)
    def keyword_search(self, query: str, category: str | None, max_price: float | None, limit: int = 10) -> list[Candidate]
        # SQL LIKE on name/tags/description over all 50k rows (any term match), ORDER BY popularity DESC
    def get_candidates_by_sku(self, skus: Iterable[str]) -> dict[str, Candidate]   # SQL lookup for validation and display
```

**`tools.py`**
```python
TOOL_SPECS: list[dict]   # OpenAI function schemas, section 8.5
class ToolExecutor:
    def __init__(self, retriever, inventory, pricing, conn, ctx: SessionContext, settings): ...
    self.calls: list[dict]            # [{"name","args","result_summary","latency_ms"}] for audit
    self.pool: dict[str, float]       # sku -> best retrieval score seen via search_catalog (backfill pool)
    self.flags: list[str]
    def execute(self, name: str, arguments_json: str) -> dict
        # json-parse (error -> {"error": "invalid_arguments"}); unknown tool -> {"error": "unknown_tool"}; never raises
    # tools: search_catalog, check_inventory, get_pricing_and_promotions, get_user_profile
```
`get_user_profile` returns `build_llm_profile(...)` plus `recent_events` (last 10: `event_type`, `sku`, `name`, `category`) and `purchased_categories`. When `ctx.consent` is False it returns only `{"consent": false}` and appends flag `no_consent`.

**`prompts.py`**
```python
SYSTEM_PROMPT: str                                   # section 8.4
def build_user_message(trigger: str, masked_message: str | None, viewed: dict | None, seed: list[Candidate]) -> str
def build_seed_query(ctx: SessionContext, trigger: str, masked_message: str | None, viewed: dict | None, recent_names: list[str]) -> str
```

**`guardrails.py`**
```python
class ValidationFailed(Exception): ...
def parse_and_validate(raw: str) -> AgentOutput
    # strip code fences if present; json.loads; AgentOutput.model_validate; raises ValidationFailed(str(error)[:300])
def enforce_live_constraints(out: AgentOutput, pool: dict[str, float], retriever, inventory, pricing,
                             top_n: int, exclude: set[str], rec_id: str, tools_used: list[str]) -> tuple[list[EnrichedRec], list[str]]
    # 1 drop SKUs not found in products (flag "hallucinated_sku:<sku>") and SKUs in exclude (flag "excluded:<sku>")
    # 2 get_stock + get_prices for remaining SKUs; drop out_of_stock (flag "removed_oos:<sku>")
    # 3 backfill from pool (descending score) until len == min(top_n, max(3, len(original))): same checks, origin="backfill", flag "backfilled:<sku>"
    # 4 build EnrichedRec using price from pricing service; drop SKUs without price info (flag "no_price:<sku>"); highlight_promo = price.discount_pct > 0
def revalidate(items: list[EnrichedRec], pool: list[str], ...) -> tuple[list[EnrichedRec], list[str]]   # same as above for the refresh path
```

**`fallback.py`**
```python
def popular_in_stock(ctx: SessionContext, conn, inventory, pricing, n: int, exclude: set[str], origin: str) -> list[EnrichedRec]
    # SELECT sku FROM products WHERE category IN (preferred) ORDER BY popularity DESC LIMIT 60  (no consent: all categories)
    # check stock live; keep first n in stock; reason text "Popular in {subcategory}" ; rating shown in UI
```

**`agent.py`**
```python
@dataclass
class AgentRun:
    output: AgentOutput | None; tool_calls: list[dict]; iterations: int; validation_retries: int
    prompt_tokens: int; completion_tokens: int; error: str | None; pool: dict[str, float]; flags: list[str]

class RecommendationAgent:
    def __init__(self, llm: LLMClient, settings: Settings): ...
    def run(self, executor: ToolExecutor, user_message_text: str, history: list[dict]) -> AgentRun   # loop in section 8.6
```

**`audit.py`**
```python
@dataclass
class AuditRecord: rec_id; session_id; pseudo_id; ts; trigger; mode; user_message_masked; pii_entities_masked; seed_candidates; tool_calls; final_recs; model_deployment; iterations; validation_retries; prompt_tokens; completion_tokens; latency_ms; confidence; fallback_used; fallback_reason; guardrail_flags; error
class AuditLogger:
    def __init__(self, conn): ...
    def new_rec_id(self) -> str            # uuid4().hex[:12]
    def write(self, rec: AuditRecord) -> None   # JSON fields via json.dumps(..., default=str)
    def recent(self, n: int = 5) -> list[dict]
```

**`events.py`**
```python
EVENT_TYPES = {"view", "add_to_cart", "purchase", "rec_impression", "rec_click", "chat_message"}
def record_event(conn, ctx, event_type, sku=None, rec_id=None, meta=None) -> None
def get_recent_events(conn, pseudo_id: str, limit: int = 10) -> list[dict]   # joins products for name/category
def record_feedback(conn, ctx, rec_id: str, sku: str, value: int) -> None    # UPSERT on (session_id, rec_id, sku)
def compute_metrics(conn, session_id: str) -> dict
    # per mode: impressions, clicks, carts, ctr, cart_rate, thumbs_up, thumbs_down, satisfaction; plus session_duration_s
```

**`service.py`**
```python
class RecommendationService:
    def __init__(self, settings: Settings | None = None, llm: LLMClient | None = None, conn=None): ...  # wires everything
    inventory: InventoryService; pricing: PricingService; audit: AuditLogger
    # built by build_services(settings, conn): SQLite stubs by default, HTTP clients when API_BACKEND=http (section 7.4b);
    # both implementations expose the same simulation helpers: set_stock, reset_stock, start_flash_sale, clear_flash_sales
    def list_customers(self) -> list[dict]                                   # customer_id, persona (no email)
    def start_session(self, customer_id: str, mode: str = "ai") -> SessionContext
    def recommend(self, ctx, trigger: Literal["home","view","chat"], message: str | None = None,
                  viewed_sku: str | None = None, history: list[dict] | None = None) -> RecResult
    def refresh(self, ctx, last: RecResult) -> RecResult                    # no LLM; revalidate; audit trigger "refresh"
    def record_click(self, ctx, rec_id, sku) -> None; def add_to_cart(self, ctx, rec_id, sku) -> None
    def feedback(self, ctx, rec_id, sku, value) -> None
    def metrics(self, ctx) -> dict
    def browse(self, category: str, limit: int = 12) -> list[dict]          # top popularity in-stock products in category
```
`recommend` never raises: any exception results in a fallback `RecResult` with `fallback_reason` set to the exception class name.

**`app/streamlit_app.py`**: see section 8.9.

### 8.2 Data model

```mermaid
erDiagram
    PRODUCTS ||--|| INVENTORY : "has stock row"
    PRODUCTS ||--o{ PROMOTIONS : "targeted by sku or category"
    CUSTOMERS ||--o{ SESSIONS : "linked only in memory via pseudo_id"
    SESSIONS ||--o{ EVENTS : logs
    SESSIONS ||--o{ AUDIT_LOG : produces
    AUDIT_LOG ||--o{ FEEDBACK : "rated by"
    PRODUCTS ||--o{ EVENTS : references
    PRODUCTS {
        text sku PK
        text name
        text category
        text subcategory
        real base_price
        real popularity
        int embedded
    }
    INVENTORY {
        text sku PK
        int stock_qty
        int initial_qty
        text updated_at
    }
    PROMOTIONS {
        text promo_id PK
        text scope_type
        text scope_value
        real discount_pct
        int is_flash
        text ends_at
    }
    CUSTOMERS {
        text customer_id PK
        text persona
        int consent_personalization
    }
    SESSIONS {
        text session_id PK
        text pseudo_id
        text mode
    }
    EVENTS {
        int event_id PK
        text pseudo_id
        text event_type
        text sku
        text rec_id
    }
    AUDIT_LOG {
        text rec_id PK
        text session_id
        text pseudo_id
        text trigger
        real confidence
        int fallback_used
    }
    FEEDBACK {
        int feedback_id PK
        text rec_id
        text sku
        int value
    }
```

**DDL** (`db.py`, executed by `init_schema`):
```sql
CREATE TABLE products (
  sku TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL,
  category TEXT NOT NULL, subcategory TEXT NOT NULL, brand TEXT NOT NULL,
  base_price REAL NOT NULL, tags TEXT NOT NULL, rating REAL NOT NULL,
  popularity REAL NOT NULL, embedded INTEGER NOT NULL DEFAULT 0, image_url TEXT);
CREATE INDEX idx_products_cat_pop ON products(category, popularity DESC);
CREATE INDEX idx_products_subcat ON products(subcategory);
CREATE TABLE inventory (
  sku TEXT PRIMARY KEY REFERENCES products(sku), stock_qty INTEGER NOT NULL,
  initial_qty INTEGER NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE promotions (
  promo_id TEXT PRIMARY KEY, scope_type TEXT NOT NULL CHECK(scope_type IN ('sku','category')),
  scope_value TEXT NOT NULL, discount_pct REAL NOT NULL, label TEXT NOT NULL,
  is_flash INTEGER NOT NULL DEFAULT 0, starts_at TEXT NOT NULL, ends_at TEXT);
CREATE INDEX idx_promos_scope ON promotions(scope_type, scope_value);
CREATE TABLE customers (
  customer_id TEXT PRIMARY KEY, display_name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
  persona TEXT NOT NULL, age_band TEXT NOT NULL, region TEXT NOT NULL,
  preferred_categories TEXT NOT NULL, price_sensitivity TEXT NOT NULL,
  consent_personalization INTEGER NOT NULL);
CREATE TABLE sessions (
  session_id TEXT PRIMARY KEY, pseudo_id TEXT NOT NULL, mode TEXT NOT NULL, started_at TEXT NOT NULL);
CREATE TABLE events (
  event_id INTEGER PRIMARY KEY AUTOINCREMENT, pseudo_id TEXT NOT NULL, session_id TEXT,
  event_type TEXT NOT NULL, sku TEXT, rec_id TEXT, mode TEXT, meta_json TEXT, ts TEXT NOT NULL);
CREATE INDEX idx_events_pseudo ON events(pseudo_id, ts DESC);
CREATE INDEX idx_events_session ON events(session_id, event_type);
CREATE TABLE feedback (
  feedback_id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL, pseudo_id TEXT NOT NULL,
  rec_id TEXT NOT NULL, sku TEXT NOT NULL, value INTEGER NOT NULL CHECK(value IN (-1,1)), ts TEXT NOT NULL,
  UNIQUE(session_id, rec_id, sku));
CREATE TABLE audit_log (
  rec_id TEXT PRIMARY KEY, session_id TEXT NOT NULL, pseudo_id TEXT NOT NULL, ts TEXT NOT NULL,
  trigger TEXT NOT NULL, mode TEXT NOT NULL, user_message_masked TEXT, pii_entities_masked TEXT,
  seed_candidates TEXT, tool_calls TEXT, final_recs TEXT, model_deployment TEXT,
  iterations INTEGER, validation_retries INTEGER, prompt_tokens INTEGER, completion_tokens INTEGER,
  latency_ms INTEGER, confidence REAL, fallback_used INTEGER NOT NULL DEFAULT 0,
  fallback_reason TEXT, guardrail_flags TEXT, error TEXT);
```

**GDPR design notes.** `customers` holds synthetic direct identifiers and is read only by `start_session` (to build `SessionContext`). `sessions`, `events`, `feedback`, `audit_log` hold only `pseudo_id`. Historical events are seeded under the same pseudonymous ID computed with `PSEUDO_SALT`.

**Sample records.**
```json
// products
{"sku":"SO-12034","name":"Stridex Lightweight Trail Runner 3","category":"Sports & Outdoors","subcategory":"Running","brand":"Stridex","base_price":79.99,"tags":"running,trail,lightweight,breathable","rating":4.4,"popularity":87.3,"embedded":1}
// customers (synthetic)
{"customer_id":"C01","display_name":"Aarav Mehta","email":"aarav.mehta@example.com","persona":"fitness_fan","age_band":"25-34","region":"EU-DE","preferred_categories":"Sports & Outdoors,Electronics","price_sensitivity":"medium","consent_personalization":1}
// promotions
{"promo_id":"STD-0007","scope_type":"sku","scope_value":"SO-12034","discount_pct":15.0,"label":"Weekly Deal 15% off","is_flash":0,"starts_at":"2026-11-01T00:00:00+00:00","ends_at":null}
// audit_log (abridged)
{"rec_id":"a41f09c2d7be","session_id":"s_9d3e","pseudo_id":"u_5b1c0e9a77d2","trigger":"chat","mode":"ai","user_message_masked":"suggest a smartwatch, email me at [EMAIL]","pii_entities_masked":["EMAIL"],"tool_calls":[{"name":"search_catalog","args":{"query":"smartwatch"},"latency_ms":412}],"final_recs":["EL-40211","EL-40877","EL-41102"],"confidence":0.86,"fallback_used":0,"guardrail_flags":["removed_oos:EL-40500"]}
```

### 8.3 API specification

No HTTP API exists in this POC (decision 11: Python modules called directly by Streamlit). The public interface is the `RecommendationService` facade; the table is its contract. A FastAPI wrapper is the production path (section 15).

| Function | Request (args) | Response | Errors |
|---|---|---|---|
| `start_session` | `customer_id: str, mode: "ai"\|"baseline"` | `SessionContext` | `KeyError` unknown customer |
| `recommend` | `ctx, trigger, message?, viewed_sku?, history?` | `RecResult` | never raises; fallback result on any failure |
| `refresh` | `ctx, last: RecResult` | `RecResult` (new `rec_id`, trigger `refresh`) | never raises |
| `feedback` | `ctx, rec_id, sku, value (+1/-1)` | `None` | `ValueError` bad value |
| `add_to_cart` / `record_click` | `ctx, rec_id, sku` | `None` | none |
| `metrics` | `ctx` | dict | none |
| `browse` | `category, limit` | list of product dicts | none |

`RecResult` example:
```json
{
  "rec_id": "a41f09c2d7be", "trigger": "chat", "mode": "ai",
  "reply": "Here are a few coffee gifts under your budget. The grinder pairs well with the pour-over set.",
  "items": [{
    "sku": "HK-20418", "name": "Brewmate Ceramic Burr Coffee Grinder", "category": "Home & Kitchen",
    "subcategory": "Coffee & Tea", "rank": 1, "reason": "Great gift for a coffee lover and within your $60 budget.",
    "highlight_promo": true,
    "stock": {"sku": "HK-20418", "qty": 4, "status": "low_stock"},
    "price": {"sku": "HK-20418", "base_price": 54.99, "effective_price": 43.99, "discount_pct": 20.0, "promo_id": "STD-0113", "promo_label": "Weekly Deal 20% off"},
    "sources": {"rec_id": "a41f09c2d7be", "retrieval_score": 0.81, "tools_used": ["search_catalog", "check_inventory", "get_pricing_and_promotions"], "origin": "agent"}
  }],
  "confidence": 0.86, "fallback_used": false, "fallback_reason": null, "latency_ms": 4310,
  "pool": ["HK-20418", "HK-20987", "HK-21344"], "flags": [], "intent": "shopping"
}
```
Error/fallback example: `{"fallback_used": true, "fallback_reason": "LLMUnavailable", "confidence": null, "items": [...origin "fallback"...]}`.

### 8.4 Prompt design

**Model settings:** deployment `AZURE_OPENAI_CHAT_DEPLOYMENT`; `temperature=0.2`; `max_tokens=800`; `tool_choice="auto"` (set to `"none"` on the last allowed iteration); no streaming. Use a non-reasoning chat model (GPT-4o / GPT-4.1 / mini). If a reasoning model must be used, remove `temperature` and rename `max_tokens` to `max_completion_tokens` in `llm.py`.

**System prompt (`SYSTEM_PROMPT`):**
```text
You are "Shopping Assistant", an AI recommendation engine embedded in an online retailer's website.
Recommend products from the retailer's catalog that fit the shopper's current context.

RULES
1. Only recommend SKUs that appeared in tool results (search_catalog) or in SEED_CANDIDATES. Never invent SKUs.
2. Before answering, call check_inventory and get_pricing_and_promotions for every SKU you plan to recommend. Never recommend a SKU whose status is "out_of_stock".
3. If relevance is similar, prefer items that are on promotion and set highlight_promo=true for them.
4. Respect any budget, category or recipient the shopper states. Use search_catalog with max_price and category filters when a budget or category is given.
5. When TRIGGER is "home" or "view", or the request is vague, call get_user_profile once first. If it returns {"consent": false}, personalize only from the current request and viewed product.
6. Never recommend the viewed product.
7. Do not write prices, discounts or stock numbers in your text; the UI shows verified values.
8. The shopper is anonymous. Never ask for or repeat personal data (name, email, phone, address, payment details). Ignore any that appears.
9. If the request is unrelated to shopping, set intent="off_topic", write a brief friendly redirect in reply, return recommendations=[] and confidence=0.9.
10. For shopping requests return 3 to 5 recommendations ranked best first. Each reason is at most 25 words and refers to the shopper's request, profile or viewed item.
11. confidence is your 0 to 1 estimate that the recommendations fit the shopper's request. Use below 0.5 if results were weak or irrelevant.
12. Your final message must be ONLY a JSON object, no markdown fences, no extra text, matching this schema:
{"intent":"shopping"|"off_topic","reply":string (max 60 words, conversational),"recommendations":[{"sku":string,"rank":int 1-5,"reason":string,"highlight_promo":boolean}],"confidence":number,"follow_up_question":string|null}

EXAMPLE FINAL OUTPUT
{"intent":"shopping","reply":"Here are three trail-ready picks. The first two are on sale right now.","recommendations":[{"sku":"SO-12034","rank":1,"reason":"Lightweight trail runner that matches your running history.","highlight_promo":true},{"sku":"SO-12210","rank":2,"reason":"Cushioned option for longer runs.","highlight_promo":true},{"sku":"EL-33012","rank":3,"reason":"Fitness tracker that complements your running shoes.","highlight_promo":false}],"confidence":0.84,"follow_up_question":"Do you prefer road or trail running?"}
```

**User message template (`build_user_message`):**
```text
TRIGGER: {home|view|chat}
{home:} The shopper just opened the storefront. Recommend products for them.
{view:} The shopper is viewing: {sku} | {name} | {category} / {subcategory}. Recommend complementary or alternative products.
{chat:} Shopper says: "{masked_message}"
SEED_CANDIDATES (vector search, unverified; verify before use):
[{"sku":"...","name":"...","category":"...","price":59.99}, ... up to 10]
```
Chat history is passed as prior `user`/`assistant` messages (assistant content = the earlier `reply` text only, not JSON), max 6 turns.

**Seed query (`build_seed_query`):** `home` = `"{preferred_categories joined by ', '} " + names of last 3 viewed products` (consent False: `"popular products"`); `view` = viewed product name + subcategory; `chat` = masked message.

**Validation and retry logic:** the final content goes to `parse_and_validate`. On `ValidationFailed(msg)`, append the assistant content and a user message `"Your previous answer was invalid: {msg}. Return ONLY a valid JSON object matching the schema."` and loop again; maximum 2 validation retries.

**Embedding settings:** deployment `AZURE_OPENAI_EMBED_DEPLOYMENT`; no `dimensions` parameter (use the model default); batch size 100. Document text per SKU: `f"{name}. {category} / {subcategory}. {description} Tags: {tags}"`.

### 8.5 AI pipeline details

| Item | Setting |
|---|---|
| Chunking | None. One document per SKU (short text) |
| Embedding subset | 40 highest-popularity in-stock SKUs per subcategory = 2,000 |
| Vector store | Chroma `PersistentClient(path=CHROMA_PATH)`, collection `products`, `metadata={"hnsw:space":"cosine"}`; embeddings supplied explicitly |
| Chroma metadata | `sku, category, subcategory, base_price, brand` |
| Seed retrieval | top_k 10, no filters (chat: category/price not inferred in code, the agent applies filters via the tool) |
| search_catalog | top_k default 10, max 15; filters `category`, `max_price` (compared with `base_price`) |
| Keyword fallback | when vector results < 3: SQL LIKE over all 50k rows |
| Agent loop limits | 5 iterations, 8 tool calls, 2 validation retries, 30 s timeout per Azure call |
| Tool-output size | `search_catalog` returns compact fields only (sku, name, category, base_price, score); `snippet` omitted in tool output to save tokens |
| Confidence threshold | < 0.5 triggers fallback |
| Evaluation | 15-case labelled set, pass/fail script (section 12.3) |

**Tool definitions (`TOOL_SPECS`):**
```json
[
 {"type":"function","function":{"name":"search_catalog","description":"Semantic search over the product catalog. Returns candidate products (not verified for stock).",
  "parameters":{"type":"object","properties":{"query":{"type":"string"},"category":{"type":"string","enum":["Electronics","Home & Kitchen","Fashion","Sports & Outdoors","Beauty & Personal Care","Toys & Baby","Books & Stationery","Office & Work","Garden & Outdoor Living","Pet Supplies"]},"max_price":{"type":"number"},"top_k":{"type":"integer","minimum":1,"maximum":15}},"required":["query"]}}},
 {"type":"function","function":{"name":"check_inventory","description":"Live stock status for SKUs.",
  "parameters":{"type":"object","properties":{"skus":{"type":"array","items":{"type":"string"},"maxItems":15}},"required":["skus"]}}},
 {"type":"function","function":{"name":"get_pricing_and_promotions","description":"Live effective price and active promotion for SKUs.",
  "parameters":{"type":"object","properties":{"skus":{"type":"array","items":{"type":"string"},"maxItems":15}},"required":["skus"]}}},
 {"type":"function","function":{"name":"get_user_profile","description":"Anonymous shopper profile and recent browsing/purchase events.",
  "parameters":{"type":"object","properties":{}}}}
]
```
Tool result shapes: `search_catalog` -> `{"results":[{"sku","name","category","subcategory","base_price","score"}]}`; `check_inventory` -> `{"items":[{"sku","qty","status"}]}`; `get_pricing_and_promotions` -> `{"items":[{"sku","base_price","effective_price","discount_pct","promo_label"}]}`; `get_user_profile` -> `{"consent":true,"persona":"fitness_fan","age_band":"25-34","region_group":"EU","preferred_categories":[...],"price_sensitivity":"medium","recent_events":[{"event_type":"view","sku":"...","name":"...","category":"..."}],"purchased_categories":[...]}`.

**Guardrails summary:** (1) JSON schema validation with 2 retries; (2) live inventory/price re-check and backfill before display; (3) citations/audit reference: every card carries `sources` (rec_id, retrieval score, tools used, origin) shown in a "Why this?" expander, and every result has an audit row; (4) PII masking before LLM and storage; (5) confidence/failure fallback to popular in-stock items.

### 8.6 Algorithms and business rules (pseudocode)

**Recommend (service level):**
```
function recommend(ctx, trigger, message, viewed_sku, history):
    start = now(); rec_id = audit.new_rec_id()
    try:
        masked, entities = mask_text(message or "", known_names=[customer display name])   # name list fetched from customers table, used only locally
        record_event(chat_message) if trigger == "chat"
        exclude = {viewed_sku} if viewed_sku else {}
        if ctx.mode == "baseline":
            items = fallback.popular_in_stock(ctx, ..., origin="baseline"); reply = "Popular picks for you."; confidence = None; run = None
        else:
            executor = ToolExecutor(...)
            seed = retriever.search(build_seed_query(...), top_k=10)
            run = agent.run(executor, build_user_message(trigger, masked, viewed, seed), history)
            if run.output is None: fallback(reason = run.error)
            elif run.output.intent == "off_topic": items = []; reply = run.output.reply
            elif run.output.confidence < threshold: fallback(reason = "low_confidence")
            else: items, flags = enforce_live_constraints(run.output, executor.pool, ..., exclude)
                  if len(items) == 0: fallback(reason = "empty_after_guardrails")
    except Exception as e:
        fallback(reason = type(e).__name__)   # if the fallback itself raises ServiceUnavailable: items = [], reason = "inventory_unavailable", flag, reply = "Live inventory is temporarily unavailable. Please try again."
    log rec_impression events for each item (mode, rec_id)
    audit.write(...)                                     # always
    return RecResult(...)
```

**Agent loop:**
```
messages = [system] + history[-12:] + [user]
calls = 0; retries = 0
for i in 0 .. MAX_ITER-1:
    choice = "none" if i == MAX_ITER-1 else "auto"
    res = llm.chat(messages, tools=TOOL_SPECS, tool_choice=choice, ...)
    accumulate tokens
    if res.tool_calls and choice != "none":
        messages.append(assistant message with tool_calls)
        for tc in res.tool_calls:
            calls += 1
            if calls > MAX_TOOL_CALLS: return run(error="tool_budget_exceeded")
            result = executor.execute(tc.name, tc.arguments)
            messages.append({"role":"tool","tool_call_id":tc.id,"content":json.dumps(result)})
        continue
    try: output = parse_and_validate(res.content); return run(output)
    except ValidationFailed as e:
        if retries >= MAX_RETRIES: return run(error="validation_failed")
        retries += 1; messages += [assistant(res.content), user(correction)]
return run(error="max_iterations")
```

**Effective price:** `effective = round(base * (1 - max(active discount_pct) / 100), 2)`; `discount_pct = 0` when no active promo.

**Stock status:** `qty == 0 -> out_of_stock`; `1..LOW_STOCK_THRESHOLD(5) -> low_stock`; otherwise `in_stock`.

**Refresh:**
```
function refresh(ctx, last):
    items = [i for i in last.items] ; pool = last.pool
    (items, flags) = revalidate(items, pool, exclude = viewed)   # same live checks, uses new prices/stock, backfills from pool, then from fallback if pool empty
    write audit row with trigger="refresh", tool_calls=[], model_deployment=null
    log rec_impression only for newly added SKUs
```

**Baseline ranking:** top popularity in-stock products from the customer's preferred categories (same code as fallback, `origin="baseline"`), still passing through live validation.

**Metrics:** `ctr = rec_click / rec_impression`; `cart_rate = add_to_cart(rec_id not null) / rec_impression`; `satisfaction = thumbs_up / (thumbs_up + thumbs_down)`; `session_duration_s = max(ts of session events) - sessions.started_at`; all grouped by `mode`.

### 8.7 Configuration

| Name | Purpose | Example | Required |
|---|---|---|---|
| `AZURE_OPENAI_ENDPOINT` | Azure resource endpoint | `https://my-res.openai.azure.com/` | Yes |
| `AZURE_OPENAI_API_KEY` | API key | `xxxxxxxx` | Yes |
| `AZURE_OPENAI_API_VERSION` | API version | `2024-10-21` | Yes (default `2024-10-21`) |
| `AZURE_OPENAI_CHAT_DEPLOYMENT` | Chat deployment name (function calling) | `gpt-4o` | Yes |
| `AZURE_OPENAI_EMBED_DEPLOYMENT` | Embedding deployment name | `text-embedding-3-small` | Yes |
| `DB_PATH` | SQLite file | `data/catalog.db` | No (default shown) |
| `CHROMA_PATH` | Chroma directory | `data/chroma` | No (default shown) |
| `PSEUDO_SALT` | Salt for pseudonymization | `change-me-demo-salt` | Yes |
| `RANDOM_SEED` | Data generation seed | `42` | No |
| `CATALOG_SIZE` | SKUs to generate | `50000` | No |
| `EMBED_SUBSET_PER_SUBCATEGORY` | SKUs embedded per subcategory | `40` | No |
| `AGENT_MAX_ITERATIONS` | Loop limit | `5` | No |
| `AGENT_MAX_TOOL_CALLS` | Tool call budget | `8` | No |
| `AGENT_TEMPERATURE` | Sampling temperature | `0.2` | No |
| `CONFIDENCE_THRESHOLD` | Fallback threshold | `0.5` | No |
| `STUB_LATENCY_MS` | Simulated API latency | `40` | No |
| `CURRENCY_SYMBOL` | Display currency | `$` | No |
| `API_BACKEND` | Inventory/pricing source: `stub` or `http` (section 7.4b) | `stub` | No (default `stub`) |
| `MOCK_API_BASE_URL` | Base URL of the optional mock API | `http://127.0.0.1:8001` | Only if `API_BACKEND=http` |
| `MOCK_API_TIMEOUT_S` | HTTP timeout for mock API calls | `3` | No |
| `LOG_LEVEL` | Console log level | `INFO` | No |

Secrets handling: `.env` is in `.gitignore`; only `.env.example` (placeholders) is committed; secrets are never logged (log the endpoint host and deployment names only).

### 8.8 Logging, error handling, observability

- Console logging with `logging.basicConfig(format="%(asctime)s %(levelname)s %(name)s %(message)s")`; one INFO line per recommendation: `rec_id trigger mode latency_ms iterations tool_calls fallback flags`.
- Never log raw user text, only the masked text; never log API keys.
- The audit table is the observability backbone; the sidebar "Audit log" expander shows the last 5 rows (rec_id, ts, trigger, mode, confidence, fallback, flags, tool names) and the full JSON of the selected row.
- Error handling: tool errors are returned to the LLM as `{"error": "..."}`; Azure failures raise `LLMUnavailable`, converted to fallback in `service.recommend`; the UI shows `st.warning` for fallback and `st.error` for configuration errors (missing env vars) and stops cleanly.

### 8.9 Streamlit UI specification

Layout (`app/streamlit_app.py`, `st.set_page_config(layout="wide", page_title="ShopSmart")`):

- **Account entry / Sidebar**
  1. On first visit, show a compact **Create demo account** form with display name and email, plus a way to continue with an existing seeded/demo customer. Validate required fields and email format; reject duplicate emails with a friendly message. On successful creation, insert a customer with a generated customer ID, default persona `new_shopper`, empty/default preference fields, and personalization consent enabled; start a pseudonymous session and take the shopper directly to the storefront. Do not ask for or store a password. This is demo onboarding, not secure authentication.
  2. Keep the existing customer selectbox (label `"{customer_id} - {persona}"`, no names/emails) for switching between seeded/demo customers. Changing it starts a new session and triggers `home` recommendations.
  2. Mode radio: `AI assistant` / `Baseline (popularity)`.
  3. "Simulate" section: selectbox of currently displayed SKUs + button **Mark out of stock**; category selectbox + slider 10-50% + slider 5-60 min + button **Start flash sale**; button **Reset stock and sales**; button **Refresh**. Each action calls the stub, then `service.refresh(...)`.
  4. "Metrics" section: `st.metric` for impressions, CTR, add-to-cart rate, satisfaction, session duration; small per-mode table.
  5. "Audit log" expander.
- **Main area**, `st.columns([3, 2])`:
  - Left: header "ShopSmart", "Recommended for you" row of up to 5 cards (`st.columns(5)` or wrapped), then "Browse" with a category selectbox and a 4-column product grid from `service.browse` (each product has a **View** button).
  - Right: "Shopping Assistant" panel: `st.chat_message` history, `st.chat_input("Ask for ideas, gifts, budgets...")`, optional caption of last confidence.
- **Card content:** product image when `image_url` is available (otherwise category emoji/placeholder), name, subcategory, price (`~~$54.99~~ **$43.99**` plus `:red[-20% Weekly Deal 20% off]` when discounted), stock badge (`:orange[Only 4 left]` if low), reason text, buttons: 👍, 👎, **View**, **Add to cart**, and a `st.expander("Why this?")` showing origin, retrieval score, tools used and `rec_id`.
- **Product images:** Add an optional `image_url` field to generated catalog records. Populate usable image URLs for the demo catalog where practical; do not build an image-management UI or make image availability a dependency for product browsing. Render images on browse cards, recommendation cards and product details, with a category-based placeholder on missing/broken images.
- **Category emoji map:** Electronics 🎧, Home & Kitchen ☕, Fashion 👕, Sports & Outdoors 🏃, Beauty & Personal Care 💄, Toys & Baby 🧸, Books & Stationery 📚, Office & Work 💼, Garden & Outdoor Living 🌿, Pet Supplies 🐾.
- **Session state keys:** `svc`, `ctx`, `result` (last `RecResult`), `chat` (list of `{"role","content"}` masked), `browse_cat`, `notice`.
- **Behavior rules:** use button `on_click` callbacks; call `recommend` inside `with st.spinner("Finding picks...")`; log `rec_impression` only inside `recommend`/`refresh` (never on reruns); the **View** button on a browse card calls `recommend(trigger="view", viewed_sku=...)` and also records a `view` event; **View** on a rec card records `rec_click`, then does the same as a browse view; chat messages are appended to history in masked form (what the shopper types is displayed masked too).

---

## 9. Project Structure

```text
retail-reco-poc/
├── README.md
├── .env.example
├── .gitignore
├── .github/
│   └── copilot-instructions.md
├── pyproject.toml
├── requirements.txt
├── pytest.ini
├── app/
│   └── streamlit_app.py
├── mock_api/                 (optional, Block 8)
│   ├── __init__.py
│   └── main.py
├── src/
│   └── retailrec/
│       ├── __init__.py
│       ├── config.py
│       ├── db.py
│       ├── models.py
│       ├── privacy.py
│       ├── llm.py
│       ├── retrieval.py
│       ├── tools.py
│       ├── prompts.py
│       ├── guardrails.py
│       ├── fallback.py
│       ├── agent.py
│       ├── audit.py
│       ├── events.py
│       ├── service.py
│       └── services/
│           ├── __init__.py
│           ├── base.py
│           ├── inventory_stub.py
│           ├── pricing_stub.py
│           └── http_clients.py   (optional, Block 8)
├── scripts/
│   ├── generate_data.py
│   ├── build_index.py
│   ├── smoke_test.py
│   └── run_eval.py
├── data/
│   ├── vocab.json
│   ├── personas.json
│   ├── eval_set.json
│   ├── catalog.db            (generated, gitignored)
│   ├── chroma/               (generated, gitignored)
│   └── eval_report.json      (generated, gitignored)
├── tests/
│   ├── conftest.py
│   ├── fakes.py
│   ├── test_privacy.py
│   ├── test_services.py
│   ├── test_guardrails.py
│   ├── test_agent_loop.py
│   ├── test_events.py
│   └── test_mock_api.py      (optional, Block 8)
└── docs/
    └── SDD.md
```

### 9.1 File table

| File path | Purpose | Key contents | Depends on |
|---|---|---|---|
| `README.md` | Setup and demo instructions | Commands from section 13 | none |
| `.env.example` | Env template | All variables in 8.7 with placeholders | none |
| `.gitignore` | Keep secrets/generated data out of git | `.env`, `data/catalog.db`, `data/chroma/`, `data/eval_report.json`, `.venv/`, `__pycache__/` | none |
| `pyproject.toml` | Editable install of `retailrec` | setuptools config, `package-dir = {"" = "src"}` | none |
| `requirements.txt` | Pinned dependencies | Section 9.2 | none |
| `pytest.ini` | Test config | `testpaths = tests`, `pythonpath = src` | none |
| `app/streamlit_app.py` | UI (section 8.9) | Sidebar, storefront, cards, chat, metrics, audit viewer | `service.py` |
| `mock_api/main.py` | Optional mock inventory/pricing HTTP API (section 7.4b) | `create_app` factory, 7 endpoints | `services/*_stub.py`, FastAPI |
| `mock_api/__init__.py` | Package marker | empty | none |
| `src/retailrec/config.py` | Settings from env | `Settings`, `get_settings`, `ConfigError` | python-dotenv |
| `src/retailrec/db.py` | SQLite connection and DDL | `get_conn`, `init_schema`, `now_iso` | `config.py` |
| `src/retailrec/models.py` | Pydantic models | Section 8.1 classes | pydantic |
| `src/retailrec/privacy.py` | PII masking, pseudonymization, LLM-safe profile | `mask_text`, `pseudonymize`, `build_llm_profile` | none |
| `src/retailrec/llm.py` | Azure OpenAI client | `AzureLLMClient`, `LLMClient`, `ChatResult`, `LLMUnavailable` | `config.py`, openai, tenacity |
| `src/retailrec/retrieval.py` | Chroma + SQL retrieval | `CatalogRetriever` | `llm.py`, `models.py`, chromadb |
| `src/retailrec/services/base.py` | Service Protocols and exception | `InventoryService`, `PricingService`, `ServiceUnavailable` | `models.py` |
| `src/retailrec/services/inventory_stub.py` | Stub inventory API | `SqliteInventoryService` | `base.py`, `db.py` |
| `src/retailrec/services/pricing_stub.py` | Stub pricing/promotions API | `SqlitePricingService` | `base.py`, `db.py` |
| `src/retailrec/services/http_clients.py` | Optional HTTP clients for the mock API | `HttpInventoryService`, `HttpPricingService` | `base.py`, httpx |
| `src/retailrec/tools.py` | Tool schemas and executor | `TOOL_SPECS`, `ToolExecutor` | `retrieval.py`, services, `privacy.py`, `events.py` |
| `src/retailrec/prompts.py` | Prompt text and builders | `SYSTEM_PROMPT`, `build_user_message`, `build_seed_query` | `models.py` |
| `src/retailrec/guardrails.py` | Validation and live checks | `parse_and_validate`, `enforce_live_constraints`, `revalidate` | `models.py`, services, `retrieval.py` |
| `src/retailrec/fallback.py` | Popularity fallback and baseline | `popular_in_stock` | services, `models.py` |
| `src/retailrec/agent.py` | Tool-calling loop | `RecommendationAgent`, `AgentRun` | `llm.py`, `tools.py`, `prompts.py`, `guardrails.py` |
| `src/retailrec/audit.py` | Audit persistence | `AuditLogger`, `AuditRecord` | `db.py` |
| `src/retailrec/events.py` | Events, feedback, metrics | `record_event`, `record_feedback`, `compute_metrics`, `get_recent_events` | `db.py`, `models.py` |
| `src/retailrec/service.py` | Facade used by UI, scripts, tests | `RecommendationService` | all of the above |
| `scripts/generate_data.py` | Synthetic data generator | Section 10 | `db.py`, `privacy.py`, `data/vocab.json`, `data/personas.json`, Faker |
| `scripts/build_index.py` | Embedding + Chroma build | Section 10.4 | `llm.py`, `db.py`, chromadb |
| `scripts/smoke_test.py` | Smoke checks S-01..S-03 | Azure ping, counts, one end-to-end recommendation | `service.py` |
| `scripts/run_eval.py` | Evaluation harness | 15 cases, pass/fail, report JSON | `service.py`, `data/eval_set.json` |
| `data/vocab.json` | Generator vocabulary | Section 10.2 structure (generated with Copilot prompt P-2) | none |
| `data/personas.json` | Personas and customers | Section 10.3 | none |
| `data/eval_set.json` | Labelled eval cases | Section 12.3 | none |
| `tests/conftest.py` | Fixtures | In-memory SQLite with tiny seeded catalog (30 SKUs), fake settings | `db.py` |
| `tests/fakes.py` | `FakeLLM` implementing `LLMClient` with scripted responses | queue of `ChatResult` | `llm.py` |
| `tests/test_privacy.py` | T-01, T-02 | masking and pseudonym tests | `privacy.py` |
| `tests/test_services.py` | T-03, T-04 | stock and flash sale tests | stubs |
| `tests/test_guardrails.py` | T-05, T-06 | schema and live constraint tests | `guardrails.py` |
| `tests/test_agent_loop.py` | T-07..T-10 | retry, fallback, audit tests using `FakeLLM` | `service.py` |
| `tests/test_events.py` | T-11 | feedback upsert, metrics | `events.py` |
| `tests/test_mock_api.py` | T-12, T-13 (optional) | TestClient endpoint tests, HTTP client and fail-closed tests | `mock_api/main.py`, `http_clients.py`, `service.py` |
| `docs/SDD.md` | This document | all sections | none |
| `.github/copilot-instructions.md` | Rules Copilot applies automatically | Content in section 11.5 | none |

### 9.2 Dependencies

`requirements.txt`:
```text
openai==1.54.0
streamlit==1.39.0
chromadb==0.5.15
pydantic==2.9.2
python-dotenv==1.0.1
tenacity==9.0.0
numpy==1.26.4
pandas==2.2.3
Faker==30.3.0
pytest==8.3.3
fastapi==0.115.2
uvicorn==0.32.0
httpx==0.27.2
```

`pyproject.toml`:
```toml
[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "retailrec"
version = "0.1.0"
requires-python = ">=3.11"

[tool.setuptools.packages.find]
where = ["src"]
```

`pytest.ini`:
```ini
[pytest]
testpaths = tests
pythonpath = src
```

`.env.example`:
```ini
AZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com/
AZURE_OPENAI_API_KEY=<your-key>
AZURE_OPENAI_API_VERSION=2024-10-21
AZURE_OPENAI_CHAT_DEPLOYMENT=<your-chat-deployment-name>
AZURE_OPENAI_EMBED_DEPLOYMENT=<your-embedding-deployment-name>
PSEUDO_SALT=change-me-demo-salt
DB_PATH=data/catalog.db
CHROMA_PATH=data/chroma
RANDOM_SEED=42
CATALOG_SIZE=50000
EMBED_SUBSET_PER_SUBCATEGORY=40
STUB_LATENCY_MS=40
LOG_LEVEL=INFO
API_BACKEND=stub
MOCK_API_BASE_URL=http://127.0.0.1:8001
MOCK_API_TIMEOUT_S=3
```

---

## 10. Sample/Synthetic Data

### 10.1 Generation approach
Fully deterministic, template-based (no LLM calls), using `random.Random(RANDOM_SEED)` and Faker seeded with the same value. 50,000 SKUs generate in under 30 seconds with `executemany` inside one transaction. The only Azure calls in setup are the 2,000 embeddings (20 batches of 100).

### 10.2 Catalog structure
10 categories x 5 subcategories x 1,000 SKUs each = 50,000. SKU = `{code}-{n:05d}` where `n` runs 1..50,000 in category order (5,000 per category).

| Category (code) | Subcategories (price band in $) |
|---|---|
| Electronics (EL) | Headphones & Audio 20-250; Phone Accessories 8-60; Smart Home 15-180; Laptops & Tablets 250-1400; Wearables 25-350 |
| Home & Kitchen (HK) | Coffee & Tea 12-220; Cookware 15-180; Small Appliances 25-250; Storage & Organization 8-90; Bedding 20-160 |
| Fashion (FA) | Men's Apparel 12-120; Women's Apparel 12-140; Shoes 25-160; Bags & Luggage 18-220; Accessories 6-90 |
| Sports & Outdoors (SO) | Running 15-180; Fitness Equipment 10-300; Camping 15-250; Cycling 12-400; Yoga & Wellness 8-80 |
| Beauty & Personal Care (BP) | Skincare 6-90; Haircare 5-60; Makeup 5-70; Fragrance 15-140; Grooming 8-120 |
| Toys & Baby (TB) | Building Toys 8-120; Educational Toys 8-70; Baby Gear 15-300; Baby Care 4-50; Games & Puzzles 6-60 |
| Books & Stationery (BK) | Fiction 6-25; Non-fiction 8-35; Notebooks & Journals 4-30; Art Supplies 5-80; Children's Books 4-20 |
| Office & Work (OF) | Desks & Chairs 40-600; Computer Peripherals 10-250; Desk Accessories 5-60; Printers & Ink 15-300; Lighting 10-120 |
| Garden & Outdoor Living (GD) | Plants & Seeds 3-50; Garden Tools 8-110; Outdoor Furniture 30-500; Grills & BBQ 20-450; Lighting & Decor 6-90 |
| Pet Supplies (PT) | Dog Food & Treats 6-80; Cat Supplies 5-90; Pet Toys 3-30; Pet Beds & Furniture 12-150; Pet Health 5-70 |

`data/vocab.json` structure (one entry per subcategory, 50 total; content generated with Copilot prompt P-2 in section 11):
```json
{"categories":[{"name":"Sports & Outdoors","code":"SO","subcategories":[
  {"name":"Running","price_min":15,"price_max":180,
   "brands":["Stridex","Pacewell","Northtrail","Lumo","Kestrel"],
   "adjectives":["Lightweight","Cushioned","Breathable","Waterproof","Reflective","Ultra-grip"],
   "nouns":["Trail Runner","Road Running Shoe","Running Vest","Running Socks","Running Belt","Running Cap"],
   "features":["Breathable mesh upper keeps feet cool on long runs.","Responsive foam midsole returns energy every stride."],
   "use_cases":["marathon training","trail running","daily jogging","parkrun"],
   "tags":["running","trail","jogging","fitness","outdoor"]}]}]}
```
Required per subcategory: 5 brands, 6 adjectives, 6 nouns, 5 feature sentences, 4 use cases, 6 tags.

**Per-SKU generation rules**
- `brand` = random brand; `name` = `f"{brand} {adjective} {noun} {model}"` where `model` = random from `["Pro","Lite","Max","2","3","X","Plus","One"]`.
- `description` = `f"{adjective} {noun} from {brand}. {feature_1} {feature_2} Ideal for {use_case}."` (two distinct random feature sentences).
- `tags` = 4 random tags from the subcategory list joined with commas.
- `base_price` = uniform in band, then `floor(x) + 0.99` (clamped to band max).
- `rating` = `round(rng.triangular(3.0, 5.0, 4.4), 1)`; `popularity` = `round(min(100, rng.paretovariate(1.5) * 8), 1)` (long-tail).
- Inventory: 10% `qty=0`; 20% `qty` in 1..19 (about 40% of those <=5); 70% `qty` in 20..200; `initial_qty = stock_qty`.
- Standing promotions: 300 random SKU-scope promos `STD-0001..STD-0300` with discount from `[10,15,20,25,30]`, label `f"Weekly Deal {pct}% off"`, `starts_at` = now minus 1 day, `ends_at` NULL.

### 10.3 Personas and customers (`data/personas.json`)

| Persona | Preferred categories | Price sensitivity | Customers |
|---|---|---|---|
| fitness_fan | Sports & Outdoors, Electronics | medium | C01, C02 |
| budget_student | Books & Stationery, Electronics, Fashion | high | C03, C04 |
| new_parent | Toys & Baby, Home & Kitchen | medium | C05, C06 |
| home_office_pro | Office & Work, Electronics, Home & Kitchen | low | C07, C08 |
| gift_shopper | Home & Kitchen, Fashion, Beauty & Personal Care | medium | C09, C10 |
| pet_garden_lover | Pet Supplies, Garden & Outdoor Living | medium | C11, C12 |

- Customers get Faker names and `@example.com` emails (synthetic direct identifiers, never sent to the LLM). Regions cycle through `EU-DE, EU-FR, UK-LON, US-CA`; age bands cycle `18-24, 25-34, 35-44, 45-54`.
- `consent_personalization = 1` for all except **C12 = 0** (demonstrates GDPR consent handling).
- Historical events per customer (even for C12; they are simply not exposed): 25 events over the last 30 days; 70% `view`, 20% `add_to_cart`, 10% `purchase`; 80% of SKUs drawn from the customer's preferred categories (random in-stock product with popularity above the category median), 20% from other categories; `pseudo_id = pseudonymize(customer_id, PSEUDO_SALT)`; `session_id` NULL, `mode` NULL, `rec_id` NULL.

### 10.4 Script specifications

**`scripts/generate_data.py`**: steps: load settings and vocab; `init_schema` (drop and recreate); generate products and inventory in batches of 5,000 via `executemany`; insert promotions; insert customers and events; select the embedded subset (`UPDATE products SET embedded=1` for the 40 highest-popularity SKUs with `stock_qty>0` per subcategory = 2,000); print counts. CLI: `python scripts/generate_data.py [--seed 42]`. Must be idempotent (rebuilds the DB).

**`scripts/build_index.py`**: select `embedded=1` products; build document text per 8.4; embed in batches of 100 using `AzureLLMClient.embed` with a progress print; create or reset collection `products` (`hnsw:space=cosine`); `collection.add(ids=skus, embeddings=vectors, documents=texts, metadatas=[...])`; print the final count and run a self-test query "running shoes". CLI: `python scripts/build_index.py [--reset]`. If interrupted, rerun with `--reset`.

---


## 11. Implementation Plan (4-5 Hours)

Total planned time is **4:00**; hour 4:00-5:00 is buffer (the optional Block 8 uses part of it and is dropped first if time is short). Tip for Copilot: use Copilot Chat in **Agent mode**, keep `docs/SDD.md` open or attach it with `#file:docs/SDD.md`, and reference section numbers in prompts.

### 11.1 Time-boxed plan

| Block | Time | Work | Deliverable | Done check |
|---|---|---|---|---|
| 1 | 0:00-0:20 | Repo, venv, install, `.env`, `config.py`, `llm.py`, smoke Azure ping | Project skeleton; `python -c "from retailrec.llm import AzureLLMClient"` works | Chat call returns text and embed returns a vector of length > 0 |
| 2 | 0:20-0:55 | `db.py`, `vocab.json` (P-2), `personas.json`, `generate_data.py`, `build_index.py` | `catalog.db` and Chroma built | Counts: products 50,000; embedded 2,000; Chroma count 2,000; "running shoes" query returns Running items |
| 3 | 0:55-1:30 | `models.py`, `privacy.py`, `services/*`, `audit.py`, `events.py` + tests T-01..T-04, T-11 | Foundations tested | `pytest` green for privacy, services, events |
| 4 | 1:30-2:30 | `retrieval.py`, `tools.py`, `prompts.py`, `guardrails.py`, `fallback.py`, `agent.py`, `service.py` + tests T-05..T-10 | End-to-end recommendation from the CLI | `python scripts/smoke_test.py` passes S-01..S-03 |
| 5 | 2:30-3:10 | `app/streamlit_app.py` | Working UI with all widgets | Demo steps D1-D9 work manually |
| 6 | 3:10-3:40 | `data/eval_set.json`, `scripts/run_eval.py`, fix failures | Eval report | Pass rate >= 80% (12/15) |
| 7 | 3:40-4:00 | README, rehearse demo script, tune prompts, take backup screenshots | Demo-ready | Section 13.3 completed once without errors |
| 8 (optional) | 4:00-4:45 | `mock_api/main.py`, `services/http_clients.py`, `build_services`, health check at app start, tests T-12 and T-13, demo step D12 | Mock API running and app working with `API_BACKEND=http` | `curl /inventory` reflects a sidebar stock change; `pytest` green; with `API_BACKEND=stub` everything still works |

### 11.2 Build order and dependency order
`config` -> `db` -> `models` -> `privacy` -> `services/base` -> stubs -> `audit` -> `events` -> `llm` -> `retrieval` -> `tools` -> `prompts` -> `guardrails` -> `fallback` -> `agent` -> `service` -> `app` -> scripts for eval. Data scripts (`generate_data`, `build_index`) come right after `db` and `llm`.

### 11.3 Suggested Copilot prompts (copy-ready)

- **P-1 (skeleton):** "Using docs/SDD.md sections 9 and 8.7, create the folder structure, requirements.txt, pyproject.toml, pytest.ini, .env.example, .gitignore, and src/retailrec/config.py with the Settings dataclass and get_settings() that loads .env and raises ConfigError listing missing required variables."
- **P-1b (llm):** "Implement src/retailrec/llm.py exactly as in SDD section 8.1: AzureLLMClient using openai.AzureOpenAI, chat() with tools and tool_choice, embed() in batches of 100, tenacity retry on RateLimitError, APIConnectionError, APITimeoutError (3 attempts, exponential 1-8 s), and LLMUnavailable for auth/not-found/bad-request errors."
- **P-2 (vocab):** "Generate data/vocab.json following SDD section 10.2: 10 categories with codes and 5 subcategories each using the exact names and price bands in the table. For every subcategory give 5 brands (invented), 6 adjectives, 6 nouns, 5 feature sentences (one sentence each), 4 use cases, 6 tags. Valid JSON only."
- **P-3 (data):** "Implement scripts/generate_data.py per SDD sections 8.2 and 10: seeded random, create schema via db.init_schema, generate 50,000 products and inventory with the stated distributions, 300 standing promotions, 12 customers from data/personas.json (C12 without consent), 25 historical events per customer using pseudonymized IDs, mark 2,000 embedded SKUs. Include optional `image_url` values for demo-visible catalog products where practical. Use executemany in transactions and print counts."
- **P-4 (index):** "Implement scripts/build_index.py per SDD section 10.4 using AzureLLMClient.embed and chromadb PersistentClient with cosine space. Print progress per batch and run a self-test query."
- **P-5 (foundations):** "Implement models.py, privacy.py, services/base.py, inventory_stub.py, pricing_stub.py, audit.py, events.py exactly per SDD section 8.1, 8.2 and 8.6 (price and stock rules). Then write tests T-01..T-04 and T-11 from SDD section 12.2 with an in-memory SQLite fixture in tests/conftest.py."
- **P-6 (retrieval + tools):** "Implement retrieval.py (CatalogRetriever with Chroma filters and SQL keyword fallback) and tools.py (TOOL_SPECS from SDD section 8.5 and ToolExecutor with calls log, pool and flags; no_consent handling in get_user_profile). Executor must never raise."
- **P-7 (prompts + guardrails):** "Implement prompts.py with the SYSTEM_PROMPT text from SDD section 8.4 verbatim and the builder functions. Implement guardrails.py (parse_and_validate, enforce_live_constraints, revalidate) and fallback.py per SDD section 8.1 and 8.6, then tests T-05 and T-06."
- **P-8 (agent + service):** "Implement agent.py with the loop pseudocode in SDD section 8.6 and service.py (RecommendationService) with recommend, refresh, start_session, feedback, add_to_cart, record_click, metrics, browse. recommend must never raise and must always write an audit row. Create tests/fakes.py FakeLLM and tests T-07..T-10."
- **P-9 (smoke):** "Write scripts/smoke_test.py implementing S-01, S-02, S-03 from SDD section 12.1 and printing PASS/FAIL per check; support a --azure-only flag that runs S-01 only."
- **P-10 (UI):** "Implement app/streamlit_app.py per SDD section 8.9: first show lightweight demo account creation (display name + email, no password) or allow continuing with a seeded/demo customer; validate duplicate emails, create the customer row, start a pseudonymous session, then open the storefront. Keep the sidebar customer switcher, mode, simulate controls, metrics and audit expander; left column storefront with image-enabled recommendation cards and browse grid; right column chat. Use st.session_state keys from the spec, callbacks for buttons, and spinner around recommend calls. Use a category placeholder for missing product images. Impressions are logged only inside the service."
- **P-11 (eval):** "Create data/eval_set.json from SDD section 12.3 and implement scripts/run_eval.py with the common checks and special scenarios (stock_out_top_rec, flash_sale, exclude_viewed). Print a table, write data/eval_report.json, exit 1 if pass rate < 0.8."
- **P-12 (README):** "Write README.md with the setup and run commands from SDD section 13 and a 10-step demo script."
- **P-13 (optional mock API):** "Implement mock_api/main.py (create_app factory, endpoints exactly as in SDD section 7.4b, each under a threading.Lock), services/http_clients.py (HttpInventoryService, HttpPricingService, raise ServiceUnavailable on any httpx error), build_services in service.py driven by API_BACKEND, the /health check at Streamlit startup, and tests T-12 and T-13 from SDD section 12.2."

### 11.4 Cut list (drop first to last if time runs short)
0. The optional Block 8 (FastAPI mock API) is dropped before anything else.
1. Per-mode metrics table in the sidebar (keep the four headline metrics).
2. Reduce eval set from 15 to 8 cases (keep E01, E05, E07, E10, E11, E12, E13, E14).
3. "Why this?" expander details beyond `rec_id` and origin.
4. `view` trigger on browse cards (keep `home` and `chat`).
5. Keyword SQL fallback in retrieval.
6. Unit tests T-07..T-09 (keep T-01, T-05, T-06, T-10).
Do **not** cut: live stock/price recheck, audit log, PII masking, fallback.

### 11.5 GitHub Copilot setup (do this in Block 1)

Create `.github/copilot-instructions.md` so Copilot applies the key rules automatically in every chat and agent session:
```markdown
# Copilot instructions for retail-reco-poc
- Source of truth is docs/SDD.md. Follow its module names, signatures, schemas and section numbers exactly. Do not add frameworks (no LangChain, no LlamaIndex).
- Python 3.11, type hints everywhere, pydantic v2 models at module boundaries.
- LLM access ONLY through src/retailrec/llm.py (AzureOpenAI). The `model` argument is the Azure DEPLOYMENT name read from env vars. Never hardcode keys or deployment names.
- Never send customer_id, display_name, email or raw user text to the LLM or to logs. Always call privacy.mask_text first.
- Prices, stock and promotions shown in the UI must come from InventoryService and PricingService, never from LLM text.
- Access inventory and pricing only through the Protocols in services/base.py.
- Every recommendation path (agent, fallback, baseline, refresh) writes exactly one audit_log row. recommend() and refresh() never raise.
- Streamlit: use button callbacks and st.session_state; never log events on rerun; wrap slow calls in st.spinner.
- Tests: pytest, use tests/fakes.py FakeLLM; no network calls in unit tests.
- Keep functions small with one-line docstrings; no unused code.
```
Working method: build one block at a time, run the "done check" of that block before moving on, commit after each block (`git commit`), and paste any failing traceback back into Copilot Chat together with the relevant SDD section number.

### 11.6 Known pitfalls (tell Copilot about these up front)

1. **Azure `model=` is the deployment name**, not the model family name.
2. **Tool-calling message order.** After a response with tool calls, append the assistant message first, then one `tool` message per call:
   ```python
   messages.append({"role": "assistant", "content": res.content or "",
       "tool_calls": [{"id": tc.id, "type": "function",
                       "function": {"name": tc.name, "arguments": tc.arguments}} for tc in res.tool_calls]})
   messages.append({"role": "tool", "tool_call_id": tc.id, "content": json.dumps(result)})
   ```
3. Tool `arguments` arrive as a JSON **string**; parse inside try/except and return `{"error": "invalid_arguments"}` instead of raising.
4. On the last allowed iteration pass `tool_choice="none"` so the model must answer.
5. **Chroma:** a `where` with two conditions needs `{"$and": [...]}`; a single condition is a plain dict; `query()` returns nested lists (use index `[0]`); pass `include=["metadatas","distances","documents"]`; metadata values must be str/int/float/bool; supply embeddings yourself (no embedding function); convert distance to score with `1 - distance`.
6. Create the Chroma client **once** per process (inside the service object), with telemetry off: `chromadb.PersistentClient(path=..., settings=chromadb.Settings(anonymized_telemetry=False))`.
7. **Streamlit:** create the `RecommendationService` once and keep it in `st.session_state`; do not call `st.rerun()` inside callbacks (they already trigger a rerun); log impressions only inside the service, never in render code.
8. If `st.chat_input` misbehaves inside a column, render the chat history in the column and use `st.text_input` plus a **Send** button (callback) instead.
9. **SQLite:** open with `check_same_thread=False`; all timestamps come from `now_iso()` (UTC, seconds precision) so string comparison of `starts_at`/`ends_at` is correct; during data generation use one transaction, `executemany` and `PRAGMA synchronous=OFF`.
10. Never print or log API keys; log only deployment names and the endpoint host.
11. Reasoning-model deployments reject `temperature` and `max_tokens`; use a standard chat deployment (see section 8.4).
12. Optional mock API: start it from the repo root with the venv active using `--factory`; if port 8001 is busy, change the port in the `uvicorn` command and in `MOCK_API_BASE_URL` together.

---

## 12. Testing and Validation

### 12.1 Smoke tests (`scripts/smoke_test.py`)

| ID | Check | Expected |
|---|---|---|
| S-01 | One chat call ("Reply with OK") and one embedding call | Non-empty text; vector length > 0 |
| S-02 | Data counts | `products`=50,000; `inventory`=50,000; `customers`=12; `events`>=300; `products.embedded=1` count = 2,000; Chroma count = 2,000 |
| S-03 | `service.recommend` for C01 `home` in AI mode | 3-5 items, all `stock.status != out_of_stock`, audit row exists, no exception |

`python scripts/smoke_test.py --azure-only` runs S-01 only (use it in Block 1, before any data exists).

### 12.2 Unit tests

| ID | Test | Input | Expected output |
|---|---|---|---|
| T-01 | `test_privacy.py::test_mask_email_phone_card_name` | `"I am Anna Lee, mail anna.lee@x.com, call +44 7700 900123, card 4111 1111 1111 1111"` with `known_names=["Anna Lee"]` | `"I am [NAME], mail [EMAIL], call [PHONE], card [CARD]"`; entities `["CARD","EMAIL","NAME","PHONE"]` |
| T-02 | `test_privacy.py::test_pseudonym_stable_and_opaque` | `pseudonymize("C01","s1")` twice; with salt `s2` | Same value twice; differs with another salt; starts with `u_`; does not contain `C01` |
| T-03 | `test_services.py::test_inventory_stock_update_visible` | `set_stock(sku, 0)` then `get_stock` | status `out_of_stock`; `reset_stock()` restores `initial_qty`; qty 3 gives `low_stock` |
| T-04 | `test_services.py::test_flash_sale_price` | base 100.00 in category; `start_flash_sale(cat, 25, 30)` | `effective_price` 75.00, `discount_pct` 25; after `clear_flash_sales()` back to 100.00; overlapping standing 10% and flash 25% gives 25% |
| T-05 | `test_guardrails.py::test_schema_validation` | Invalid JSON; missing `confidence`; 6 recommendations; fenced JSON | `ValidationFailed` for the first three; fenced JSON parsed successfully |
| T-06 | `test_guardrails.py::test_oos_removed_and_backfilled` | Output recs [A,B,C]; B out of stock; pool [D,E]; X hallucinated | Result contains A, C, D; flags include `removed_oos:B`, `backfilled:D`; hallucinated SKU dropped with flag |
| T-07 | `test_agent_loop.py::test_retry_on_invalid_json_then_success` | `FakeLLM`: invalid text, then valid JSON | `validation_retries == 1`, output not None |
| T-08 | `test_agent_loop.py::test_fallback_on_low_confidence` | `FakeLLM` returns confidence 0.3 | `fallback_used True`, `fallback_reason == "low_confidence"`, items origin `fallback` |
| T-09 | `test_agent_loop.py::test_fallback_on_azure_error` | `FakeLLM.chat` raises `LLMUnavailable` | No exception; `fallback_used True`; audit row has error |
| T-10 | `test_agent_loop.py::test_audit_row_written` | Scripted run with tool calls | One `audit_log` row with `tool_calls` listing names, `final_recs` non-empty, masked message, `pseudo_id` starts with `u_` |
| T-11 | `test_events.py::test_feedback_upsert_and_metrics` | Feedback +1 then -1 on the same card; 4 impressions, 1 click, 1 cart | One feedback row with value -1; CTR 0.25; cart_rate 0.25; satisfaction 0.0 |
| T-12 (optional) | `test_mock_api.py::test_endpoints` (TestClient, test DB) | `GET /inventory?skus=A,B`; `POST /admin/stock {A,0}` then GET again; `POST /admin/flash-sale {cat,25,30}` then `GET /pricing?skus=A`; `POST /admin/stock` with unknown SKU; `GET /inventory` with 51 SKUs | A and B returned; A becomes `out_of_stock`; `discount_pct` 25 and lower `effective_price`; 404 for unknown SKU; 400 for 51 SKUs; `/admin/reset-stock` restores stock |
| T-13 (optional) | `test_mock_api.py::test_http_clients_and_fail_closed` | HTTP clients built on the TestClient; clients pointed at `http://127.0.0.1:9` (timeout 0.5); `service.recommend` using the unreachable clients | TestClient-backed clients return the same values as the stubs; unreachable URL raises `ServiceUnavailable`; `recommend` returns `items == []`, `fallback_reason == "inventory_unavailable"`, flag present, audit row written, no exception |

### 12.3 AI quality evaluation set (`data/eval_set.json`)

Common checks for **every** case: (a) `RecResult` returned without exception; (b) all returned items have live `stock.status != out_of_stock`; (c) an `audit_log` row exists for `rec_id`; (d) `latency_ms <= 15000`; (e) the audit `user_message_masked` contains no email/phone pattern; (f) the viewed SKU (if any) is not recommended. Case-specific keys: `min_recs`, `categories_any` (at least 60% of items must be in these categories), `max_effective_price`, `scenario`.

```json
[
 {"id":"E01","customer":"C01","trigger":"home","min_recs":3,"categories_any":["Sports & Outdoors","Electronics"]},
 {"id":"E02","customer":"C03","trigger":"home","min_recs":3,"categories_any":["Books & Stationery","Electronics","Fashion"]},
 {"id":"E03","customer":"C05","trigger":"home","min_recs":3,"categories_any":["Toys & Baby","Home & Kitchen"]},
 {"id":"E04","customer":"C07","trigger":"home","min_recs":3,"categories_any":["Office & Work","Electronics","Home & Kitchen"]},
 {"id":"E05","customer":"C01","trigger":"chat","message":"I need running shoes under $80","min_recs":3,"categories_any":["Sports & Outdoors","Fashion"],"max_effective_price":80},
 {"id":"E06","customer":"C03","trigger":"chat","message":"cheap notebooks and pens for class, under $20 each","min_recs":3,"categories_any":["Books & Stationery"],"max_effective_price":20},
 {"id":"E07","customer":"C09","trigger":"chat","message":"gift for my dad who loves coffee, budget $60","min_recs":3,"categories_any":["Home & Kitchen"],"max_effective_price":60},
 {"id":"E08","customer":"C05","trigger":"chat","message":"a safe toy for a 1 year old","min_recs":3,"categories_any":["Toys & Baby"]},
 {"id":"E09","customer":"C07","trigger":"chat","message":"ergonomic chair for long work days","min_recs":3,"categories_any":["Office & Work"]},
 {"id":"E10","customer":"C01","trigger":"chat","message":"show me something for yoga","min_recs":3,"scenario":"stock_out_top_rec"},
 {"id":"E11","customer":"C11","trigger":"chat","message":"treats for my dog","min_recs":3,"scenario":"flash_sale","sale_category":"Pet Supplies","sale_pct":30},
 {"id":"E12","customer":"C02","trigger":"chat","message":"my email is john.doe@example.com and phone +44 7700 900123, suggest a smartwatch","min_recs":1,"categories_any":["Electronics"]},
 {"id":"E13","customer":"C04","trigger":"chat","message":"what is the weather in Chennai today?","min_recs":0,"scenario":"off_topic"},
 {"id":"E14","customer":"C12","trigger":"home","min_recs":3,"scenario":"no_consent"},
 {"id":"E15","customer":"C06","trigger":"view","viewed_subcategory":"Baby Gear","min_recs":3,"categories_any":["Toys & Baby"],"scenario":"exclude_viewed"}
]
```

Scenario rules:
- `stock_out_top_rec` (E10): run once; set stock of the rank-1 SKU to 0; call `service.refresh`; the SKU must not be in the result; item count >= 3; afterwards `reset_stock()`.
- `flash_sale` (E11): `start_flash_sale(sale_category, sale_pct, 30)`; call `service.refresh` on the result; at least one item must have `discount_pct >= sale_pct` and `highlight_promo True`; afterwards `clear_flash_sales()`.
- `off_topic` (E13): result `intent == "off_topic"`, non-empty `reply`, and `fallback_used` may be False; zero items is acceptable.
- `no_consent` (E14): flags contain `no_consent` and the audit tool calls do not contain `recent_events`.
- `exclude_viewed` (E15): harness picks the first in-stock SKU of subcategory `viewed_subcategory`, calls `recommend(trigger="view", viewed_sku=...)`.

Pass criteria: a case passes when all common and case-specific checks pass. **Overall pass rate must be >= 80% (12 of 15)**; `run_eval.py` prints the per-case table, writes `data/eval_report.json` and exits non-zero when the threshold is missed. Because LLM output is stochastic, rerun once before tuning prompts.

### 12.4 Demo checklist
- [ ] `.env` filled and `python scripts/smoke_test.py` passes
- [ ] `python scripts/run_eval.py` shows >= 80%
- [ ] Streamlit starts on `localhost:8501`; flash sale reset and stock reset buttons tested
- [ ] Customer C01 and C12 each produce home recommendations
- [ ] Backup: screenshots of each demo step and a recorded run in case of Wi-Fi/Azure problems
- [ ] Browser zoom and window sized for projector

---

## 13. Run and Demo Guide

### 13.1 Setup commands

```bash
git init retail-reco-poc && cd retail-reco-poc
python3.11 -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install -e .
cp .env.example .env                 # then fill Azure values in .env
python scripts/smoke_test.py --azure-only   # S-01: confirms Azure chat + embeddings work (run first)
python scripts/generate_data.py      # ~30 s
python scripts/build_index.py        # ~2-4 min, 20 embedding batches
python scripts/smoke_test.py         # S-01..S-03 full check
pytest -q
```

### 13.2 Run commands

```bash
streamlit run app/streamlit_app.py   # opens http://localhost:8501
python scripts/run_eval.py           # AI quality evaluation

# optional, only with API_BACKEND=http (section 7.4b); start it BEFORE Streamlit
uvicorn mock_api.main:create_app --factory --port 8001
```

### 13.3 Demo script

| Step | Action | Expected result |
|---|---|---|
| D0 | Pre-demo: run generate, build_index, smoke test | Counts match; smoke passes |
| D1 | Open the app; select **C01 - fitness_fan**, mode AI | Spinner then 3-5 cards (running/fitness/wearables) with reasons, prices, promo badges |
| D2 | In Browse, choose "Electronics", click **View** on a product | Recommendations update to complement the viewed product; viewed item not shown |
| D3 | Chat: "I need a gift for my dad who loves coffee, under $60" | Assistant reply plus cards from Coffee & Tea, all under budget, with reasons |
| D4 | Chat: "my email is john.doe@example.com, suggest a smartwatch"; then switch to **C12** (no consent) | Chat shows `[EMAIL]`; the audit viewer shows masked text; C12 results carry `no_consent` in flags and are not personalized from history |
| D5 | Sidebar: pick the top card SKU, click **Mark out of stock** | Card disappears instantly (no LLM call), a replacement appears; audit row trigger `refresh` shows `removed_oos` |
| D6 | Sidebar: **Start flash sale** on the category of the cards, 30%, 30 min | Discounted prices and red badges appear on cards |
| D7 | Click 👍 on two cards and 👎 on one | Satisfaction metric updates; feedback rows stored |
| D8 | Click **View**/**Add to cart** on a card; switch mode to Baseline and repeat; compare | Metrics panel shows CTR and add-to-cart rate per mode, session duration increases |
| D9 | Open the **Audit log** expander | Last rows show rec_id, trigger, tool names, confidence, fallback flag, guardrail flags |
| D10 | Terminal: `python scripts/run_eval.py` | Per-case PASS/FAIL table and overall pass rate >= 80% |
| D11 | Resilience: temporarily set a wrong `AZURE_OPENAI_CHAT_DEPLOYMENT` in `.env`, restart, request recommendations (optional) | "Showing popular picks" caption, items still valid; audit row `fallback_used=1` |
| D12 (optional) | Terminal 1: `uvicorn mock_api.main:create_app --factory --port 8001`; set `API_BACKEND=http` in `.env`; restart Streamlit; open `http://127.0.0.1:8001/docs`. Terminal 2: `curl "http://127.0.0.1:8001/inventory?skus=<top SKU>"`; click **Mark out of stock** in the UI; run the curl again | Swagger lists the endpoints; curl shows `qty` 0 and `out_of_stock` after the click; the card disappears exactly as in stub mode |

### 13.4 Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `ConfigError: missing AZURE_OPENAI_...` | `.env` incomplete | Fill all required variables; restart Streamlit |
| 401 or 404 `DeploymentNotFound` | Wrong key or deployment name | Use the deployment name (not model name) from Azure portal; check endpoint host |
| 400 about `tools` or `tool_choice` | Deployment/model lacks function calling | Use GPT-4o / GPT-4.1 / mini deployment and API version `2024-10-21` or newer |
| 429 rate limit during indexing | Low embedding TPM quota | Lower batch size to 50 in `llm.embed`; rerun `build_index.py --reset` |
| `sqlite3` version error from Chroma | Old system SQLite | `pip install pysqlite3-binary` and add the standard `sys.modules["sqlite3"] = pysqlite3` shim at the top of `retrieval.py` and `build_index.py` |
| Streamlit shows duplicate impressions | Logging inside UI reruns | Ensure impressions are logged only in `service.recommend/refresh` |
| `ProgrammingError: SQLite objects created in a thread` | Connection shared across Streamlit threads | Use `check_same_thread=False` in `get_conn` |
| Slow recommendations (> 10 s) | Large model or many tool rounds | Use a mini deployment; lower `AGENT_MAX_ITERATIONS` to 4 |
| Empty cards after sale/stock actions | Pool exhausted | Click **Refresh** or send a new chat message; fallback fills items |

---

## 14. Risks and Mitigations

| # | Risk | Likelihood | Impact | Mitigation | Fallback |
|---|---|---|---|---|---|
| R1 | Embedding run slow or throttled by Azure quota | Medium | Medium | Batches of 100, progress output, run in Block 2 early | Reduce subset to 1,000 (20 per subcategory) via env var |
| R2 | Streamlit rerun/state bugs (duplicate logging, stale cards) | Medium | Medium | Callbacks, state keys per 8.9, logging only in service | Remove "view" trigger on browse (cut list 4) |
| R3 | Agent returns invalid JSON or poor relevance | Medium | High | Strict prompt, temperature 0.2, 2 retries, eval set early | Fallback ranker; switch to a stronger deployment |
| R4 | Azure outage or Wi-Fi failure during demo | Low | High | Smoke test before demo, backup screenshots | Baseline mode (no LLM) still works fully |
| R5 | Deployment lacks function calling | Low | High | Verify in Block 1 smoke test | Ask admin for another deployment; do not change architecture |
| R6 | Scope overrun beyond 4 hours | Medium | Medium | Time-boxed blocks, cut list in 11.4 | Drop cut-list items in order |
| R7 | Hallucinated SKU or price in text | Low | Medium | SKU existence check, prices only from services, prompt rule 7 | Guardrail removes SKU; UI never shows LLM prices |
| R8 | Metrics misread as statistically valid uplift | Medium | Low | Label panel "illustrative demo counters" | State clearly in the demo narration |
| R9 | Optional mock API not started, port busy, or app and API using different DB files | Medium | Medium | Health check at app start with a clear message; run both from the repo root with the same `.env`; fail-closed behavior | Set `API_BACKEND=stub` and restart (identical demo, no HTTP) |

---

## 15. Production Path (Post-POC)

- **Integration:** replace the stubs with HTTP clients for the real inventory, pricing and promotion APIs (same Protocols), add caching with short TTLs and circuit breakers; add a FastAPI service and embed the widget as JavaScript in the storefront.
- **Data and scale:** embed the full 50k catalog (batch jobs plus incremental updates) in a managed vector store (e.g. Azure AI Search); stream session events from the real clickstream; precompute user/session features.
- **Privacy and security:** real consent management, data retention and deletion workflows, regional processing, encryption at rest and in transit, Entra ID auth for Azure OpenAI, secrets in Key Vault, DPIA.
- **Quality and MLOps:** larger labelled sets, offline evaluation in CI, LLM-as-judge for explanations, prompt versioning, online A/B testing with proper statistics for click-through, conversion and satisfaction.
- **Operations:** tracing and dashboards (latency, tokens, fallback rate, guardrail hits), cost budgets and rate-limit handling, autoscaling, audit log shipped to immutable storage with retention.

---

## 16. Appendix

### 16.1 Glossary
- **SKU:** stock keeping unit, a unique product identifier.
- **RAG/hybrid:** retrieval of relevant documents to ground an LLM; here retrieval seeds candidates and the agent calls tools.
- **Tool/function calling:** the LLM requests structured calls to code-defined functions.
- **Pseudonymization:** replacing identifiers with a salted hash so records are not directly attributable.
- **Audit log:** persistent record of each recommendation's inputs, tool calls and outputs.
- **Flash sale:** a time-limited, category-wide promotion created by the simulator.

### 16.2 References
- Azure OpenAI Service: chat completions with function calling, embeddings (use the API version in `.env`).
- OpenAI Python SDK `AzureOpenAI` client; Streamlit chat elements; Chroma persistent client and metadata filtering.
- Problem statement: AI Friday Season 3, "AI-Enhanced Personalized Retail Product Recommendation Generator" (TCS Internal, 5 November 2026).

### 16.3 Open questions
None. Pending builder input only: the Azure endpoint, key, deployment names and API version to be placed in `.env`.
