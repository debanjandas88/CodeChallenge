Read `AGENTS.md` first and follow it for all work in this repository. Progress lives in `task_tracker.md` and must be updated after every task.
