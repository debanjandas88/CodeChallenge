# AGENTS.md - Instructions for any AI agent or model working on this project

## Project
ShopSmart is a local proof-of-concept retail storefront with synthetic products and shoppers, a Streamlit shopping experience, and personalized recommendations grounded by Azure OpenAI retrieval/tool calls and live SQLite-backed stock/pricing stubs. The release-blocking demo path is lightweight account creation, storefront entry, product browsing/viewing with available images or placeholders, and recommendation/chat. Source documents: `SDD.md` (design and source of truth), `implementation_plan.md` (approved build sequence), and `task_tracker.md` (single live progress source).

Constraints: 4–5 hour total prototype; Azure OpenAI is the only LLM; UI is Streamlit; stack is Python 3.11+, SQLite, Chroma, Pydantic v2, and the plain Azure OpenAI SDK. Do not add production authentication, passwords, SSO, product administration, new services, or frameworks.

## STARTUP PROTOCOL (every new session and every model switch)
1. Read, in order: `AGENTS.md`, `SDD.md`, `implementation_plan.md`, `task_tracker.md` (including Session/Handoff Log, Manual Actions, and Blockers).
2. Find the first task that is not DONE, respecting dependencies and phase gates.
3. Print a short status: current phase, last completed task, next task, and open Manual Actions or Blockers.
4. Explicitly ask the developer: **"Who is working right now, and what should I do next?"** Offer:
   - A) Continue with the next task in the tracker [recommended]
   - B) Resume the IN PROGRESS / blocked task
   - C) Resolve a pending manual action together
   - D) Re-plan or change scope (requires a Decision Log entry)
   - E) Other
5. Do not start coding until they answer.

## WORKING RULES
- Work only from `task_tracker.md`. One task at a time, in order, and honor `Depends on`.
- Update `task_tracker.md` immediately after EVERY subtask or task, before doing anything else: status, checkboxes, timestamps, files, notes, counts, and handoff if switching/stopping.
- A task is DONE only after its stated acceptance check passes; record the actual result.
- If a human action, credential, install, approval, or decision is needed, stop; mark the task `BLOCKED-HUMAN`, update Manual Actions/Blockers, print the ACTION REQUIRED block below, list what follows, and wait.
- Never change scope, architecture, stack, or `SDD.md` without asking and recording the approved change in the Decision Log first.
- Never hardcode secrets. `.env` is local/ignored; `.env.example` contains placeholders only. Never print/log API keys or ask for them in chat.
- Use only Azure OpenAI for LLM calls, through the single client wrapper in `src/retailrec/llm.py`.
- Follow the actual project structure in `SDD.md`; add no untracked application files without first adding a tracker task.
- Git workflow is no Git/commits for this workspace unless the human explicitly changes that decision and the tracker records it.
- Keep account creation and product browse/view paths release-blocking. Render images where available and a category placeholder when missing/broken. Do not add product administration.
- Optional FastAPI mock API is deferred; do not start it unless core demo work is done, time remains, and the human approves recording the scope decision.
- Phase order: Setup → Development → ML Training (N/A; no training in SDD) → Testing and Debugging → Demo Prep → Final Documentation.
- At each phase gate, update the phase summary, summarize results, and wait for human confirmation before starting the next phase.

## ACTION REQUIRED FORMAT
**ACTION REQUIRED (task <ID>)**
- What: <what the human must do>
- How: <exact steps>
- Why needed: <reason>
- When done, tell me: "<what to reply>"
- Next steps after this: <ordered list>

## ON MODEL SWITCH OR SESSION END
Before stopping or switching, update tracker status and timestamps, add a newest-first Session/Handoff Log row (time, model/agent, completed work, next task, gotchas), and ensure no task is falsely marked DONE. A new model must follow the STARTUP PROTOCOL.

## CODING CONVENTIONS
Use Python 3.11+, type hints, Pydantic v2 at module boundaries, SDD-pinned packages, concise docstrings where applicable, and `logging` without sensitive or raw unmasked user text. Follow SDD module/function names, schemas, and error-handling behavior. Keep functions focused. Use SQLite through the shared DB helpers and inventory/pricing through the Protocols. Unit tests use `FakeLLM`; do not make network calls from unit tests. Do not add a linter without approval.

## HOW TO RUN
From a Windows PowerShell terminal at the project root:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pip install -e .
Copy-Item .env.example .env
# Fill Azure values and PSEUDO_SALT locally; never share them in chat.
python scripts/smoke_test.py --azure-only
python scripts/generate_data.py
python scripts/build_index.py
python scripts/smoke_test.py
pytest -q
python scripts/run_eval.py
streamlit run app/streamlit_app.py
```

## FINAL DOCUMENTATION GATE
`README.md`, `WALKTHROUGH.md`, and `SOLUTION_OVERVIEW.md` are the final phase and must not be written before testing/debugging and Demo Prep are DONE and the human explicitly replies `CONFIRM COMPLETE`. Describe only real final code/results, verify every command/path/result, and leave no placeholders.
